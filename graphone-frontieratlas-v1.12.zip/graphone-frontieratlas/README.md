# GraphOne / FrontierAtlas - AI Ingestion Pipeline

**Ingestion pipeline + dashboard for the AI/venture ecosystem.** Every record traces to a real source URL; LLM-extracted fields are kept only if their verbatim evidence appears in the source text.

| Measured (reproducible) | Result | How |
|---|---|---|
| Startups, live run | **1,000 unique** YC startups, all with source URL | `run startups` |
| Products, live run | **600 unique** GitHub products (licence evidence, live stars); remaining 400 come from pricing pages | `run products` |
| Entity resolution (self-authored) | 100% precision / 100% recall, 31/31 look-alikes kept separate, 113 names | `python scripts/eval_resolver.py` |
| Entity resolution (real data) | 225 real GitHub org logins, scored with the pipeline's own call (login + homepage): **219/219 non-seed orgs kept separate, 6/6 seed companies found.** See note below | `python scripts/eval_resolver.py er_heldout.csv` |
| Fetch throughput | **135 req/s per process** (local loopback, 40 ms latency); per-host politeness cap 6.7 req/s | `python scripts/benchmark.py` |
| Chaos test | real LLM engine survives permanent 429s and 413s via backoff, fallback and shrink | dashboard, *Chaos Mode* |
| Tests / coverage | all offline tests pass; 64% line coverage | `make test` |

**Entity-resolution honesty note.** The first scoring on the real-data set (labels written *before* scoring) gave 83% recall and showed two genuine bugs: homepages on shared hosts (`github.com`, `arxiv.org`) were treated as a company's own domain and merged unrelated orgs, and subdomains (`developers.llamaindex.ai`) were not reduced to the registrable domain. Both are fixed and covered by tests. The set is therefore no longer blind for those two fixes, and with only 6 seed matches the recall figure is weak evidence; the strong evidence is the 219 real non-seed organisations that stay unmapped. Two NVIDIA repos merging via `nvidia.com` is a legitimate same-company merge.

Not yet run against the live internet: arXiv, Hugging Face papers, job boards, news feeds, real LLM keys, Tier 1/2 anti-bot. See `SUBMISSION_CHECKLIST.md`. Changelog: `CHANGELOG.md`.

Async, fault-tolerant pipeline that acquires startups, products, research papers (with live GitHub stars), 24h-fresh AI news and jobs,
structures them with a **multi-tier LLM engine that is not allowed to hallucinate**, and resolves messy entity names to canonical ones.

```
Discover -> Frontier -> Fetch (aiohttp > curl_cffi > Playwright) -> Extract (rules, then Gemini>Groq>DeepSeek + grounding) -> Resolve -> Store/Export
```
Full design: [`architecture.pdf`](architecture.pdf) (2 pages).

## Run it (generates the real data for the Google Sheet)

```bash
# Requires Python 3.11+
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # add GITHUB_TOKEN (strongly recommended) + any of GEMINI/GROQ/DEEPSEEK keys
make test                   # offline tests
PYTHONPATH=src python -m graphone run all --target 50    # smoke test (minutes)
PYTHONPATH=src python -m graphone run all                # full run: 1,000 / 1,000 / 1,000 + 24h signals
```
Outputs land in `output/`: `graphone_output.xlsx` (the **6 tabs**: Startups, Products, Research Papers, Jobs, News, Entity Mapping Log),
per-tab CSV/JSONL, and `run_report.json` (counts, retry/429/413 stats, quality gates). The CLI exits non-zero if a target is missed or
a gate fails (stale row, duplicate, missing `source.url`).

Publish the Sheet: import the xlsx via *Google Sheets -> File -> Import -> Insert new sheets*, then *Share -> Anyone with the link*; or
`python scripts/publish_to_sheets.py` (service account, see header of that file).

Optional anti-bot tiers: `pip install curl_cffi playwright && playwright install chromium`. Optional distributed state: set `REDIS_URL`.
The LLM chain is optional: without keys the pipeline runs deterministically (rules + grounding), and only rule-undecidable items are skipped.

## What maps to what

| Brief | Code |
|---|---|
| Phase I bulk startups / products / papers | `sources/yc.py`, `sources/products.py`, `sources/papers.py`, `pool.py` (bounded async worker pool) |
| Paper -> GitHub repo -> live stars | `papers.py`: 4-tier repo discovery (HF papers API, legacy PwC API, arXiv abstract, none) + GitHub REST with rate-limit pause; `github_stars_checked_at` stamped |
| Phase II 5 news + 5 job boards, 24h | `sources/news.py` (TechCrunch, VentureBeat, The Verge, MIT TR, HF Blog), `sources/jobs.py` (RemoteOK, Remotive, WWR, Greenhouse, Lever) |
| Date normalisation + heuristic | `dates.py` (relative dates, JSON-LD, meta, `<time>`, URL, Last-Modified, epochs, TZ abbreviations), `state.py:FreshnessGate` (baseline-run first-seen heuristic) |
| Phase III LLM fallback / chunking / 429 | `llm.py` (Gemini->Groq->DeepSeek, full-jitter backoff, circuit breaker, adaptive 413 shrink), `textclean.py:smart_truncate` |
| Phase IV entity resolution | `resolver.py` + `data/seed_entities.json` (50 AI startups, aliases, domains) |
| Phase V anti-bot / async | `fetcher.py` (3-tier ladder, block detection, cookie harvest, per-domain pacing, robots.txt) |
| No hallucination | `grounding.py`: a field survives only with a verbatim evidence quote present in the fetched text |
| Exactly-once across nodes | `state.py` (claim -> process -> commit leases; SQLite or Redis) |

## Design decisions worth knowing

* **Rules first, LLM second.** Structured APIs/feeds/JSON-LD give dates, titles, companies directly; the LLM is used for the long tail (pricing ambiguity, company mentions) and is *verified*, not trusted.
* **Evidence or nothing.** Pricing rows store the verbatim snippet they were classified from; papers without a discoverable repo keep `github_url = null`.
* **Honest dates.** Every job/news row has `date_method`. Greenhouse `updated_at` is *not* treated as a publish date; undated items only pass via the baseline-run heuristic and are labelled `first-seen-heuristic`.
* **Politeness.** robots.txt honoured for HTML, arXiv paced at 3.1 s, no CAPTCHA solving; hard-blocked sources are dead-lettered (see architecture.pdf section 4).

## Known limitations (read before submitting)

* The code and tests were validated **offline** (offline tests, including a local server simulating 429 + Retry-After, Cloudflare-style challenges, robots.txt, and end-to-end news/product record paths). The live endpoints (YC mirror, arXiv, HF papers, feeds, job-board APIs) must be exercised on your machine; if a vendor changed a response shape, the fix is local to one adapter and the run report will show it as a shortfall rather than silently passing.
* Tier 1/2 anti-bot (`curl_cffi`, Playwright) and the Redis backend follow the same interfaces but are not covered by the offline tests.
* Products come from startup pricing pages: only companies with a discoverable pricing page and evidence produce a record, so the pipeline examines a wider pool than 1,000 to reach 1,000. If your run falls short, raise the pool (more sources) rather than relaxing evidence rules.
* The "24h fresh" tabs depend on what was published in the 24h before *your* run; run it once, then export immediately.
* Model names change; override with `GEMINI_MODEL`, `GROQ_MODEL`, `DEEPSEEK_MODEL`.

## Repo layout
```
src/graphone/  config models dates textclean fetcher llm grounding resolver state pool context export pipeline __main__
src/graphone/sources/  yc products papers news jobs
data/seed_entities.json   tests/   scripts/   architecture.pdf
```

## Mission Control dashboard
```bash
make dashboard        # or: PYTHONPATH=src python dashboard/server.py --out output --port 8000
```
Open http://localhost:8000. Pages: Mission Control (live counters, quality badges, fetch/LLM/resolver stats), Data & Evidence (all 5 tabs, click a row for source URL + verbatim evidence / GitHub stars / date provenance), Freshness Radar (24h timeline by date_method), Knowledge Graph, Entity Lab (step through the resolution cascade). It reads only `output/*.jsonl` + `run_report.json`; no run output = empty state, never placeholder data.
