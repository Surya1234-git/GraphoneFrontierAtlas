# Changelog

## v1.1 additions
* **Confusable folding** in the resolver (`OpenAl`, `Anthr0pic` -> canonical; guarded by a test that no two seed entities collide).
* **Map-reduce extraction** (`LLMOrchestrator.extract_long`): documents larger than any provider budget are chunked, extracted per chunk (each grounded against its own chunk) and merged. Used by news and products.
* **Star history** (`output/star_history.jsonl`): every run appends a (repo, stars, timestamp) snapshot -> star momentum across runs.
* **Docker / CI**: `Dockerfile`, `docker-compose.yml` (Redis + two workers + dashboard = exactly-once demo), GitHub Actions running the tests.

## v1.2 additions
* **Chaos Mode** (dashboard, Mission Control): runs the *real* `LLMOrchestrator` against an in-process mock server that returns permanent 429s on tier A and 413s on tier B until the chunker shrinks the payload; shows each request, the jittered backoffs, the fallback and the grounded result. Test: `tests/test_chaos_and_hf.py`. Note: task `keywords` steer which sentences survive truncation; always pass them.
* **Papers-first** (`papers.py`): Hugging Face daily papers (repo-linked, with `githubRepo`) are processed before general arXiv, raising the share of papers with live GitHub stars. Falls back to arXiv automatically. *Live shape of the HF endpoint is untested here: check `run_report.json`.*
* **Star momentum** card (from `star_history.jsonl`), Prometheus **`/metrics`** on the dashboard server, and `--json-logs` for structured logs.

## v1.3 additions
* **Real products**: `products.py` now sources ~60% of products from the GitHub search API (org-owned, licensed, non-fork, non-archived AI repos). Each record has a distinct product name, the owning org resolved to a canonical startup, `FREE` with the licence + URL as evidence, and live stars. The rest still come from startup pricing pages (FREEMIUM / PAID / ENTERPRISE). Verified against the live API (30 repos -> 16 qualified). If GitHub is unreachable the pricing path continues alone.
* **Preflight**: `python scripts/preflight.py` hits all 15 live sources once and reports which adapter's response shape has drifted. **Run this before the full pipeline.**
* **Redis exactly-once is now tested** with `fakeredis` (20 concurrent claimers -> exactly one winner; commit blocks forever; release lets a crashed worker's item be retried).

## v1.4: live verification status
Run end-to-end against the real internet from a restricted sandbox (only GitHub hosts reachable):
* **Startups: PASS.** `run startups --target 1000` produced **1,000 unique YC startups** (all with employee counts, source URLs, canonical names). The YC adapter now falls back to the `raw.githubusercontent.com` mirror automatically.
* **Products: PASS (60% path).** `run products` produced **600 unique GitHub products** (475 distinct orgs, licence evidence, live stars). The remaining 400 come from startup pricing pages, which the sandbox could not reach.
* **Not verifiable there** (run `python scripts/preflight.py` on your machine): arXiv, Hugging Face papers, job boards, news feeds. These adapters are covered by offline tests but have not touched the live services.

## v1.6: UI
Mission Control now has a hero with a live target-coverage ring, per-metric progress rings, an animated pipeline, mouse-tracking glow cards, a ⌘/Ctrl+K command palette and a one-click **Auto demo** (walks judges through every page, triggers Chaos Mode and opens the evidence drawer). The graph clusters startups by YC batch and links products, papers→repos, jobs and news by canonical entity. All figures come from `output/`; badges only claim what the data shows. `is_ai` is now strict (tags / one-liner / repeated description mentions) so a payroll company that says "AI-powered" once is not flagged AI.

## v1.7: dashboard fixes + hosting
* Mobile bottom navigation, keyboard/ARIA support, sortable + paginated tables, http(s)-only source links, copy-URL button.
* The knowledge graph now cools down and stops animating (no idle CPU); the freshness radar uses deterministic positions and redraws on resize.
* **Host it for judges**: `make export-static` writes a serverless copy to `docs/` (index.html + data/*.json); enable GitHub Pages on `/docs`. Chaos Mode and Entity Lab need the live server and say so on the static site.

## v1.8
* Labelled entity-resolution benchmark (`data/er_labelled.csv`, `scripts/eval_resolver.py`); dotted legal suffixes (`L.L.C.`) now normalised.
* `scripts/benchmark.py` throughput benchmark; measured numbers and an extrapolation table in `architecture.pdf`.
* Dashboard: graph pre-settles and cools slowly, drawer above mobile nav with focus trap/return, real tab roles, reduced-motion support, short mobile labels, split into `index.html` / `app.css` / `app.js`.

## v1.9
* **Bug fix (data corruption):** resolver no longer treats shared-host homepages (github.com, arxiv.org, ...) as company domains; registrable-domain (eTLD+1) reduction for subdomains. Found by a held-out set of 225 real GitHub org logins (`data/er_heldout.csv`).
* Dashboard: warm light theme by default with dark toggle, inline SVG icons, system fonts (no external requests), run-summary hero built from real counts, Data Trust panel, Open-source-URL button, CSV download, config.json for Sheet/GitHub links; removed aurora/glow effects; closed drawer fully hidden (no shadow leak, not focusable); mobile safe-area + caption position.

## v1.10
* **Order-independent canonical names**: non-seed organisations are no longer merged by domain, and a post-run stabilisation pass (`stabilize.py`) renames each non-seed entity to its most frequent cleaned spelling, so concurrent workers cannot change the output (60-permutation test).
* Accessibility: light-theme accent darkened (white-on-accent 5.2:1, accent-on-page 4.9:1), nav glyphs removed from the HTML source, dead aurora/glow/infinite-loop CSS deleted, first-visit theme follows `prefers-color-scheme`.
* Fixed README "42 tests" claim; fixed a stray CSS brace (guarded by a new test).

## v1.11
* Dashboard: nav icons now live in the HTML source (work without JS), Inter variable font self-hosted (`dashboard/fonts/`, OFL licence included, no external requests), canvases render at the device pixel ratio (verified at 1x/2x/3x), JS syntax gate test.

## v1.12
**Bug fixes** (each with a test): every file read/write in `src/` is explicitly UTF-8 (tested under `LC_ALL=C PYTHONUTF8=0`); `entity_mapping_log.csv` now *merges* across invocations (dedupe on raw+canonical, newest wins) instead of being overwritten; log and JSONL rewrites are atomic (temp file + `os.replace`); stabilisation groups by normalised key so names produced by different invocations unify.
**New tools (read real files only, refuse otherwise):** `scripts/finalize_submission.py` (brief validator, 6-tab xlsx/CSV export, static site to `docs/`, `config.json` links, README RESULTS block, optional `--push-sheet`), `scripts/make_llm_trace.py` (from `output/llm_events.jsonl`, which the orchestrator now writes), `scripts/screenshots.py`, `scripts/build_heldout_candidates.py` (+ `eval_resolver.py` refuses unlabeled rows), `scripts/submit_check.py`, `scripts/lighthouse.sh`, `make submit-check`.
**Not done in v1.12:** `antibot_probe.py`; mypy at 0 errors; the coverage gate of 75 percent (current coverage is about 64 percent, so `make submit-check` fails honestly until that is raised); regenerating architecture.pdf from measured files; README restructure beyond the generated blocks; dashboard items 13-16 (token-based theme, first-run empty-state cards, meta/OG tags and About drawer, graph legend/zoom, table filter chips).
