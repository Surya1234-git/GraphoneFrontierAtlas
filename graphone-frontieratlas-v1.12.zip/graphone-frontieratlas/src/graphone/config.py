from __future__ import annotations
import os
from dataclasses import dataclass, field
from pathlib import Path


def _load_dotenv(path: str = ".env") -> None:
    p = Path(path)
    if not p.exists():
        return
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip())


@dataclass
class Settings:
    out_dir: Path = Path("output")
    state_path: Path = Path("output/state.sqlite")
    redis_url: str = ""
    proxy_url: str = ""
    concurrency: int = 40
    per_domain_concurrency: int = 6
    contact_email: str = "contact@example.com"
    github_token: str = ""
    gemini_key: str = ""
    groq_key: str = ""
    deepseek_key: str = ""
    gemini_model: str = "gemini-2.5-flash"
    groq_model: str = "llama-3.3-70b-versatile"
    deepseek_model: str = "deepseek-chat"
    respect_robots: bool = True
    freshness_hours: int = 24
    # per-host minimum seconds between requests (politeness; arXiv asks for >=3s)
    domain_intervals: dict = field(default_factory=lambda: {
        "export.arxiv.org": 3.1, "arxiv.org": 1.0, "api.github.com": 0.0,
        "huggingface.co": 0.1,
    })
    targets: dict = field(default_factory=lambda: {"startups": 1000, "products": 1000, "papers": 1000})

    @classmethod
    def from_env(cls) -> Settings:
        _load_dotenv()
        e = os.environ.get
        return cls(
            out_dir=Path(e("OUT_DIR", "output")),
            state_path=Path(e("STATE_PATH", "output/state.sqlite")),
            redis_url=e("REDIS_URL", ""), proxy_url=e("PROXY_URL", ""),
            concurrency=int(e("CONCURRENCY", "40")),
            contact_email=e("CONTACT_EMAIL", "contact@example.com"),
            github_token=e("GITHUB_TOKEN", ""),
            gemini_key=e("GEMINI_API_KEY", ""), groq_key=e("GROQ_API_KEY", ""),
            deepseek_key=e("DEEPSEEK_API_KEY", ""),
            gemini_model=e("GEMINI_MODEL", "gemini-2.5-flash"),
            groq_model=e("GROQ_MODEL", "llama-3.3-70b-versatile"),
            deepseek_model=e("DEEPSEEK_MODEL", "deepseek-chat"),
        )
