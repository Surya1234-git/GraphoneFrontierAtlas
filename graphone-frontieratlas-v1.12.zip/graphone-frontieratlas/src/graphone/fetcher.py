"""Async HTTP layer: per-domain politeness, retry w/ exponential backoff + full jitter,
block detection and a 3-tier escalation ladder (aiohttp -> TLS-impersonation -> real browser).

Design rules
  * Cheapest tier first; the winning tier is remembered per domain, so a Cloudflare-protected
    host costs one browser launch, after which harvested cookies make plain HTTP work again.
  * No CAPTCHA solving, no credential stuffing. robots.txt is honoured for HTML crawls.
  * Prefer official APIs / feeds wherever they exist; escalation is the fallback, not the plan.
"""
from __future__ import annotations
import asyncio
import json as _json
import logging
import random
import time
import urllib.robotparser as robotparser
from dataclasses import dataclass
from typing import Any, Optional
from urllib.parse import urlsplit

import aiohttp

log = logging.getLogger("graphone.fetch")

UAS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64; rv:125.0) Gecko/20100101 Firefox/125.0",
]
BLOCK_MARKERS = ("just a moment", "cf-chl", "challenge-platform", "attention required! | cloudflare",
                 "captcha-delivery.com", "datadome", "px-captcha", "perimeterx", "enable javascript and cookies",
                 "_incapsula_", "access denied | ")


class FetchError(Exception): ...
class RateLimited(FetchError): ...
class BlockedError(FetchError): ...


@dataclass
class FetchResult:
    url: str
    status: int
    text: str
    headers: dict
    tier: int = 0
    final_url: str = ""

    def json(self) -> Any:
        return _json.loads(self.text)


def looks_blocked(status: int, headers: dict, body: str) -> bool:
    h = {k.lower(): str(v).lower() for k, v in headers.items()}
    if "cf-mitigated" in h or h.get("x-datadome") or "x-datadome-cid" in h:
        return True
    head = (body or "")[:6000].lower()
    marker = any(m in head for m in BLOCK_MARKERS)
    if status in (401, 403, 429, 503) and marker:
        return True
    if status in (403, 503) and ("cloudflare" in h.get("server", "") or "datadome" in h.get("server", "")) and len(body or "") < 20000:
        return True
    return status == 200 and marker and len(body or "") < 15000  # soft-block interstitial


class _Pacer:
    """Per-host min-interval pacing + concurrency cap."""

    def __init__(self, interval: float, conc: int):
        self.interval, self.sem, self._next, self._lock = interval, asyncio.Semaphore(conc), 0.0, asyncio.Lock()

    async def wait(self) -> None:
        if self.interval <= 0:
            return
        async with self._lock:
            now = time.monotonic()
            delay = max(0.0, self._next - now)
            self._next = max(now, self._next) + self.interval
        if delay:
            await asyncio.sleep(delay)


class Fetcher:
    def __init__(self, *, concurrency: int = 40, per_domain: int = 6, intervals: Optional[dict] = None,
                 proxy: str = "", respect_robots: bool = True, max_tier: int = 2, timeout: float = 30,
                 max_attempts: int = 5, base_delay: float = 0.8, max_delay: float = 45.0,
                 contact: str = "", sleep=asyncio.sleep):
        self.global_sem = asyncio.Semaphore(concurrency)
        self.per_domain, self.intervals = per_domain, intervals or {}
        self.proxy, self.respect_robots, self.max_tier = proxy or None, respect_robots, max_tier
        self.timeout, self.max_attempts = timeout, max_attempts
        self.base_delay, self.max_delay, self.contact, self._sleep = base_delay, max_delay, contact, sleep
        self._pacers: dict[str, _Pacer] = {}
        self._tier: dict[str, int] = {}
        self._ua: dict[str, str] = {}
        self._cookies: dict[str, dict[str, str]] = {}
        self._robots: dict[str, Optional[robotparser.RobotFileParser]] = {}
        self._session: Optional[aiohttp.ClientSession] = None
        self._pw = None
        self._pw_ctx = None
        self._pw_lock = asyncio.Lock()
        self.stats = {"requests": 0, "retries": 0, "r429": 0, "blocked": 0, "escalations": 0}

    # ------------------------------------------------------------ lifecycle
    async def __aenter__(self) -> Fetcher:
        conn = aiohttp.TCPConnector(limit=0, ttl_dns_cache=300, enable_cleanup_closed=True)
        self._session = aiohttp.ClientSession(connector=conn, timeout=aiohttp.ClientTimeout(total=self.timeout))
        return self

    async def __aexit__(self, *exc) -> None:
        if self._session:
            await self._session.close()
        if self._pw_ctx:
            await self._pw_ctx.close()
        if self._pw:
            await self._pw.stop()

    # ------------------------------------------------------------ helpers
    def _host(self, url: str) -> str:
        return urlsplit(url).netloc.lower()

    def _pacer(self, host: str) -> _Pacer:
        if host not in self._pacers:
            self._pacers[host] = _Pacer(self.intervals.get(host, self.intervals.get(host.removeprefix("www."), 0.15)), self.per_domain)
        return self._pacers[host]

    def _headers(self, host: str, extra: Optional[dict], as_json: bool) -> dict:
        ua = self._ua.setdefault(host, random.choice(UAS))  # one stable UA per host (cf_clearance is UA-bound)
        h = {"User-Agent": ua,
             "Accept": "application/json" if as_json else "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
             "Accept-Language": "en-US,en;q=0.9"}
        if ck := self._cookies.get(host):
            h["Cookie"] = "; ".join(f"{k}={v}" for k, v in ck.items())
        h.update(extra or {})
        return h

    async def _robots_ok(self, url: str) -> bool:
        if not self.respect_robots:
            return True
        p = urlsplit(url)
        base = f"{p.scheme}://{p.netloc}"
        if base not in self._robots:
            rp = robotparser.RobotFileParser()
            try:
                async with self._session.get(base + "/robots.txt", timeout=aiohttp.ClientTimeout(total=10)) as r:
                    rp.parse((await r.text()).splitlines() if r.status == 200 else [])
                self._robots[base] = rp
            except Exception:
                self._robots[base] = None  # unreachable robots -> allow (RFC 9309)
        rp = self._robots[base]
        return True if rp is None else rp.can_fetch("*", url)

    def backoff(self, attempt: int, retry_after: Optional[float] = None) -> float:
        """Exponential backoff with *full jitter*; Retry-After is a floor."""
        cap = min(self.max_delay, self.base_delay * (2 ** attempt))
        d = random.uniform(0, cap)
        return min(self.max_delay, max(d, retry_after or 0.0))

    # ------------------------------------------------------------ public API
    async def get(self, url: str, *, as_json: bool = False, headers: Optional[dict] = None,
                  escalate: bool = True, robots: Optional[bool] = None, min_tier: int = 0) -> FetchResult:
        host = self._host(url)
        if (robots if robots is not None else not as_json) and not await self._robots_ok(url):
            raise FetchError(f"robots.txt disallows {url}")
        start = max(min_tier, self._tier.get(host, 0))
        last: Optional[Exception] = None
        for tier in range(start, (self.max_tier if escalate else start) + 1):
            try:
                async with self.global_sem, self._pacer(host).sem:
                    await self._pacer(host).wait()
                    res = await self._attempt(url, host, tier, headers, as_json)
                if tier > self._tier.get(host, 0):
                    self._tier[host] = tier
                    log.info("tier-pinned host=%s tier=%d", host, tier)
                return res
            except BlockedError as e:
                last = e
                self.stats["escalations"] += 1
                log.warning("blocked host=%s tier=%d -> escalating", host, tier)
            except ImportError as e:
                last = BlockedError(f"tier {tier} unavailable: {e}")
                log.warning("tier %d not installed (%s)", tier, e)
        raise last or BlockedError(url)

    async def get_json(self, url: str, **kw) -> Any:
        r = await self.get(url, as_json=True, escalate=False, **kw)
        if r.status >= 400:
            raise FetchError(f"{r.status} {url}")
        return r.json()

    # ------------------------------------------------------------ tiers
    async def _attempt(self, url: str, host: str, tier: int, headers, as_json: bool) -> FetchResult:
        for attempt in range(self.max_attempts):
            self.stats["requests"] += 1
            try:
                if tier == 0:
                    res = await self._tier0(url, host, headers, as_json)
                elif tier == 1:
                    res = await self._tier1(url, host, headers, as_json)
                else:
                    return await self._tier2(url, host)
            except (TimeoutError, aiohttp.ClientError, OSError) as e:
                if attempt == self.max_attempts - 1:
                    raise FetchError(f"network error {url}: {e}") from e
                self.stats["retries"] += 1
                await self._sleep(self.backoff(attempt))
                continue
            if looks_blocked(res.status, res.headers, res.text):
                self.stats["blocked"] += 1
                raise BlockedError(f"{res.status} challenge at {host}")
            if res.status == 429 or res.status >= 500:
                self.stats["r429"] += res.status == 429
                if attempt == self.max_attempts - 1:
                    raise RateLimited(f"{res.status} after {attempt + 1} attempts: {url}")
                ra = res.headers.get("Retry-After") or res.headers.get("retry-after")
                wait = self.backoff(attempt, float(ra) if ra and ra.replace(".", "").isdigit() else None)
                log.info("retry status=%d host=%s attempt=%d wait=%.1fs", res.status, host, attempt, wait)
                self.stats["retries"] += 1
                await self._sleep(wait)
                continue
            return res
        raise FetchError(url)

    async def _tier0(self, url, host, headers, as_json) -> FetchResult:
        async with self._session.get(url, headers=self._headers(host, headers, as_json), proxy=self.proxy,
                                     allow_redirects=True) as r:
            body = await r.text(errors="replace")
            return FetchResult(url, r.status, body, dict(r.headers), 0, str(r.url))

    async def _tier1(self, url, host, headers, as_json) -> FetchResult:
        from curl_cffi.requests import AsyncSession  # optional: JA3/HTTP2 fingerprint of real Chrome
        async with AsyncSession() as s:
            r = await s.get(url, headers=self._headers(host, headers, as_json), impersonate="chrome124",
                            proxies={"https": self.proxy, "http": self.proxy} if self.proxy else None,
                            timeout=self.timeout)
            return FetchResult(url, r.status_code, r.text, dict(r.headers), 1, str(r.url))

    async def _tier2(self, url: str, host: str) -> FetchResult:
        """Real Chromium. Waits for the JS challenge to clear, then *harvests cookies* so later
        requests to this host drop back to cheap tier-0/1 with a valid clearance cookie."""
        from playwright.async_api import async_playwright  # optional
        async with self._pw_lock:
            if self._pw_ctx is None:
                self._pw = await async_playwright().start()
                browser = await self._pw.chromium.launch(headless=True, args=["--disable-blink-features=AutomationControlled"],
                                                         proxy={"server": self.proxy} if self.proxy else None)
                self._pw_ctx = await browser.new_context(user_agent=self._ua.setdefault(host, UAS[0]), locale="en-US",
                                                         timezone_id="America/New_York", viewport={"width": 1366, "height": 850})
                await self._pw_ctx.add_init_script("Object.defineProperty(navigator,'webdriver',{get:()=>undefined})")
        page = await self._pw_ctx.new_page()
        try:
            resp = await page.goto(url, wait_until="domcontentloaded", timeout=45000)
            for _ in range(20):  # up to ~20s for the interstitial to resolve itself
                title = (await page.title()).lower()
                if "just a moment" not in title and "attention required" not in title:
                    break
                await page.wait_for_timeout(1000)
            html = await page.content()
            status = resp.status if resp else 200
            if looks_blocked(status, {}, html):
                raise BlockedError(f"browser tier still challenged at {host}")
            self._cookies[host] = {c["name"]: c["value"] for c in await self._pw_ctx.cookies(url)}
            return FetchResult(url, status, html, dict(resp.headers) if resp else {}, 2, page.url)
        finally:
            await page.close()
