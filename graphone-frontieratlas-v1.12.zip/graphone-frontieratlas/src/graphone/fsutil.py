"""Atomic, UTF-8 file writes: write to a temp file in the same directory, then os.replace (never a half-written file)."""
import os
from pathlib import Path


def atomic_write(path: str | Path, text: str) -> None:
    p = Path(path)
    tmp = p.with_name(p.name + ".tmp")
    with open(tmp, "w", encoding="utf-8", newline="") as f:
        f.write(text)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, p)
