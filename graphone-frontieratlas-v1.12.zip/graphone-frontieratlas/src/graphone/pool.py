from __future__ import annotations
import asyncio
import logging
from typing import Awaitable, Callable, Iterable, TypeVar

T = TypeVar("T")
log = logging.getLogger("graphone.pool")


async def run_pool(items: Iterable[T], worker: Callable[[T], Awaitable[None]], *, concurrency: int,
                   done: Callable[[], bool] = lambda: False) -> None:
    """Bounded worker pool over a (possibly huge) iterable; stops early once done() is true.
    Worker exceptions are logged and isolated - one bad record never kills the run."""
    q: asyncio.Queue = asyncio.Queue(maxsize=concurrency * 2)

    async def producer():
        for it in items:
            if done():
                break
            await q.put(it)
        for _ in range(concurrency):
            await q.put(None)

    async def consume():
        while (it := await q.get()) is not None:
            if done():
                continue
            try:
                await worker(it)
            except asyncio.CancelledError:
                raise
            except Exception as e:  # noqa: BLE001
                log.warning("worker error: %s: %s", type(e).__name__, str(e)[:160])

    await asyncio.gather(producer(), *(consume() for _ in range(concurrency)))
