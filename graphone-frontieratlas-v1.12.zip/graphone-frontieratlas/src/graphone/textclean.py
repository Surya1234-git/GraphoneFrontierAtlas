"""URL canonicalisation, main-text extraction and semantic-density truncation."""
from __future__ import annotations
import re
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode
from bs4 import BeautifulSoup

_TRACK = re.compile(r"^(utm_|fbclid|gclid|mc_|ref$|ref_|igshid|spm)", re.I)


def canonical_url(url: str) -> str:
    p = urlsplit(url.strip())
    host = p.netloc.lower().removeprefix("www.")
    q = sorted((k, v) for k, v in parse_qsl(p.query, keep_blank_values=True) if not _TRACK.match(k))
    path = re.sub(r"/+$", "", p.path) or "/"
    return urlunsplit(("https", host, path, urlencode(q), ""))


def host_of(url: str) -> str:
    return urlsplit(url).netloc.lower().removeprefix("www.")


def normalize_ws(text: str) -> str:
    text = text.replace("\xa0", " ")
    text = re.sub(r"[ \t\r\f\v]+", " ", text)
    return re.sub(r"\n\s*\n+", "\n", text).strip()


def visible_text(html: str) -> str:
    soup = BeautifulSoup(html, "lxml")
    for t in soup(["script", "style", "noscript", "svg", "template"]):
        t.decompose()
    return normalize_ws(soup.get_text("\n"))


def extract_main_text(html: str) -> str:
    """Article body via trafilatura, falling back to <p> harvesting."""
    try:
        import trafilatura
        t = trafilatura.extract(html, include_comments=False, include_tables=False, favor_recall=True)
        if t and len(t) > 200:
            return normalize_ws(t)
    except Exception:  # pragma: no cover - extractor failures must never kill the crawl
        pass
    soup = BeautifulSoup(html, "lxml")
    for t in soup(["script", "style", "nav", "footer", "aside", "header", "form", "noscript"]):
        t.decompose()
    paras = [p.get_text(" ", strip=True) for p in soup.find_all("p")]
    return normalize_ws("\n".join(p for p in paras if len(p) > 40))


# ---------------------------------------------------------------- truncation
_BOILER = re.compile(r"(cookie|subscribe|newsletter|all rights reserved|privacy policy|sign up|follow us|"
                     r"advertisement|read more|share this|click here)", re.I)
_SENT = re.compile(r"(?<=[.!?])\s+(?=[A-Z0-9\"'])")
MARK = "\n[...]\n"


def estimate_tokens(text: str) -> int:
    return int(len(text) / 3.6) + 1


def _units(text: str, soft_max: int) -> list[str]:
    units: list[str] = []
    for para in (p.strip() for p in text.split("\n")):
        if not para:
            continue
        if len(para) > soft_max:
            units.extend(s for s in _SENT.split(para) if s.strip())
        else:
            units.append(para)
    return units


def _score(u: str, keywords: tuple[str, ...]) -> float:
    n = max(len(u), 1)
    digits = sum(c.isdigit() for c in u) / n
    caps = len(re.findall(r"\b[A-Z][a-z]+\b", u)) / max(len(u.split()), 1)
    kw = sum(1 for k in keywords if k.lower() in u.lower())
    pen = 2.0 if _BOILER.search(u) else 0.0
    length_bonus = 0.5 if 80 <= n <= 600 else 0.0
    return 4 * digits + 1.5 * caps + 2 * kw + length_bonus - pen


def smart_truncate(text: str, max_chars: int, keywords: tuple[str, ...] = ()) -> str:
    """Shrink `text` to <= max_chars keeping the most semantically dense material.

    Strategy: dedupe -> always keep the lede (35%) and the conclusion (10%) -> fill the
    remainder with the highest-density middle units (numbers, entities, keywords, no
    boilerplate) -> re-emit in original order with gap markers. Guaranteed len <= max_chars.
    """
    text = normalize_ws(text)
    if len(text) <= max_chars:
        return text
    seen: set[str] = set()
    units = [u for u in _units(text, max(300, max_chars // 6)) if not (u.lower() in seen or seen.add(u.lower()))]
    keep: set[int] = set()
    used = 0

    def take(i: int, budget: int) -> bool:
        nonlocal used
        if i in keep or used + len(units[i]) + 1 > budget:
            return False
        keep.add(i)
        used += len(units[i]) + 1
        return True

    head_b, tail_b = int(max_chars * 0.35), int(max_chars * 0.45)
    for i in range(len(units)):
        if not take(i, head_b):
            break
    for i in range(len(units) - 1, -1, -1):
        if i in keep or not take(i, tail_b):
            break
    mid = sorted((i for i in range(len(units)) if i not in keep), key=lambda i: -_score(units[i], keywords))
    budget = max_chars - len(MARK) * 6
    for i in mid:
        take(i, budget)
    out, prev = [], -1
    for i in sorted(keep):
        if prev != -1 and i != prev + 1:
            out.append(MARK.strip())
        out.append(units[i])
        prev = i
    res = "\n".join(out)
    return res[:max_chars]
