"""Canonical record schemas (v1.0). Every record carries source.url for traceability."""
from __future__ import annotations
from datetime import datetime, UTC
from enum import Enum
from typing import Any, Optional
from pydantic import BaseModel, Field, field_validator

SCHEMA_VERSION = "1.0"


def now_iso(dt: datetime | None = None) -> str:
    dt = (dt or datetime.now(UTC)).astimezone(UTC)
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


class PricingModel(str, Enum):
    FREE = "FREE"
    FREEMIUM = "FREEMIUM"
    PAID = "PAID"
    ENTERPRISE = "ENTERPRISE"


class Source(BaseModel):
    name: str
    url: str

    @field_validator("url")
    @classmethod
    def _http(cls, v: str) -> str:  # hard guarantee: no record without a real URL
        if not v.startswith(("http://", "https://")):
            raise ValueError("source.url must be an absolute http(s) URL")
        return v


class _Base(BaseModel):
    schemaVersion: str = SCHEMA_VERSION
    collectedAt: str = Field(default_factory=now_iso)


class StartupData(BaseModel):
    employeeCount: Optional[int] = None


class StartupContent(BaseModel):
    entityName: str
    rawName: str
    data: StartupData = StartupData()
    website: Optional[str] = None
    description: Optional[str] = None
    aiRelevant: bool = True
    batch: Optional[str] = None
    resolution: Optional[str] = None


class Startup(_Base):
    recordType: str = "STARTUP"
    source: Source
    content: StartupContent


class ProductContent(BaseModel):
    startupName: str
    productName: str
    pricingModel: PricingModel
    pricingEvidence: str          # verbatim snippet from the page -> auditability
    website: Optional[str] = None
    classifiedBy: str = "heuristic"
    description: Optional[str] = None
    githubStars: Optional[int] = None


class Product(_Base):
    recordType: str = "PRODUCT"
    source: Source
    content: ProductContent


class PaperContent(BaseModel):
    title: str
    authors: list[str]
    paper_url: str
    arxiv_id: str
    github_url: Optional[str] = None
    github_stars: Optional[int] = None
    github_stars_checked_at: Optional[str] = None
    github_discovery: Optional[str] = None
    published_date: str


class ResearchPaper(_Base):
    recordType: str = "RESEARCH_PAPER"
    source: Source
    content: PaperContent


class NewsContent(BaseModel):
    title: str
    url: str
    published_at: str
    date_method: str
    author: Optional[str] = None
    text: str
    companies_mentioned: list[str] = []


class News(_Base):
    recordType: str = "NEWS"
    source: Source
    content: NewsContent


class JobContent(BaseModel):
    company: str
    rawCompany: str
    title: str
    date: str
    date_method: str
    is_remote: bool
    role_family: str
    location: Optional[str] = None
    url: str
    description: Optional[str] = None


class Job(_Base):
    recordType: str = "JOB"
    source: Source
    content: JobContent


def dump(model: BaseModel) -> dict[str, Any]:
    return model.model_dump(mode="json")


def flatten(d: dict, prefix: str = "") -> dict[str, Any]:
    """Nested record -> flat row for spreadsheets."""
    out: dict[str, Any] = {}
    for k, v in d.items():
        key = f"{prefix}{k}"
        if isinstance(v, dict):
            out.update(flatten(v, key + "."))
        elif isinstance(v, list):
            out[key] = "; ".join(map(str, v))
        else:
            out[key] = v
    return out
