"""GraphOne / FrontierAtlas - AI ecosystem ingestion pipeline."""
__version__ = "1.0.0"
