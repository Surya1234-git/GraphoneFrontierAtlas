"""Deterministic entity resolution: messy string -> canonical entity.

Cascade (first hit wins, every decision is logged with method + score):
  1. domain      exact registrable-domain match against the seed (strongest signal)
  2. alias       exact match of the normalised string against canonical names / known aliases
  3. compact     match with whitespace/punctuation removed        ("Open AI" -> "openai")
  4. stripped    match after removing generic corporate/AI tokens ("Cohere AI", "Anysphere Inc")
  5. fuzzy       rapidfuzz ratio >= 93 (>= 88 for keys of 8+ chars, i.e. one typo) on compact keys, same first letter, *unique* best by a margin
  6. new         otherwise register a NEW canonical (cleaned display form) so later variants collapse into it
No randomness, no LLM: same input + same order => same output. Ambiguous fuzzy hits are NOT merged.
"""
from __future__ import annotations
import json
import re
import unicodedata
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Optional

try:
    from rapidfuzz import fuzz
    _ratio = fuzz.ratio
except ImportError:  # pragma: no cover
    from difflib import SequenceMatcher
    _ratio = lambda a, b: 100 * SequenceMatcher(None, a, b).ratio()

_LEGAL = r"(inc|incorporated|llc|l l c|ltd|limited|corp|corporation|co|company|gmbh|plc|pbc|sa|sas|ag|bv|b v|se|oy|ab|pte|pvt|opco|holdings)"
_GENERIC = {"ai", "labs", "lab", "technologies", "technology", "systems", "the", "global", "hq", "app", "io"}
FUZZY_MIN, FUZZY_MIN_LONG, FUZZY_MARGIN = 93, 88, 3   # long keys (>=8 chars) tolerate one typo


def norm(s: str) -> str:
    s = re.sub(r"\b(?:[A-Za-z]\.){2,}", lambda m: m.group(0).replace(".", ""), s)  # L.L.C. -> LLC, A.I. -> AI
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode().lower()
    s = s.replace("&", " and ")
    s = re.sub(r"\([^)]*\)", " ", s)
    s = re.sub(r"[^a-z0-9. ]+", " ", s)
    s = re.sub(r"\.(?=\s|$)", " ", s)
    toks = s.split()
    while toks and re.fullmatch(_LEGAL, toks[-1].strip(".")):
        toks.pop()
    return " ".join(toks)


def compact(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", norm(s))


def stripped(s: str) -> str:
    toks = [t for t in norm(s).replace(".", " ").split() if t not in _GENERIC]
    return "".join(toks)


def fold(k: str) -> str:
    """Visual-confusable folding: l/1/| -> i, 0 -> o (catches 'OpenAl', 'Anthr0pic')."""
    return k.translate(str.maketrans("l1|0", "iiio"))


# Hosts that serve *many* organisations' pages: a homepage on one of these says nothing about who owns it.
SHARED_HOSTS = {"github.com", "github.io", "gitlab.com", "bitbucket.org", "arxiv.org", "huggingface.co", "medium.com", "substack.com", "notion.so",
                "notion.site", "readthedocs.io", "readthedocs.org", "pypi.org", "npmjs.com", "youtube.com", "youtu.be", "linkedin.com", "twitter.com",
                "x.com", "discord.gg", "discord.com", "t.me", "vercel.app", "netlify.app", "herokuapp.com", "pages.dev", "web.app", "streamlit.app"}
_SLD = {"co", "com", "org", "net", "ac", "gov", "edu"}


def registrable(domain: str) -> str:
    """Registrable domain (eTLD+1 heuristic): developers.llamaindex.ai -> llamaindex.ai, x.bbc.co.uk -> bbc.co.uk."""
    d = re.sub(r"^https?://", "", (domain or "").lower()).split("/")[0].split(":")[0].removeprefix("www.")
    parts = d.split(".")
    if len(parts) >= 3 and parts[-2] in _SLD and len(parts[-1]) == 2:
        return ".".join(parts[-3:])
    return ".".join(parts[-2:]) if len(parts) >= 2 else d


@dataclass
class Resolution:
    raw: str
    canonical: str
    method: str
    score: float
    is_new: bool

    def row(self) -> dict:
        return asdict(self)


class EntityResolver:
    def __init__(self, seed_path: str | Path | None = None):
        self.canon: dict[str, str] = {}      # compact key -> canonical display
        self.alias: dict[str, str] = {}      # norm -> canonical
        self.strip: dict[str, str] = {}      # stripped key -> canonical
        self.domain: dict[str, str] = {}
        self.fold: dict[str, str] = {}
        self.log: list[Resolution] = []
        self.seed_names: set[str] = set()
        if seed_path:
            for e in json.loads(Path(seed_path).read_text(encoding="utf-8")):
                self._register(e["canonical"], e.get("aliases", []), e.get("domain"), seed=True)

    def _register(self, canonical: str, aliases=(), domain: Optional[str] = None, seed: bool = False) -> None:
        if seed:
            self.seed_names.add(canonical)
        for a in (canonical, *aliases):
            self.alias.setdefault(norm(a), canonical)
            self.canon.setdefault(compact(a), canonical)
            self.fold.setdefault(fold(compact(a)), canonical)
            if s := stripped(a):
                self.strip.setdefault(s, canonical)
        if domain:
            if (rd := registrable(domain)) and rd not in SHARED_HOSTS:
                self.domain.setdefault(rd, canonical)

    @staticmethod
    def display_clean(raw: str) -> str:
        s = re.sub(r"\s+", " ", raw).strip(" ,.-")
        toks = s.split()
        while len(toks) > 1 and re.fullmatch(_LEGAL, toks[-1].strip(".,").lower()):
            toks.pop()
        return " ".join(toks).rstrip(",")

    def resolve(self, raw: str, domain: Optional[str] = None, *, log: bool = True) -> Resolution:
        raw = (raw or "").strip()
        res = self._resolve(raw, domain)
        if log:
            self.log.append(res)
        return res

    def _resolve(self, raw: str, domain: Optional[str]) -> Resolution:
        if not norm(raw):
            return Resolution(raw, raw, "empty", 0, False)
        if domain and registrable(domain) not in SHARED_HOSTS and (c := self.domain.get(registrable(domain))):
            return Resolution(raw, c, "domain", 100, False)
        n = norm(raw)
        if c := self.alias.get(n):
            return Resolution(raw, c, "alias", 100, False)
        k = compact(raw)
        if c := self.canon.get(k):
            return Resolution(raw, c, "compact", 99, False)
        s = stripped(raw)
        if s and (c := self.strip.get(s)):
            return Resolution(raw, c, "stripped", 97, False)
        if len(k) >= 5 and (c := self.fold.get(fold(k))):
            return Resolution(raw, c, "confusable", 98, False)
        best = sorted(((_ratio(k, ck), ck) for ck in self.canon if ck[:1] == k[:1] and abs(len(ck) - len(k)) <= 3 and len(k) >= 5),
                      key=lambda t: (-t[0], t[1]))
        thr = FUZZY_MIN_LONG if len(k) >= 8 else FUZZY_MIN
        if best and best[0][0] >= thr:
            top_c = self.canon[best[0][1]]
            rivals = [b for b in best[1:] if self.canon[b[1]] != top_c]
            if not rivals or best[0][0] - rivals[0][0] >= FUZZY_MARGIN:
                return Resolution(raw, top_c, "fuzzy", round(best[0][0], 1), False)
        display = self.display_clean(raw)
        self._register(display, [raw], None)  # non-seed domains never merge orgs (order-dependent)
        return Resolution(raw, display, "new", 0, True)

    def write_log(self, path: str | Path) -> None:
        """Merge this run's rows into the existing log (dedupe on raw+canonical, newest wins) and write atomically as UTF-8."""
        import csv
        import io

        from .fsutil import atomic_write
        path = Path(path)
        merged: dict[tuple[str, str], dict] = {}
        if path.exists():
            with open(path, newline="", encoding="utf-8") as f:
                for r in csv.DictReader(f):
                    merged[(r["raw"], r["canonical"])] = r
        for res in self.log:
            row = res.row()
            merged[(row["raw"], row["canonical"])] = row
        buf = io.StringIO(newline="")
        w = csv.DictWriter(buf, ["raw", "canonical", "method", "score", "is_new"])
        w.writeheader()
        w.writerows(merged.values())
        atomic_write(path, buf.getvalue())