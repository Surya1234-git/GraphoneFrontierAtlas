from __future__ import annotations
import argparse
import asyncio
import json
import logging
import sys

from .config import Settings


class JsonFmt(logging.Formatter):
    def format(self, r):
        return json.dumps({"t": self.formatTime(r), "level": r.levelname, "logger": r.name, "msg": r.getMessage()})

ALL = {"startups", "products", "papers", "news", "jobs"}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser("graphone", description="GraphOne / FrontierAtlas ingestion pipeline")
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run", help="run phases")
    r.add_argument("phases", nargs="*", default=["all"], help="all | startups products papers news jobs")
    r.add_argument("--target", type=int, help="override 1000-record targets (e.g. 50 for a smoke test)")
    r.add_argument("--no-robots", action="store_true", help="do not consult robots.txt (not recommended)")
    r.add_argument("--json-logs", action="store_true", help="structured JSON log lines")
    r.add_argument("-v", "--verbose", action="store_true")
    sub.add_parser("export", help="rebuild xlsx/csv from JSONL")
    sub.add_parser("validate", help="run quality gates on existing output")
    a = ap.parse_args(argv)
    s = Settings.from_env()
    logging.basicConfig(level=logging.DEBUG if getattr(a, "verbose", False) else logging.INFO,
                        format="%(asctime)s %(levelname)-7s %(name)s | %(message)s", datefmt="%H:%M:%S")
    if getattr(a, "json_logs", False):
        for h in logging.getLogger().handlers:
            h.setFormatter(JsonFmt())
    from . import export as ex
    if a.cmd == "export":
        print(json.dumps(ex.export(s.out_dir), indent=2))
        return 0
    if a.cmd == "validate":
        rep = ex.validate(s.out_dir)
        print(json.dumps(rep, indent=2))
        return 1 if rep["problems"] else 0
    phases = ALL if "all" in a.phases else set(a.phases)
    if bad := phases - ALL:
        ap.error(f"unknown phase(s): {bad}")
    if a.no_robots:
        s.respect_robots = False
    from . import pipeline
    targets = {k: a.target for k in ("startups", "products", "papers")} if a.target else None
    rep = asyncio.run(pipeline.run(phases, s, targets))
    print(json.dumps(rep, indent=2))
    return 1 if rep["validation"]["problems"] or rep["shortfalls"] else 0


if __name__ == "__main__":
    sys.exit(main())
