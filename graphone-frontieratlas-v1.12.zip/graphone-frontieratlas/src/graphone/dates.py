"""Publication-date extraction & normalisation (relative dates, meta tags, JSON-LD, URL, epochs)."""
from __future__ import annotations
import json
import re
from dataclasses import dataclass
from datetime import datetime, timedelta, UTC
from typing import Any, Optional
from bs4 import BeautifulSoup
from dateutil import parser as dparser

UTC = UTC
_TZ = {"EST": -5, "EDT": -4, "CST": -6, "CDT": -5, "MST": -7, "MDT": -6, "PST": -8, "PDT": -7,
       "IST": 5.5, "BST": 1, "CET": 1, "CEST": 2, "JST": 9, "GMT": 0, "UTC": 0, "Z": 0}
TZINFOS = {k: int(v * 3600) for k, v in _TZ.items()}

_UNIT = {"s": 1, "sec": 1, "secs": 1, "second": 1, "seconds": 1,
         "m": 60, "min": 60, "mins": 60, "minute": 60, "minutes": 60,
         "h": 3600, "hr": 3600, "hrs": 3600, "hour": 3600, "hours": 3600,
         "d": 86400, "day": 86400, "days": 86400,
         "w": 604800, "wk": 604800, "wks": 604800, "week": 604800, "weeks": 604800,
         "mo": 2592000, "month": 2592000, "months": 2592000,
         "y": 31536000, "yr": 31536000, "yrs": 31536000, "year": 31536000, "years": 31536000}
_REL = re.compile(r"\b(?P<n>\d+(?:\.\d+)?|an?|one)\s*(?P<u>[a-z]+)\s*(?P<ago>ago)?\b", re.I)


def parse_relative(text: str, now: datetime) -> Optional[datetime]:
    t = text.strip().lower()
    if re.search(r"\b(just now|moments? ago|a few seconds ago|less than a minute)\b", t):
        return now
    if re.fullmatch(r"(posted\s+|published\s+)?today", t):
        return now
    if re.fullmatch(r"(posted\s+|published\s+)?yesterday", t):
        return now - timedelta(days=1)
    m = _REL.search(t)
    if not m or m["u"] not in _UNIT or not m["ago"]:
        return None  # require the explicit word "ago": avoids misreading "2 min read" etc.
    n = 1.0 if m["n"].lower() in ("a", "an", "one") else float(m["n"])
    return now - timedelta(seconds=n * _UNIT[m["u"]])


def parse_datetime(value: Any, now: Optional[datetime] = None) -> Optional[datetime]:
    """Anything date-like -> aware UTC datetime, or None. Never raises."""
    now = now or datetime.now(UTC)
    if value is None or value == "":
        return None
    try:
        if isinstance(value, datetime):
            dt = value if value.tzinfo else value.replace(tzinfo=UTC)
        elif isinstance(value, (int, float)) or (isinstance(value, str) and re.fullmatch(r"\d{9,13}(\.\d+)?", value.strip())):
            v = float(value)
            dt = datetime.fromtimestamp(v / 1000 if v > 1e11 else v, UTC)
        else:
            s = str(value).strip()
            dt = parse_relative(s, now)
            if dt is None:
                s = re.sub(r"^(published|posted|updated|date|on)\s*[:\-]?\s*", "", s, flags=re.I)
                d = dparser.parse(s, fuzzy=False, tzinfos=TZINFOS, default=datetime(now.year, now.month, now.day, tzinfo=UTC))
                dt = d if d.tzinfo else d.replace(tzinfo=UTC)
        dt = dt.astimezone(UTC)
    except (ValueError, OverflowError, OSError, dparser.ParserError):
        return None
    if dt.year < 2000 or dt > now + timedelta(days=2):
        return None  # implausible -> treat as missing, never guess
    return dt


@dataclass
class DateResult:
    dt: Optional[datetime]
    method: str
    raw: Optional[str] = None


_META_KEYS = ["article:published_time", "og:article:published_time", "datepublished", "pubdate", "publishdate",
              "publish_date", "date", "dc.date", "dc.date.issued", "dcterms.created", "parsely-pub-date",
              "sailthru.date", "cxenseparse:recs:publishtime", "article.published", "timestamp"]
_URL_DATE = re.compile(r"/(20\d{2})[/-](0?[1-9]|1[0-2])[/-](0?[1-9]|[12]\d|3[01])(?:/|-|$)")


def _jsonld_dates(soup: BeautifulSoup) -> list[str]:
    out: list[str] = []

    def walk(o: Any) -> None:
        if isinstance(o, dict):
            for k in ("datePublished", "dateCreated", "uploadDate"):
                if isinstance(o.get(k), str):
                    out.append(o[k])
            for v in o.values():
                walk(v)
        elif isinstance(o, list):
            for v in o:
                walk(v)

    for s in soup.find_all("script", type="application/ld+json"):
        try:
            walk(json.loads(s.string or s.get_text() or ""))
        except (ValueError, TypeError):
            continue
    return out


def extract_published(html: str, url: str = "", now: Optional[datetime] = None,
                      last_modified: Optional[str] = None) -> DateResult:
    """Priority: JSON-LD > meta tags > <time> > visible relative text > URL path > Last-Modified."""
    now = now or datetime.now(UTC)
    soup = BeautifulSoup(html or "", "lxml")
    for raw in _jsonld_dates(soup):
        if dt := parse_datetime(raw, now):
            return DateResult(dt, "jsonld", raw)
    metas = {}
    for m in soup.find_all("meta"):
        k = (m.get("property") or m.get("name") or m.get("itemprop") or "").lower()
        if k and m.get("content"):
            metas.setdefault(k, m["content"])
    for k in _META_KEYS:
        if k in metas and (dt := parse_datetime(metas[k], now)):
            return DateResult(dt, f"meta:{k}", metas[k])
    fallback = None
    for t in soup.find_all("time"):
        raw = t.get("datetime") or t.get_text(strip=True)
        dt = parse_datetime(raw, now) if raw else None
        if not dt:
            continue
        ctx = " ".join(t.get("class", []) + [t.get("itemprop", "")] + [" ".join(p.get("class", [])) for p in t.parents if hasattr(p, "get")][:3]).lower()
        if any(w in ctx for w in ("publish", "posted", "date", "entry", "byline")):
            return DateResult(dt, "time-tag", raw)
        fallback = fallback or DateResult(dt, "time-tag-first", raw)
    if fallback:
        return fallback
    text = soup.get_text(" ", strip=True)[:6000]
    if m := re.search(r"(?:published|posted|updated)\s*(?:on|:)?\s*([A-Za-z0-9,:\s\-/]{3,40}?\bago\b)", text, re.I):
        if dt := parse_relative(m.group(1), now):
            return DateResult(dt, "relative-text", m.group(1))
    if m := _URL_DATE.search(url or ""):
        try:
            return DateResult(datetime(int(m[1]), int(m[2]), int(m[3]), tzinfo=UTC), "url-path", m.group(0))
        except ValueError:
            pass
    if last_modified and (dt := parse_datetime(last_modified, now)):
        return DateResult(dt, "http-last-modified", last_modified)
    return DateResult(None, "none")


def is_fresh(dt: Optional[datetime], now: Optional[datetime] = None, hours: int = 24,
             skew: timedelta = timedelta(minutes=10)) -> bool:
    now = now or datetime.now(UTC)
    return dt is not None and now - timedelta(hours=hours) <= dt <= now + skew
