"""Phase I - Startups. Source: Y Combinator company directory via the open `yc-oss` JSON mirror
(one static file, thousands of structured rows -> bulk acquisition without HTML scraping).
Every record's source.url is the company's YC page."""
from __future__ import annotations
import logging
import re
from ..context import Ctx
from ..models import Startup, Source, StartupContent, StartupData, dump
from ..state import fingerprint

log = logging.getLogger("graphone.startups")
YC_ALL = "https://yc-oss.github.io/api/companies/all.json"
YC_MIRRORS = [YC_ALL, "https://raw.githubusercontent.com/yc-oss/api/main/companies/all.json",
              "https://raw.githubusercontent.com/yc-oss/api/gh-pages/companies/all.json"]  # same data, different host
_AI = re.compile(r"\b(AI|A\.I\.|artificial intelligence|machine learning|ML|LLMs?|GPT|generative|foundation models?|"
                 r"deep learning|computer vision|NLP|AI agents?|agentic|copilot)\b", re.I)


def is_ai(c: dict) -> bool:
    """Strict: AI must be a headline attribute (tags / one-liner) or a recurring theme of the long description.
    A single passing 'AI-powered' in a payroll company's blurb does not qualify."""
    tags = " ".join(map(str, (c.get("tags") or []) + (c.get("industries") or []) + [c.get("subindustry") or ""]))
    if _AI.search(tags) or _AI.search(c.get("one_liner") or ""):
        return True
    return len(_AI.findall((c.get("long_description") or "")[:900])) >= 5


async def fetch_companies(ctx: Ctx) -> list[dict]:
    from ..fetcher import FetchError
    for url in YC_MIRRORS:  # first healthy mirror wins; a blocked host never kills the phase
        try:
            r = await ctx.fetcher.get(url, as_json=True, escalate=False)
            data = r.json() if r.status == 200 else None
        except (FetchError, ValueError) as e:
            log.warning("yc mirror failed %s: %s", url, str(e)[:80])
            continue
        if isinstance(data, list) and data:
            log.info("yc directory rows=%d via %s", len(data), url)
            return data
    return []


def to_record(ctx: Ctx, c: dict, log_resolution: bool = True) -> dict | None:
    name, url = (c.get("name") or "").strip(), c.get("url") or ""
    if not name or not url.startswith("http"):
        return None
    res = ctx.resolver.resolve(name, c.get("website"), log=log_resolution)
    ts = c.get("team_size")
    rec = Startup(
        source=Source(name="Y Combinator", url=url),
        content=StartupContent(
            entityName=res.canonical, rawName=name,
            data=StartupData(employeeCount=int(ts) if isinstance(ts, (int, float)) and ts > 0 else None),
            website=c.get("website") or None, description=c.get("one_liner") or None,
            aiRelevant=is_ai(c), batch=c.get("batch") or None, resolution=res.method))
    return dump(rec)


async def run(ctx: Ctx, target: int, companies: list[dict] | None = None) -> list[dict]:
    """Returns the startup *records* written (dicts) so downstream phases can reuse them."""
    companies = companies if companies is not None else await fetch_companies(ctx)
    companies = sorted(companies, key=lambda c: (not is_ai(c), -(c.get("team_size") or 0)))  # AI-relevant first
    n, out = 0, []
    for c in companies:
        if n >= target:
            break
        rec = to_record(ctx, c)
        if rec and ctx.sink.write("startups", rec, key=fingerprint(rec["content"]["entityName"])):
            n += 1
            out.append(rec)
    log.info("startups written=%d", n)
    return out


def candidate_records(ctx: Ctx, companies: list[dict]):
    """Wider pool for the Products phase (many sites have no public pricing page, so we must
    examine more companies than we need products). Does not write to the Startups tab."""
    for c in companies:
        if c.get("website") and (rec := to_record(ctx, c, log_resolution=False)):
            yield rec
