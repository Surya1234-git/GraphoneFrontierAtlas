"""Phase II - AI news. 5 sources via RSS/Atom discovery, then full-text crawl of each article.

Date logic: feed date -> cross-checked against the article page (JSON-LD/meta/<time>/relative text/URL)
-> Last-Modified -> first-seen heuristic (only after a baseline run). 24h window is enforced on the
*normalised UTC* date; nothing undated is accepted without the heuristic."""
from __future__ import annotations
import logging
import re
from datetime import datetime, timedelta, UTC

import feedparser

from ..context import Ctx
from ..dates import extract_published, parse_datetime
from ..fetcher import FetchError
from ..models import News, NewsContent, Source, dump
from ..pool import run_pool
from ..state import title_key, url_key
from ..textclean import canonical_url, extract_main_text

log = logging.getLogger("graphone.news")

NEWS_SOURCES = [
    ("TechCrunch AI", "https://techcrunch.com/category/artificial-intelligence/feed/"),
    ("VentureBeat AI", "https://venturebeat.com/category/ai/feed/"),
    ("The Verge AI", "https://www.theverge.com/rss/ai-artificial-intelligence/index.xml"),
    ("MIT Technology Review AI", "https://www.technologyreview.com/topic/artificial-intelligence/feed"),
    ("Hugging Face Blog", "https://huggingface.co/blog/feed.xml"),
]


def entry_date(e) -> tuple[datetime | None, str]:
    for k in ("published", "updated", "created"):
        if e.get(k) and (dt := parse_datetime(e[k])):
            return dt, f"feed:{k}"
    for k in ("published_parsed", "updated_parsed"):
        if e.get(k):
            return datetime(*e[k][:6], tzinfo=UTC), f"feed:{k}"
    return None, "none"


async def process_entry(ctx: Ctx, source: str, e, now: datetime) -> None:
    url = e.get("link")
    title = re.sub(r"\s+", " ", e.get("title", "")).strip()
    if not url or not title:
        return
    ukey = url_key(url)
    dt, method = entry_date(e)
    if dt is not None and not (now - timedelta(hours=ctx.settings.freshness_hours) <= dt):
        return  # cheap pre-filter: stale per feed -> never download the page
    html, text = "", ""
    try:
        r = await ctx.fetcher.get(url)
        if r.status == 200:
            html = r.text
            text = extract_main_text(html)
            page = extract_published(html, url, now, r.headers.get("Last-Modified"))
            if page.dt and (dt is None or method.startswith("feed:updated")):  # prefer true publish date over 'updated'
                dt, method = page.dt, page.method
    except FetchError as ex:
        log.info("article fetch failed %s: %s", url, ex)
    if not text:
        text = re.sub(r"<[^>]+>", " ", (e.get("content") or [{}])[0].get("value", "") or e.get("summary", ""))
        text = re.sub(r"\s+", " ", text).strip()
    if len(text) < 200:
        return
    ok, why = await ctx.gate.decide(f"news:{source}", ukey, dt, now)
    if not ok:
        return
    if not await ctx.state.claim("news-title", title_key(source, title)):
        await ctx.state.release("fresh", ukey)  # same story re-posted under another URL
        return
    method = method if dt else why
    pub = dt or now
    mentions: list[str] = []
    if ctx.llm.enabled:
        ex = await ctx.llm.extract_long(task="List AI startups/companies explicitly named in the article.",
                                   fields={"companies": "JSON array of company names exactly as written"},
                                   text=text, url=url, required=(), keywords=("raises", "funding", "launch", "acquire"))
        mentions = [ctx.resolver.resolve(c, log=True).canonical for c in (ex.data.get("companies", []) if ex else [])]
    rec = News(source=Source(name=source, url=url),
               content=NewsContent(title=title, url=canonical_url(url), published_at=pub.strftime("%Y-%m-%dT%H:%M:%SZ"),
                                   date_method=method,
                                   author=e.get("author"), text=text, companies_mentioned=sorted(set(mentions))))
    if ctx.sink.write("news", dump(rec), key=ukey):
        await ctx.state.commit("fresh", ukey)
        await ctx.state.commit("news-title", title_key(source, title))


async def run_source(ctx: Ctx, name: str, feed_url: str, now: datetime) -> None:
    try:
        r = await ctx.fetcher.get(feed_url, robots=False)
    except FetchError as e:
        log.warning("feed unavailable %s: %s", name, e)
        return
    entries = feedparser.parse(r.text).entries
    log.info("news source=%s entries=%d", name, len(entries))
    await run_pool(entries, lambda e: process_entry(ctx, name, e, now), concurrency=8)
    await ctx.state.set_baselined(f"news:{name}")


async def run(ctx: Ctx) -> None:
    now = datetime.now(UTC)
    import asyncio
    await asyncio.gather(*(run_source(ctx, n, u, now) for n, u in NEWS_SOURCES))
