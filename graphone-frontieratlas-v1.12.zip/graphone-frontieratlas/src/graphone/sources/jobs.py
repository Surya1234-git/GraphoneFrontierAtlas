"""Phase II - AI jobs. 5 job boards, all via public JSON/RSS endpoints (fast, stable, ToS-friendly):
RemoteOK, Remotive, We Work Remotely, Greenhouse boards (AI companies), Lever postings (AI companies).
Date provenance is recorded per row (date_method): e.g. Greenhouse exposes `first_published` (true) or
`updated_at` (weaker) and we label which one we used."""
from __future__ import annotations
import asyncio
import logging
import re
from datetime import datetime, UTC
from html import unescape

import feedparser

from ..context import Ctx
from ..dates import parse_datetime
from ..fetcher import FetchError
from ..models import Job, JobContent, Source, dump
from ..state import fingerprint
from ..textclean import canonical_url

log = logging.getLogger("graphone.jobs")
GREENHOUSE = ["anthropic", "scaleai", "databricks", "huggingface", "togetherai", "runwayml", "cohere"]   # board tokens (404s are skipped)
LEVER = ["mistral", "palantir", "wealthfront"]
AI_RE = re.compile(r"\b(AI|A\.I\.|ML|machine learning|LLM|NLP|deep learning|research scientist|generative|data scientist|computer vision|prompt|MLOps)\b", re.I)

ROLE_RULES = [
    ("Research", r"research (scientist|engineer)|\bresearcher\b|applied scientist|scientist"),
    ("Data", r"data (engineer|analyst|scien)|analytics|machine learning|\bml\b|mlops"),
    ("Engineering", r"engineer|developer|software|devops|sre|backend|frontend|full[- ]?stack|architect|infrastructure|security"),
    ("Product", r"product (manager|lead|owner)|\bpm\b|program manager"),
    ("Design", r"designer|ux|ui\b|creative"),
    ("Sales & GTM", r"sales|account (executive|manager)|solutions|customer success|partnership|business development|gtm"),
    ("Marketing", r"marketing|content|brand|growth|community|devrel|developer advocate"),
    ("Operations", r"operations|finance|legal|recruit|people|hr\b|talent|office|admin|counsel|accounting"),
]


def role_family(title: str) -> str:
    t = title.lower()
    for fam, pat in ROLE_RULES:
        if re.search(pat, t):
            return fam
    return "Other"


def is_remote(location: str | None, text: str = "", board_remote: bool = False) -> bool:
    loc = (location or "").lower()
    if re.search(r"\bremote\b|anywhere|work from home|distributed", loc):
        return True
    if re.search(r"\bhybrid\b|on-?site", loc):
        return False
    return board_remote or bool(re.search(r"\b(fully|100%) remote\b", text.lower()))


def strip_html(s: str) -> str:
    return re.sub(r"\s+", " ", unescape(re.sub(r"<[^>]+>", " ", s or ""))).strip()


async def emit(ctx: Ctx, board: str, now: datetime, *, company: str, title: str, url: str, dt, method: str,
               location: str | None, desc: str, board_remote: bool = False, ai_only: bool = True) -> None:
    if not (company and title and url.startswith("http")):
        return
    if ai_only and not AI_RE.search(title + " " + desc[:1500]):
        return
    key = fingerprint("job", canonical_url(url))
    ok, why = await ctx.gate.decide(f"jobs:{board}", key, dt, now)
    if not ok:
        return
    res = ctx.resolver.resolve(company)
    rec = Job(source=Source(name=board, url=url),
              content=JobContent(company=res.canonical, rawCompany=company, title=title,
                                 date=(dt or now).strftime("%Y-%m-%dT%H:%M:%SZ"),
                                 date_method=method if dt else "first-seen-heuristic",
                                 is_remote=is_remote(location, desc, board_remote), role_family=role_family(title),
                                 location=location, url=url, description=desc[:1500] or None))
    if ctx.sink.write("jobs", dump(rec), key=key):
        await ctx.state.commit("fresh", key)


async def remoteok(ctx, now):
    data = await ctx.fetcher.get_json("https://remoteok.com/api", robots=False)
    for j in (x for x in data if isinstance(x, dict) and x.get("position")):
        await emit(ctx, "RemoteOK", now, company=j.get("company", ""), title=j["position"], url=j.get("url", ""),
                   dt=parse_datetime(j.get("epoch") or j.get("date"), now), method="api:epoch",
                   location=j.get("location"), desc=strip_html(j.get("description", "")), board_remote=True)


async def remotive(ctx, now):
    for cat in ("software-dev", "data"):
        d = await ctx.fetcher.get_json(f"https://remotive.com/api/remote-jobs?category={cat}&limit=200", robots=False)
        for j in d.get("jobs", []):
            await emit(ctx, "Remotive", now, company=j.get("company_name", ""), title=j.get("title", ""), url=j.get("url", ""),
                       dt=parse_datetime(j.get("publication_date"), now), method="api:publication_date",
                       location=j.get("candidate_required_location"), desc=strip_html(j.get("description", "")), board_remote=True)


async def weworkremotely(ctx, now):
    for cat in ("remote-programming-jobs", "remote-data-jobs", "remote-devops-sysadmin-jobs"):
        try:
            r = await ctx.fetcher.get(f"https://weworkremotely.com/categories/{cat}.rss", robots=False)
        except FetchError:
            continue
        for e in feedparser.parse(r.text).entries:
            company, _, title = e.get("title", "").partition(": ")
            await emit(ctx, "We Work Remotely", now, company=company, title=title or company, url=e.get("link", ""),
                       dt=parse_datetime(e.get("published"), now), method="rss:pubDate", location=e.get("region"),
                       desc=strip_html(e.get("summary", "")), board_remote=True)


async def greenhouse(ctx, now):
    async def one(tok):
        try:
            d = await ctx.fetcher.get_json(f"https://boards-api.greenhouse.io/v1/boards/{tok}/jobs?content=true", robots=False)
        except FetchError:
            return
        for j in d.get("jobs", []):
            fp = j.get("first_published")
            await emit(ctx, "Greenhouse", now, company=j.get("company_name") or tok, title=j.get("title", ""), url=j.get("absolute_url", ""),
                       dt=parse_datetime(fp, now) if fp else None, method="api:first_published",  # updated_at is NOT a publish date -> heuristic path
                       location=(j.get("location") or {}).get("name"), desc=strip_html(j.get("content", "")), ai_only=False)
    await asyncio.gather(*(one(t) for t in GREENHOUSE))


async def lever(ctx, now):
    async def one(co):
        try:
            d = await ctx.fetcher.get_json(f"https://api.lever.co/v0/postings/{co}?mode=json", robots=False)
        except FetchError:
            return
        for j in d if isinstance(d, list) else []:
            cat = j.get("categories") or {}
            await emit(ctx, "Lever", now, company=co, title=j.get("text", ""), url=j.get("hostedUrl", ""),
                       dt=parse_datetime(j.get("createdAt"), now), method="api:createdAt", location=cat.get("location"),
                       desc=j.get("descriptionPlain", ""), board_remote=(j.get("workplaceType") == "remote"), ai_only=False)
    await asyncio.gather(*(one(c) for c in LEVER))


BOARDS = {"RemoteOK": remoteok, "Remotive": remotive, "We Work Remotely": weworkremotely,
          "Greenhouse": greenhouse, "Lever": lever}


async def run(ctx: Ctx) -> None:
    now = datetime.now(UTC)

    async def guarded(name, fn):
        try:
            await fn(ctx, now)
            await ctx.state.set_baselined(f"jobs:{name}")
        except Exception as e:  # one dead board must not sink the others
            log.warning("board %s failed: %s: %s", name, type(e).__name__, str(e)[:120])
    await asyncio.gather(*(guarded(n, f) for n, f in BOARDS.items()))
    log.info("jobs written=%d", ctx.sink.counts.get("jobs", 0))
