"""Phase I - Research papers with live GitHub metrics.

Discovery (arXiv Atom API, paged, 3s politeness)  ->  repo linking (4 tiers)  ->  live stars (GitHub REST).
Repo linking tiers: (1) Hugging Face papers API (successor of Papers-with-Code linking), (2) legacy
paperswithcode API (follows redirects; tolerated if gone), (3) github.com URL in arXiv abstract/comment,
(4) none -> github_url stays null (never guessed).
Stars are *always* read live from api.github.com and stamped with github_stars_checked_at."""
from __future__ import annotations
import asyncio
import logging
import re
import time
from datetime import datetime, UTC
from typing import Optional

import feedparser

from ..context import Ctx
from ..dates import parse_datetime
from ..fetcher import FetchError
from ..models import PaperContent, ResearchPaper, Source, dump, now_iso
from ..pool import run_pool
from ..state import fingerprint

log = logging.getLogger("graphone.papers")
ARXIV = "https://export.arxiv.org/api/query"
GH_RE = re.compile(r"https?://(?:www\.)?github\.com/([A-Za-z0-9_.-]+)/([A-Za-z0-9_.-]+)", re.I)
GH_SKIP = {"features", "orgs", "topics", "sponsors", "marketplace", "about", "apps", "settings", "login", "pricing"}
CATS = ["cs.LG", "cs.CL", "cs.CV", "cs.AI", "stat.ML"]


def parse_repo(text: str) -> Optional[tuple[str, str]]:
    for m in GH_RE.finditer(text or ""):
        owner = m.group(1)
        repo = re.sub(r"\.git$", "", re.sub(r"[.,;:)\]]+$", "", m.group(2)))
        if owner.lower() not in GH_SKIP and repo:
            return owner, repo
    return None


def arxiv_id(entry_id: str) -> str:
    return re.sub(r"v\d+$", "", entry_id.rsplit("/abs/", 1)[-1])


def parse_arxiv_feed(xml: str) -> list[dict]:
    out = []
    for e in feedparser.parse(xml).entries:
        aid = arxiv_id(e.get("id", ""))
        if not aid:
            continue
        out.append({"id": aid, "title": re.sub(r"\s+", " ", e.get("title", "")).strip(),
                    "authors": [a.get("name", "").strip() for a in e.get("authors", []) if a.get("name")],
                    "published": e.get("published", ""), "summary": e.get("summary", ""),
                    "comment": e.get("arxiv_comment", "") or "", "url": f"https://arxiv.org/abs/{aid}"})
    return out


def parse_hf_daily(items) -> list[dict]:
    """Hugging Face daily-papers payload -> the same dict shape as parse_arxiv_feed (+ optional `repo`)."""
    out = []
    for it in items if isinstance(items, list) else []:
        pp = it.get("paper") or {}
        names = [a.get("name", "").strip() for a in pp.get("authors") or [] if a.get("name") and not a.get("hidden")]
        if pp.get("id") and pp.get("title") and names:
            out.append({"id": pp["id"], "title": re.sub(r"\s+", " ", pp["title"]).strip(), "authors": names,
                        "published": pp.get("publishedAt") or it.get("publishedAt") or "", "summary": pp.get("summary") or "",
                        "comment": "", "url": f"https://arxiv.org/abs/{pp['id']}", "repo": pp.get("githubRepo")})
    return out


async def iter_hf_daily(ctx: Ctx, want: int, days: int = 120):
    from datetime import timedelta
    seen: set[str] = set()
    for i in range(days):
        d = (datetime.now(UTC) - timedelta(days=i)).strftime("%Y-%m-%d")
        try:
            r = await ctx.fetcher.get(f"https://huggingface.co/api/daily_papers?date={d}", as_json=True, escalate=False)
            batch = parse_hf_daily(r.json()) if r.status == 200 else []
        except (FetchError, ValueError):
            continue
        for p in batch:
            if p["id"] not in seen:
                seen.add(p["id"])
                yield p
        if len(seen) >= want * 2:
            return


class GitHub:
    """Stars client with shared cache and rate-limit awareness (sleeps until x-ratelimit-reset)."""

    def __init__(self, ctx: Ctx):
        self.ctx, self.cache = ctx, {}
        self.pause_until = 0.0
        self.headers = {"Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28"}
        if ctx.settings.github_token:
            self.headers["Authorization"] = f"Bearer {ctx.settings.github_token}"

    async def stars(self, owner: str, repo: str) -> Optional[int]:
        k = f"{owner}/{repo}".lower()
        if k in self.cache:
            return self.cache[k]
        if (w := self.pause_until - time.time()) > 0:
            await asyncio.sleep(min(w, 900))
        try:
            r = await self.ctx.fetcher.get(f"https://api.github.com/repos/{owner}/{repo}", as_json=True,
                                           escalate=False, headers=self.headers)
        except FetchError as e:
            log.warning("github fail %s: %s", k, e)
            return None
        if r.status == 403 and r.headers.get("x-ratelimit-remaining") == "0":
            self.pause_until = float(r.headers.get("x-ratelimit-reset", time.time() + 60))
            log.warning("github rate-limited; pausing until %s", self.pause_until)
            return await self.stars(owner, repo)
        val = r.json().get("stargazers_count") if r.status == 200 else None
        self.cache[k] = val if isinstance(val, int) else None
        return self.cache[k]


async def discover_repo(ctx: Ctx, p: dict) -> tuple[Optional[tuple[str, str]], Optional[str]]:
    if p.get("repo") and (repo := parse_repo(str(p["repo"]))):  # repo already published alongside the paper
        return repo, "huggingface-daily"
    try:  # tier 1: Hugging Face papers API
        r = await ctx.fetcher.get(f"https://huggingface.co/api/papers/{p['id']}", as_json=True, escalate=False)
        if r.status == 200 and (repo := parse_repo(str(r.json().get("githubRepo") or ""))):
            return repo, "huggingface-papers"
    except (FetchError, ValueError):
        pass
    try:  # tier 2: legacy Papers-with-Code API (may redirect / be gone)
        r = await ctx.fetcher.get(f"https://paperswithcode.com/api/v1/papers/?arxiv_id={p['id']}", as_json=True, escalate=False)
        if r.status == 200 and r.text.lstrip().startswith("{"):
            res = r.json().get("results") or []
            if res:
                rr = await ctx.fetcher.get(f"https://paperswithcode.com/api/v1/papers/{res[0]['id']}/repositories/", as_json=True, escalate=False)
                items = (rr.json().get("results") or []) if rr.status == 200 else []
                for it in sorted(items, key=lambda x: -(x.get("stars") or 0)):
                    if repo := parse_repo(it.get("url", "")):
                        return repo, "paperswithcode"
    except (FetchError, ValueError):
        pass
    if repo := parse_repo(p["summary"] + " " + p["comment"]):  # tier 3: author-provided link
        return repo, "arxiv-abstract"
    return None, None


async def build_record(ctx: Ctx, gh: GitHub, p: dict) -> None:
    dt = parse_datetime(p["published"])
    if not (p["title"] and p["authors"] and dt):
        return
    key = fingerprint("paper", p["id"])
    if not await ctx.state.claim("paper", key):
        return
    try:
        repo, how = await discover_repo(ctx, p)
        stars = checked = None
        gh_url = None
        if repo:
            gh_url = f"https://github.com/{repo[0]}/{repo[1]}"
            stars = await gh.stars(*repo)
            checked = now_iso() if stars is not None else None
        rec = ResearchPaper(source=Source(name="arXiv", url=p["url"]),
                            content=PaperContent(title=p["title"], authors=p["authors"], paper_url=p["url"], arxiv_id=p["id"],
                                                 github_url=gh_url, github_stars=stars, github_stars_checked_at=checked,
                                                 github_discovery=how, published_date=now_iso(dt)))
        if stars is not None:  # append-only snapshot -> star momentum across runs
            ctx.sink.write("star_history", {"arxiv_id": p["id"], "repo": gh_url, "stars": stars, "at": checked})
        ctx.sink.write("papers", dump(rec), key=key)
        await ctx.state.commit("paper", key)
    except Exception:
        await ctx.state.release("paper", key)
        raise


async def iter_arxiv(ctx: Ctx, want: int, page: int = 100):
    """Yield papers, preferring those whose abstract mentions github (-> higher repo hit-rate)."""
    seen: set[str] = set()
    for abs_filter in ("AND abs:github", ""):
        for cat in CATS:
            start = 0
            while start < 2000:
                q = f"search_query=cat:{cat}{('+' + abs_filter.replace(' ', '+')) if abs_filter else ''}" \
                    f"&start={start}&max_results={page}&sortBy=submittedDate&sortOrder=descending"
                try:
                    r = await ctx.fetcher.get(f"{ARXIV}?{q}", robots=False, escalate=False)
                except FetchError as e:
                    log.warning("arxiv page failed: %s", e)
                    break
                batch = parse_arxiv_feed(r.text) if r.status == 200 else []
                if not batch:
                    break
                for p in batch:
                    if p["id"] not in seen:
                        seen.add(p["id"])
                        yield p
                start += page
                if len(seen) >= want * 2:
                    return


async def run(ctx: Ctx, target: int) -> None:
    gh = GitHub(ctx)
    ctx.sink.counts.setdefault("papers", 0)
    papers = [p async for p in iter_hf_daily(ctx, target)]
    papers.sort(key=lambda p: not p.get("repo"))  # repo-linked papers first -> more GitHub metrics
    have = {p["id"] for p in papers}
    if len(papers) < target * 2:
        papers += [p async for p in iter_arxiv(ctx, target) if p["id"] not in have]
    log.info("arxiv candidates=%d", len(papers))
    await run_pool(papers, lambda p: build_record(ctx, gh, p), concurrency=min(ctx.settings.concurrency, 25),
                   done=lambda: ctx.sink.counts["papers"] >= target)
    log.info("papers written=%d", ctx.sink.counts["papers"])
