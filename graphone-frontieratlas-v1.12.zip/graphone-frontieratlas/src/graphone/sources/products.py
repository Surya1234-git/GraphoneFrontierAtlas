"""Phase I - Products. For each startup website we locate the pricing page and classify the
pricing model. A record is emitted ONLY with a verbatim evidence snippet from that page:
deterministic rules first, LLM (grounded) only when rules abstain. No evidence -> no record."""
from __future__ import annotations
import asyncio
import logging
import re
from urllib.parse import quote
from urllib.parse import urljoin
from bs4 import BeautifulSoup

from ..context import Ctx
from ..fetcher import FetchError
from ..models import Product, ProductContent, PricingModel, Source, dump
from ..pool import run_pool
from ..state import fingerprint
from ..textclean import host_of, visible_text

log = logging.getLogger("graphone.products")
FREE_PLAN = re.compile(r"(free plan|free tier|free forever|freemium|always free|free to use|(get )?started? (for )?free|"
                       r"start for free|try for free|\$\s?0(?![\d.])\s*(/|per)?\s*(mo|month|user|seat)?|forever free)", re.I)
FREE_ONLY = re.compile(r"(100% free|completely free|totally free|free and open[- ]source|open[- ]source and free|no cost)", re.I)
ENTERPRISE = re.compile(r"(contact (sales|us)|book a demo|talk to sales|custom pricing|request (a )?(quote|demo)|get a quote)", re.I)
PRICE = re.compile(r"([$€£]\s?\d[\d,]*(\.\d+)?\s*(/|per|a)?\s*(mo|month|yr|year|user|seat)?|\d+\s?/\s?(mo|month|user|seat|year))", re.I)
PRICING_LINK = re.compile(r"pricing|plans|price", re.I)


def _snip(text: str, m: re.Match, w: int = 90) -> str:
    return re.sub(r"\s+", " ", text[max(0, m.start() - w): m.end() + w]).strip()


def classify_pricing(text: str) -> tuple[PricingModel, str] | None:
    """Deterministic classifier. Returns (model, evidence) or None when ambiguous."""
    price, free, ent, only = PRICE.search(text), FREE_PLAN.search(text), ENTERPRISE.search(text), FREE_ONLY.search(text)
    if only and not price:
        return PricingModel.FREE, _snip(text, only)
    if price and free:
        return PricingModel.FREEMIUM, _snip(text, free)
    if price:
        return PricingModel.PAID, _snip(text, price)
    if ent:
        return PricingModel.ENTERPRISE, _snip(text, ent)
    if free:
        return PricingModel.FREE, _snip(text, free)
    return None


async def find_pricing_page(ctx: Ctx, site: str) -> tuple[str, str] | None:
    base = site if site.startswith("http") else "https://" + site
    for path in ("/pricing", "/plans"):
        try:
            r = await ctx.fetcher.get(urljoin(base, path))
        except FetchError:
            continue
        if r.status == 200 and len(r.text) > 500 and host_of(r.final_url or r.url) == host_of(base):
            return r.final_url or r.url, r.text
    try:  # fall back to homepage link discovery
        home = await ctx.fetcher.get(base)
    except FetchError:
        return None
    if home.status != 200:
        return None
    for a in BeautifulSoup(home.text, "lxml").find_all("a", href=True):
        if PRICING_LINK.search(a.get_text(" ", strip=True)) or PRICING_LINK.search(a["href"]):
            u = urljoin(home.final_url or base, a["href"])
            if host_of(u) == host_of(base):
                try:
                    r = await ctx.fetcher.get(u)
                    if r.status == 200:
                        return r.final_url or u, r.text
                except FetchError:
                    continue
    return None


async def process(ctx: Ctx, startup: dict) -> None:
    c = startup["content"]
    site = c.get("website")
    if not site:
        return
    key = fingerprint("product", c["entityName"])
    if not await ctx.state.claim("product", key):
        return
    try:
        found = await find_pricing_page(ctx, site)
        if not found:
            await ctx.state.release("product", key)
            return
        url, html = found
        text = visible_text(html)
        verdict, by = classify_pricing(text), "heuristic"
        if verdict is None and ctx.llm.enabled:
            ex = await ctx.llm.extract_long(
                task="Classify the product's pricing model from its pricing page.",
                fields={"pricingModel": "one of FREE, FREEMIUM, PAID, ENTERPRISE"}, text=text, url=url,
                required=("pricingModel",), enums={"pricingModel": {m.value for m in PricingModel}},
                keywords=("free", "pricing", "plan", "$", "contact sales"))
            if ex:
                verdict, by = (PricingModel(ex.data["pricingModel"]), re.sub(r"\s+", " ", ex.evidence["pricingModel"])), ex.provider
        if verdict is None:
            await ctx.state.release("product", key)
            return
        model, evidence = verdict
        rec = Product(source=Source(name=host_of(url), url=url),
                      content=ProductContent(startupName=c["entityName"], productName=c["entityName"], pricingModel=model,
                                             pricingEvidence=evidence, website=site, classifiedBy=by))
        if ctx.sink.write("products", dump(rec), key=key):
            await ctx.state.commit("product", key)
    except Exception:
        await ctx.state.release("product", key)
        raise


GH_SEARCH = "https://api.github.com/search/repositories"
GH_TOPICS = ["llm", "generative-ai", "ai-agents", "machine-learning", "rag", "vector-database", "mlops", "computer-vision", "nlp", "deep-learning"]


def repo_to_product(ctx: Ctx, r: dict) -> dict | None:
    """GitHub repo -> PRODUCT record. Only org-owned, licensed, non-fork, non-archived repos qualify; pricing is
    FREE with the licence + URL as evidence, so every field is a direct API fact (nothing inferred)."""
    owner, lic = r.get("owner") or {}, (r.get("license") or {}).get("spdx_id")
    if owner.get("type") != "Organization" or r.get("fork") or r.get("archived") or not lic or lic == "NOASSERTION" \
            or not r.get("html_url") or not r.get("name"):
        return None
    res = ctx.resolver.resolve(owner["login"], r.get("homepage") or None)
    return dump(Product(source=Source(name="GitHub", url=r["html_url"]),
                        content=ProductContent(startupName=res.canonical, productName=r["name"], pricingModel=PricingModel.FREE,
                                               pricingEvidence=f"Open-source repository licensed {lic}: {r['html_url']}",
                                               website=r.get("homepage") or r["html_url"], classifiedBy="github-api",
                                               description=r.get("description") or None, githubStars=r.get("stargazers_count"))))


async def github_candidates(ctx: Ctx, need: int) -> list[dict]:
    """Lazy, resumable topic search (100/page, 5 pages/topic). Paced for the 30/min (token) or 10/min search quota."""
    st = ctx.stop.setdefault("gh", {"recs": [], "ids": set(), "t": 0, "page": 1, "dead": False})
    hdr = {"Accept": "application/vnd.github+json"}
    if ctx.settings.github_token:
        hdr["Authorization"] = f"Bearer {ctx.settings.github_token}"
    gap = 2.3 if ctx.settings.github_token else 6.5
    while len(st["recs"]) < need and not st["dead"] and st["t"] < len(GH_TOPICS):
        q = quote(f"topic:{GH_TOPICS[st['t']]} stars:>300 archived:false fork:false")
        try:
            r = await ctx.fetcher.get(f"{GH_SEARCH}?q={q}&sort=stars&order=desc&per_page=100&page={st['page']}",
                                      as_json=True, escalate=False, headers=hdr)
        except FetchError as e:
            log.warning("github search failed: %s", e)
            st["dead"] = True
            break
        if r.status != 200:
            log.warning("github search status=%s -> falling back to pricing pages only", r.status)
            st["dead"] = True
            break
        items = r.json().get("items", [])
        for it in items:
            if it.get("id") not in st["ids"] and (rec := repo_to_product(ctx, it)):
                st["ids"].add(it["id"])
                st["recs"].append(rec)
        if len(items) < 100 or st["page"] >= 5:
            st["t"], st["page"] = st["t"] + 1, 1
        else:
            st["page"] += 1
        await asyncio.sleep(gap)
    return st["recs"]


async def run(ctx: Ctx, target: int, startups: list[dict]) -> None:
    """60% from GitHub (structured, distinct products), the rest from startup pricing pages (FREEMIUM/PAID/ENTERPRISE
    diversity); GitHub tops up any shortfall. A dead GitHub never blocks the pricing path."""
    ctx.sink.counts.setdefault("products", 0)

    async def fill(upto: int) -> None:
        for rec in await github_candidates(ctx, upto):
            if ctx.sink.counts["products"] >= upto:
                break
            ctx.sink.write("products", rec, key=fingerprint("product", rec["source"]["url"]))
    await fill(int(target * 0.6))
    cands = (s for s in startups if s["content"].get("website"))
    await run_pool(cands, lambda s: process(ctx, s), concurrency=ctx.settings.concurrency,
                   done=lambda: ctx.sink.counts["products"] >= target)
    await fill(target)
    log.info("products written=%d", ctx.sink.counts["products"])
