"""Anti-hallucination layer. An LLM-extracted field survives ONLY if it is backed by a verbatim
evidence quote that exists in the fetched source text (and the value is consistent with the quote)."""
from __future__ import annotations
import re
import unicodedata
from dataclasses import dataclass, field
from typing import Any, Optional


def norm(s: str) -> str:
    s = unicodedata.normalize("NFKD", str(s)).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", " ", s).strip()


@dataclass
class Report:
    kept: dict[str, Any] = field(default_factory=dict)
    dropped: dict[str, str] = field(default_factory=dict)
    ok: bool = True


def verify(data: dict, evidence: dict, source_text: str, *, required: tuple[str, ...] = (),
           enums: Optional[dict[str, set]] = None) -> Report:
    src = " " + norm(source_text) + " "
    enums = enums or {}
    rep = Report()
    for k, v in data.items():
        if v in (None, "", [], {}):
            continue
        q = evidence.get(k)
        if not q or len(norm(q)) < 3 or f" {norm(q)} " not in src:
            rep.dropped[k] = "no verbatim evidence in source"
            continue
        if k in enums and v not in enums[k]:
            rep.dropped[k] = f"value not in enum {sorted(enums[k])}"
            continue
        if isinstance(v, bool):
            pass  # evidence presence is the check
        elif isinstance(v, (int, float)):
            digits = re.sub(r"[,\s]", "", q)
            if str(int(v)) not in digits and not re.search(rf"\b{int(v)}\b", digits):
                rep.dropped[k] = "number not present in evidence"
                continue
        elif isinstance(v, list):
            if not all(f" {norm(x)} " in src for x in v):
                rep.dropped[k] = "list item not found in source"
                continue
        elif k not in enums and f" {norm(v)} " not in src:
            rep.dropped[k] = "value not found in source"
            continue
        rep.kept[k] = v
    rep.ok = all(r in rep.kept for r in required)
    return rep
