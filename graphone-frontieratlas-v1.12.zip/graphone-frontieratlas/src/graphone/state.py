"""Exactly-once freshness/dedup state. SQLite for single node, Redis for a distributed fleet.

Protocol: claim() -> process -> commit()  (or release() on failure).
A claim is a *lease* so a crashed worker's item is retried after `lease_s`, while a committed
item is never processed again by any node.
"""
from __future__ import annotations
import hashlib
import sqlite3
import time
from pathlib import Path
from typing import Optional, Protocol

from .textclean import canonical_url


def fingerprint(*parts: str) -> str:
    return hashlib.sha1("\x1f".join(p.strip().lower() for p in parts).encode()).hexdigest()


def url_key(url: str) -> str:
    return fingerprint(canonical_url(url))


def title_key(source: str, title: str) -> str:
    import re
    return fingerprint(source, re.sub(r"\W+", " ", title.lower()).strip())


class StateStore(Protocol):
    async def claim(self, ns: str, key: str, lease_s: int = 300) -> bool: ...
    async def commit(self, ns: str, key: str) -> None: ...
    async def release(self, ns: str, key: str) -> None: ...
    async def is_baselined(self, source: str) -> bool: ...
    async def set_baselined(self, source: str) -> None: ...
    async def first_seen(self, ns: str, key: str) -> Optional[float]: ...


class SqliteState:
    def __init__(self, path: str | Path = ":memory:"):
        if str(path) != ":memory:":
            Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(str(path), isolation_level=None, check_same_thread=False)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("CREATE TABLE IF NOT EXISTS seen(ns TEXT, key TEXT, state TEXT, until REAL, first_seen REAL,"
                        " PRIMARY KEY(ns,key))")
        self.db.execute("CREATE TABLE IF NOT EXISTS baseline(source TEXT PRIMARY KEY, at REAL)")

    async def claim(self, ns: str, key: str, lease_s: int = 300) -> bool:
        now = time.time()
        row = self.db.execute("SELECT state, until FROM seen WHERE ns=? AND key=?", (ns, key)).fetchone()
        if row and (row[0] == "done" or row[1] > now):
            return False
        self.db.execute("INSERT INTO seen(ns,key,state,until,first_seen) VALUES(?,?,?,?,?) "
                        "ON CONFLICT(ns,key) DO UPDATE SET state='leased', until=excluded.until",
                        (ns, key, "leased", now + lease_s, now))
        return True

    async def commit(self, ns: str, key: str) -> None:
        self.db.execute("UPDATE seen SET state='done', until=0 WHERE ns=? AND key=?", (ns, key))

    async def release(self, ns: str, key: str) -> None:
        self.db.execute("DELETE FROM seen WHERE ns=? AND key=? AND state='leased'", (ns, key))

    async def is_baselined(self, source: str) -> bool:
        return self.db.execute("SELECT 1 FROM baseline WHERE source=?", (source,)).fetchone() is not None

    async def set_baselined(self, source: str) -> None:
        self.db.execute("INSERT OR IGNORE INTO baseline VALUES(?,?)", (source, time.time()))

    async def first_seen(self, ns: str, key: str) -> Optional[float]:
        r = self.db.execute("SELECT first_seen FROM seen WHERE ns=? AND key=?", (ns, key)).fetchone()
        return r[0] if r else None


class RedisState:
    """Same contract on Redis. `done:` keys are permanent; `lease:` keys carry a TTL.
    Commit writes `done:` *before* the lease expires, so SET NX on the lease cannot race a finished item."""

    def __init__(self, url: str):
        import redis.asyncio as redis  # optional dependency
        self.r = redis.from_url(url, decode_responses=True)

    async def claim(self, ns: str, key: str, lease_s: int = 300) -> bool:
        if await self.r.exists(f"done:{ns}:{key}"):
            return False
        return bool(await self.r.set(f"lease:{ns}:{key}", time.time(), nx=True, ex=lease_s))

    async def commit(self, ns: str, key: str) -> None:
        await self.r.set(f"done:{ns}:{key}", time.time())

    async def release(self, ns: str, key: str) -> None:
        await self.r.delete(f"lease:{ns}:{key}")

    async def is_baselined(self, source: str) -> bool:
        return bool(await self.r.exists(f"baseline:{source}"))

    async def set_baselined(self, source: str) -> None:
        await self.r.set(f"baseline:{source}", time.time(), nx=True)

    async def first_seen(self, ns: str, key: str) -> Optional[float]:
        v = await self.r.get(f"done:{ns}:{key}") or await self.r.get(f"lease:{ns}:{key}")
        return float(v) if v else None


def make_state(redis_url: str, sqlite_path) -> StateStore:
    return RedisState(redis_url) if redis_url else SqliteState(sqlite_path)


class FreshnessGate:
    """Decides whether an item is 'new within the last 24h' and never processed before.

    * dated item   -> accept iff dt within window AND claim() succeeds
    * undated item -> *first-seen heuristic*: accept iff the source already has a baseline run
      (otherwise the whole back-catalogue would look new) AND the fingerprint is unseen.
    """

    def __init__(self, state: StateStore, hours: int = 24):
        self.state, self.hours = state, hours

    async def decide(self, source: str, key: str, dt, now) -> tuple[bool, str]:
        from .dates import is_fresh
        if dt is not None:
            if not is_fresh(dt, now, self.hours):
                return False, "stale"
            return (await self.state.claim("fresh", key)), "dated"
        if not await self.state.is_baselined(source):
            await self.state.claim("baseline-seed", key)
            await self.state.commit("baseline-seed", key)
            return False, "baseline-seeding"
        if await self.state.first_seen("baseline-seed", key):
            return False, "seen-in-baseline"
        return (await self.state.claim("fresh", key)), "first-seen-heuristic"
