"""Multi-tier LLM extraction engine: Gemini Flash -> Groq Llama 3 -> DeepSeek.

Handles
  429  exponential backoff + full jitter (Retry-After honoured), per-provider token-bucket and a
       circuit breaker; exhausted providers are skipped and the next tier takes over.
  413  adaptive shrinking: payload is re-truncated by the semantic-density chunker (-45% per try);
       the provider's learned safe budget is remembered so the *next* call is right first time.
  5xx  retried with backoff.      401/403  provider disabled for the run.
Outputs are JSON-repaired and then passed through the grounding verifier (no evidence => no field).
"""
from __future__ import annotations
import asyncio
import json
import logging
import random
import re
import time
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Optional

import aiohttp

from .grounding import verify
from .textclean import smart_truncate

log = logging.getLogger("graphone.llm")


class ProviderError(Exception):
    def __init__(self, msg: str = "", retry_after: Optional[float] = None):
        super().__init__(msg)
        self.retry_after = retry_after

class RateLimited(ProviderError): ...
class PayloadTooLarge(ProviderError): ...
class Transient(ProviderError): ...
class Fatal(ProviderError): ...


def classify_error(status: int, body: str, retry_after: Optional[str] = None) -> ProviderError:
    ra = float(retry_after) if retry_after and re.fullmatch(r"\d+(\.\d+)?", retry_after) else None
    low = (body or "").lower()
    if status == 429:
        return RateLimited(body[:200], ra)
    if status == 413 or (status == 400 and re.search(r"(too large|context length|maximum context|token count|exceeds the (maximum|limit)|too many tokens|input is too long)", low)):
        return PayloadTooLarge(body[:200])
    if status in (401, 403):
        return Fatal(f"auth {status}")
    if status >= 500 or status in (408, 409):
        return Transient(f"{status} {body[:120]}", ra)
    return Fatal(f"{status} {body[:200]}")


@dataclass
class Provider:
    name: str
    key: str
    model: str
    max_chars: int                    # starting input budget (chars); shrinks on 413
    rpm: float = 30.0
    concurrency: int = 8
    _sem: asyncio.Semaphore = field(init=False, repr=False)
    _next: float = field(default=0.0, init=False, repr=False)
    _fails: int = field(default=0, init=False)
    _open_until: float = field(default=0.0, init=False)
    disabled: bool = field(default=False, init=False)

    def __post_init__(self):
        self._sem = asyncio.Semaphore(self.concurrency)

    async def pace(self) -> None:  # token-bucket-ish: spread calls to stay under rpm instead of eating 429s
        gap = 60.0 / self.rpm
        now = time.monotonic()
        wait = max(0.0, self._next - now)
        self._next = max(now, self._next) + gap
        if wait:
            await asyncio.sleep(wait)

    @property
    def available(self) -> bool:
        return not self.disabled and time.monotonic() >= self._open_until

    def trip(self, cooldown: float) -> None:
        self._open_until = time.monotonic() + cooldown

    async def complete(self, session: aiohttp.ClientSession, system: str, user: str) -> str:
        raise NotImplementedError

    async def _post(self, session, url, headers, payload) -> dict:
        async with session.post(url, headers=headers, json=payload, timeout=aiohttp.ClientTimeout(total=90)) as r:
            body = await r.text()
            if r.status != 200:
                raise classify_error(r.status, body, r.headers.get("retry-after"))
            return json.loads(body)


class GeminiProvider(Provider):
    async def complete(self, session, system, user):
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent"
        d = await self._post(session, url, {"x-goog-api-key": self.key}, {
            "systemInstruction": {"parts": [{"text": system}]},
            "contents": [{"role": "user", "parts": [{"text": user}]}],
            "generationConfig": {"temperature": 0, "responseMimeType": "application/json"}})
        try:
            return d["candidates"][0]["content"]["parts"][0]["text"]
        except (KeyError, IndexError):
            raise Transient("empty gemini candidate") from None


class OpenAICompat(Provider):
    base: str = ""

    async def complete(self, session, system, user):
        d = await self._post(session, self.base, {"Authorization": f"Bearer {self.key}"}, {
            "model": self.model, "temperature": 0, "response_format": {"type": "json_object"},
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}]})
        try:
            return d["choices"][0]["message"]["content"]
        except (KeyError, IndexError):
            raise Transient("empty completion") from None


class GroqProvider(OpenAICompat):
    base = "https://api.groq.com/openai/v1/chat/completions"

class DeepSeekProvider(OpenAICompat):
    base = "https://api.deepseek.com/chat/completions"


def build_chain(s) -> list[Provider]:
    chain: list[Provider] = []
    if s.gemini_key:
        chain.append(GeminiProvider("gemini", s.gemini_key, s.gemini_model, max_chars=300_000, rpm=15, concurrency=10))
    if s.groq_key:   # free tier TPM is tight -> small budget, relies on the chunker
        chain.append(GroqProvider("groq", s.groq_key, s.groq_model, max_chars=24_000, rpm=25, concurrency=4))
    if s.deepseek_key:
        chain.append(DeepSeekProvider("deepseek", s.deepseek_key, s.deepseek_model, max_chars=150_000, rpm=60, concurrency=10))
    return chain


SYSTEM = ("You are a strict information-extraction engine. Use ONLY the DOCUMENT. Never use outside knowledge, "
          "never guess, never infer. If a field is not explicitly stated, return null. Respond with ONE JSON object "
          "containing the requested fields plus an \"evidence\" object that maps every non-null field name to a "
          "short VERBATIM quote (<=200 chars) copied from the DOCUMENT that supports it.")


def parse_json(raw: str) -> dict:
    raw = re.sub(r"^```(?:json)?|```$", "", raw.strip(), flags=re.M).strip()
    i = raw.find("{")
    if i < 0:
        raise ValueError("no json object")
    obj, _ = json.JSONDecoder().raw_decode(raw[i:])
    if not isinstance(obj, dict):
        raise ValueError("not an object")
    return obj


@dataclass
class Extraction:
    data: dict
    provider: str
    dropped: dict
    truncated: bool
    attempts: int
    evidence: dict = field(default_factory=dict)


class LLMOrchestrator:
    def __init__(self, providers: list[Provider], *, event_log: Optional[Path] = None, max_429: int = 4, base_delay: float = 1.0, max_delay: float = 60.0,
                 shrink: float = 0.55, max_shrinks: int = 4, breaker_after: int = 4, cooldown: float = 45.0,
                 sleep=asyncio.sleep):
        self.event_log = Path(event_log) if event_log else None
        self.chain, self.max_429, self.base_delay, self.max_delay = providers, max_429, base_delay, max_delay
        self.shrink, self.max_shrinks, self.breaker_after, self.cooldown, self._sleep = shrink, max_shrinks, breaker_after, cooldown, sleep
        self._session: Optional[aiohttp.ClientSession] = None
        self.stats: dict[str, int] = {"calls": 0, "r429": 0, "r413": 0, "fallbacks": 0, "ungrounded_drops": 0}

    async def __aenter__(self):
        self._session = aiohttp.ClientSession()
        return self

    async def __aexit__(self, *a):
        if self._session:
            await self._session.close()

    @property
    def enabled(self) -> bool:
        return bool(self.chain)

    def _delay(self, attempt: int, retry_after: Optional[float]) -> float:
        cap = min(self.max_delay, self.base_delay * 2 ** attempt)
        return min(self.max_delay, max(random.uniform(0, cap), retry_after or 0.0))

    def _emit(self, **kw) -> None:
        """Append one structured event (ts, provider, status, attempt, backoff_s, shrunk_to_chars, fallback_to) as a JSON line."""
        if self.event_log:
            rec = {"ts": datetime.now(UTC).isoformat(timespec="seconds"), "provider": None, "status": None, "attempt": None,
                   "backoff_s": None, "shrunk_to_chars": None, "fallback_to": None, **kw}
            with open(self.event_log, "a", encoding="utf-8") as f:
                f.write(json.dumps(rec) + "\n")

    async def _call_provider(self, p: Provider, instructions: str, text: str, url: str, keywords) -> tuple[str, bool]:
        budget, n429, nshrink, ntrans = p.max_chars, 0, 0, 0
        while True:
            doc = smart_truncate(text, budget, keywords)
            user = f"{instructions}\n\nSOURCE URL: {url}\n\nDOCUMENT:\n\"\"\"\n{doc}\n\"\"\""
            try:
                async with p._sem:
                    await p.pace()
                    self.stats["calls"] += 1
                    out = await p.complete(self._session, SYSTEM, user)
                self._emit(provider=p.name, status=200, attempt=n429 + nshrink + ntrans + 1)
                p._fails = 0
                p.max_chars = min(p.max_chars, budget)  # remember what worked
                return out, len(doc) < len(text)
            except PayloadTooLarge:
                self.stats["r413"] += 1
                nshrink += 1
                self._emit(provider=p.name, status=413, attempt=nshrink, shrunk_to_chars=int(budget * self.shrink))
                if nshrink > self.max_shrinks or budget < 1500:
                    raise
                budget = int(budget * self.shrink)
                log.info("413 provider=%s -> shrink budget=%d", p.name, budget)
            except RateLimited as e:
                self.stats["r429"] += 1
                p._fails += 1
                if p._fails >= self.breaker_after:
                    p.trip(self.cooldown)
                n429 += 1
                if n429 > self.max_429:
                    raise
                d = self._delay(n429 - 1, e.retry_after)
                log.info("429 provider=%s attempt=%d sleep=%.1fs", p.name, n429, d)
                self._emit(provider=p.name, status=429, attempt=n429, backoff_s=round(d, 2))
                await self._sleep(d)
            except Transient as e:
                ntrans += 1
                if ntrans > 3:
                    raise
                await self._sleep(self._delay(ntrans - 1, e.retry_after))
            except Fatal:
                p.disabled = True
                raise

    async def extract(self, *, task: str, fields: dict[str, str], text: str, url: str,
                      required: tuple[str, ...] = (), enums: Optional[dict] = None,
                      keywords: tuple[str, ...] = ()) -> Optional[Extraction]:
        field_spec = "\n".join(f'- "{k}": {v}' for k, v in fields.items())
        instructions = f"TASK: {task}\nReturn JSON with these fields (null if not explicitly stated):\n{field_spec}\n" \
                       f"and \"evidence\": {{field: verbatim quote}}."
        for tier, p in enumerate(self.chain):
            if not p.available:
                continue
            if tier:
                self.stats["fallbacks"] += 1
                self._emit(provider=self.chain[tier - 1].name, fallback_to=p.name)
            try:
                raw, truncated = await self._call_provider(p, instructions, text, url, keywords)
                try:
                    obj = parse_json(raw)
                except ValueError:  # one repair attempt
                    raw, truncated = await self._call_provider(
                        p, instructions + "\nYour previous reply was not valid JSON. Reply with JSON only.", text, url, keywords)
                    obj = parse_json(raw)
            except (TimeoutError, ProviderError, ValueError, aiohttp.ClientError) as e:
                log.warning("provider=%s failed (%s: %s) -> next tier", p.name, type(e).__name__, str(e)[:80])
                continue
            evidence = obj.pop("evidence", {}) or {}
            rep = verify({k: obj.get(k) for k in fields}, evidence, text, required=required, enums=enums)
            self.stats["ungrounded_drops"] += len(rep.dropped)
            if not rep.ok:
                log.info("provider=%s output failed grounding: %s", p.name, rep.dropped)
                continue  # try next tier; a different model may find the evidence
            return Extraction(rep.kept, p.name, rep.dropped, truncated, tier + 1, {k: evidence[k] for k in rep.kept if k in evidence})
        return None

    async def extract_long(self, *, text: str, chunk_chars: int = 0, **kw) -> Optional[Extraction]:
        """Map-reduce for documents beyond any context window: extract per chunk (each grounded against
        its own chunk), then merge - first non-null wins per field, lists are unioned."""
        size = chunk_chars or min((p.max_chars for p in self.chain), default=20_000)
        if len(text) <= size:
            return await self.extract(text=text, **kw)
        chunks, cur = [], ""
        for para in text.split("\n"):
            for i in range(0, max(len(para), 1), size):
                piece = para[i:i + size]
                if cur and len(cur) + len(piece) + 1 > size:
                    chunks.append(cur)
                    cur = ""
                cur += piece + "\n"
        if cur.strip():
            chunks.append(cur)
        sub = {**kw, "required": ()}
        parts = [x for x in await asyncio.gather(*(self.extract(text=c, **sub) for c in chunks)) if x]
        data: dict = {}
        ev: dict = {}
        for x in parts:
            for k, v in x.data.items():
                if isinstance(v, list):
                    data[k] = sorted(set(data.get(k, [])) | set(v))
                elif k not in data:
                    data[k] = v
            for k, q in x.evidence.items():
                ev.setdefault(k, q)
        if not parts or not all(r in data for r in kw.get("required", ())):
            return None
        return Extraction(data, "+".join(sorted({x.provider for x in parts})), {}, True, max(x.attempts for x in parts), ev)
