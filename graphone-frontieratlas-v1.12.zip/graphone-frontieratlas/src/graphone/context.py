from __future__ import annotations
import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .config import Settings
from .fetcher import Fetcher
from .llm import LLMOrchestrator
from .resolver import EntityResolver
from .state import FreshnessGate, StateStore

log = logging.getLogger("graphone")


class JsonlSink:
    """Append-only JSONL per record type; in-process key set gives cheap idempotency."""

    def __init__(self, out_dir: Path):
        self.dir = out_dir
        out_dir.mkdir(parents=True, exist_ok=True)
        self.counts: dict[str, int] = {}
        self._keys: dict[str, set] = {}

    def write(self, name: str, rec: dict, key: str | None = None) -> bool:
        if key is not None:
            ks = self._keys.setdefault(name, set())
            if key in ks:
                return False
            ks.add(key)
        with open(self.dir / f"{name}.jsonl", "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        self.counts[name] = self.counts.get(name, 0) + 1
        return True

    def preload(self, name: str, key_fn) -> None:
        p = self.dir / f"{name}.jsonl"
        if p.exists():
            ks = self._keys.setdefault(name, set())
            for line in p.read_text(encoding="utf-8").splitlines():
                try:
                    r = json.loads(line)
                    ks.add(key_fn(r))
                    self.counts[name] = self.counts.get(name, 0) + 1
                except ValueError:
                    continue


@dataclass
class Ctx:
    settings: Settings
    fetcher: Fetcher
    llm: LLMOrchestrator
    resolver: EntityResolver
    state: StateStore
    gate: FreshnessGate
    sink: JsonlSink
    stop: dict[str, Any] = field(default_factory=dict)
