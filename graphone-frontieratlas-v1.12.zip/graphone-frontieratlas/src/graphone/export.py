"""JSONL -> 6-tab workbook (+CSVs) and post-run quality gates."""
from __future__ import annotations
import csv
import json
from datetime import datetime, timedelta, UTC
from pathlib import Path

from .models import flatten

TABS = [("Startups", "startups"), ("Products", "products"), ("Research Papers", "papers"), ("Jobs", "jobs"), ("News", "news")]
FIRST = ["schemaVersion", "recordType", "source.name", "source.url"]


def read_jsonl(p: Path) -> list[dict]:
    if not p.exists():
        return []
    rows = []
    for line in p.read_text(encoding="utf-8").splitlines():
        try:
            rows.append(json.loads(line))
        except ValueError:
            continue
    return rows


def _columns(rows: list[dict]) -> list[str]:
    cols: list[str] = []
    for r in rows:
        for k in r:
            if k not in cols:
                cols.append(k)
    return [c for c in FIRST if c in cols] + [c for c in cols if c not in FIRST]


def export(out: Path) -> dict[str, int]:
    from openpyxl import Workbook
    wb = Workbook()
    wb.remove(wb.active)
    counts: dict[str, int] = {}
    for tab, name in TABS:
        rows = [flatten(r) for r in read_jsonl(out / f"{name}.jsonl")]
        cols = _columns(rows)
        ws = wb.create_sheet(tab)
        ws.append(cols or ["(no rows)"])
        for r in rows:
            ws.append([("" if r.get(c) is None else (str(r[c])[:32000] if isinstance(r[c], str) else r[c])) for c in cols])
        ws.freeze_panes = "A2"
        with open(out / f"{name}.csv", "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(cols)
            for r in rows:
                w.writerow([r.get(c, "") for c in cols])
        counts[tab] = len(rows)
    ws = wb.create_sheet("Entity Mapping Log")
    log_p = out / "entity_mapping_log.csv"
    if log_p.exists():
        with open(log_p, newline="", encoding="utf-8") as f:
            for row in csv.reader(f):
                ws.append(row)
    else:
        ws.append(["raw", "canonical", "method", "score", "is_new"])
    counts["Entity Mapping Log"] = max(ws.max_row - 1, 0)
    wb.save(out / "graphone_output.xlsx")
    return counts


def validate(out: Path, now: datetime | None = None, hours: int = 24) -> dict:
    """Hard quality gates. Any violation is reported (and fails the CLI exit code)."""
    now = now or datetime.now(UTC)
    problems: list[str] = []
    rep: dict = {}
    for _tab, name in TABS:
        rows = read_jsonl(out / f"{name}.jsonl")
        rep[name] = len(rows)
        urls = set()
        for r in rows:
            u = (r.get("source") or {}).get("url", "")
            if not u.startswith("http"):
                problems.append(f"{name}: row without source.url")
            key = json.dumps(r.get("content", {}).get("url") or r["source"]["url"] + str(r["content"].get("entityName", "")))
            if key in urls:
                problems.append(f"{name}: duplicate {key[:80]}")
            urls.add(key)
    for name, field in (("jobs", "date"), ("news", "published_at")):
        stale = 0
        for r in read_jsonl(out / f"{name}.jsonl"):
            dt = datetime.strptime(r["content"][field], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC)
            if not (now - timedelta(hours=hours, minutes=5) <= dt <= now + timedelta(minutes=10)):
                stale += 1
        rep[f"{name}_stale_violations"] = stale
        if stale:
            problems.append(f"{name}: {stale} rows outside the {hours}h window")
    papers = read_jsonl(out / "papers.jsonl")
    rep["papers_with_github"] = sum(1 for p in papers if p["content"].get("github_url"))
    rep["papers_with_stars"] = sum(1 for p in papers if p["content"].get("github_stars") is not None)
    rep["problems"] = problems
    return rep
