from __future__ import annotations
import asyncio
import json
import logging
import time
from pathlib import Path

from .config import Settings
from .context import Ctx, JsonlSink
from .export import export, validate
from .fetcher import Fetcher
from .llm import LLMOrchestrator, build_chain
from .resolver import EntityResolver
from .sources import jobs, news, papers, products, yc
from .state import FreshnessGate, make_state

log = logging.getLogger("graphone.pipeline")
SEED = Path(__file__).resolve().parents[2] / "data" / "seed_entities.json"


async def run(phases: set[str], s: Settings, targets: dict | None = None) -> dict:
    t0 = time.time()
    targets = {**s.targets, **(targets or {})}
    s.out_dir.mkdir(parents=True, exist_ok=True)
    state = make_state(s.redis_url, s.state_path)
    resolver = EntityResolver(SEED)
    sink = JsonlSink(s.out_dir)
    for name in ("startups", "products", "papers"):  # resume support: never re-write existing rows
        sink.preload(name, lambda r, n=name: _legacy_key(n, r))
    async with Fetcher(concurrency=s.concurrency, per_domain=s.per_domain_concurrency, intervals=s.domain_intervals,
                       proxy=s.proxy_url, respect_robots=s.respect_robots, contact=s.contact_email) as fetcher, \
            LLMOrchestrator(build_chain(s), event_log=s.out_dir / "llm_events.jsonl") as llm:
        ctx = Ctx(s, fetcher, llm, resolver, state, FreshnessGate(state, s.freshness_hours), sink)
        log.info("llm chain=%s", [p.name for p in llm.chain] or "none (deterministic mode)")
        startup_pool: list[dict] = []

        async def guarded(name, coro):  # a dead source must never sink the other phases
            try:
                return await coro
            except Exception as e:  # noqa: BLE001
                log.error("phase %s failed: %s: %s", name, type(e).__name__, str(e)[:200])

        if phases & {"startups", "products"}:
            companies = await guarded("yc-directory", yc.fetch_companies(ctx)) or []
            if "startups" in phases and companies:
                await guarded("startups", yc.run(ctx, targets["startups"], companies))
            if "products" in phases and companies:
                ranked = sorted(companies, key=lambda c: (not yc.is_ai(c), -(c.get("team_size") or 0)))
                startup_pool = list(yc.candidate_records(ctx, ranked))
        tasks = []
        if "products" in phases:
            tasks.append(guarded("products", products.run(ctx, targets["products"], startup_pool)))
        if "papers" in phases:
            tasks.append(guarded("papers", papers.run(ctx, targets["papers"])))
        if "news" in phases:
            tasks.append(guarded("news", news.run(ctx)))
        if "jobs" in phases:
            tasks.append(guarded("jobs", jobs.run(ctx)))
        await asyncio.gather(*tasks)
        stats = {"fetch": fetcher.stats, "llm": llm.stats}
    resolver.write_log(s.out_dir / "entity_mapping_log.csv")
    from .stabilize import apply_stable_names
    apply_stable_names(s.out_dir, resolver.seed_names)
    counts = export(s.out_dir)
    want = {"Startups": targets["startups"], "Products": targets["products"], "Research Papers": targets["papers"]}
    short = {k: f"{counts[k]}/{v}" for k, v in want.items() if k.lower().split()[0].rstrip("s") in {p.rstrip("s") for p in phases} and counts[k] < v}
    report = {"elapsed_s": round(time.time() - t0, 1), "counts": counts, "shortfalls": short, "stats": stats,
              "validation": validate(s.out_dir)}
    (s.out_dir / "run_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    return report


def _legacy_key(name: str, r: dict) -> str:
    from .state import fingerprint
    c = r["content"]
    if name == "startups":
        return fingerprint(c["entityName"])
    if name == "papers":
        return fingerprint("paper", c.get("arxiv_id"))
    if c.get("classifiedBy") == "github-api":
        return fingerprint("product", r["source"]["url"])
    return fingerprint("product", c.get("startupName"))
