"""Order-independent canonical names for NON-seed entities.

While a run is in flight the first-seen spelling of a new entity becomes its canonical name, and with concurrent workers
"first" varies between runs. After the run, each non-seed cluster (grouped by normalised key, so it also unifies names
produced by *different* invocations) is renamed to its most frequent cleaned spelling (ties: shorter, then alphabetical),
so the output depends only on the set of variants seen, never on their order."""
import csv
import io
import json
from collections import Counter, defaultdict
from pathlib import Path

from .fsutil import atomic_write
from .resolver import EntityResolver, compact

NAME_KEYS = ("entityName", "startupName", "company")


def stable_names(pairs, seeds) -> dict[str, str]:
    groups: dict[str, tuple[set, Counter]] = defaultdict(lambda: (set(), Counter()))
    for raw, canonical in pairs:
        if canonical not in seeds:
            names, forms = groups[compact(canonical)]
            names.add(canonical)
            forms[EntityResolver.display_clean(raw)] += 1
    out = {}
    for names, forms in groups.values():
        best = sorted(forms.items(), key=lambda kv: (-kv[1], len(kv[0]), kv[0]))[0][0]
        out.update({c: best for c in names if c != best})
    return out


def apply_stable_names(out_dir: Path, seeds) -> dict[str, str]:
    """Rewrite entity_mapping_log.csv and all *.jsonl (atomically) so every non-seed canonical name is the stable one."""
    log_p = Path(out_dir) / "entity_mapping_log.csv"
    if not log_p.exists():
        return {}
    with open(log_p, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    mp = stable_names(((r["raw"], r["canonical"]) for r in rows), seeds)
    if not mp:
        return {}
    buf = io.StringIO(newline="")
    w = csv.DictWriter(buf, ["raw", "canonical", "method", "score", "is_new"])
    w.writeheader()
    for r in rows:
        r["canonical"] = mp.get(r["canonical"], r["canonical"])
        w.writerow(r)
    atomic_write(log_p, buf.getvalue())
    for p in Path(out_dir).glob("*.jsonl"):
        lines = []
        for line in p.read_text(encoding="utf-8").splitlines():
            rec = json.loads(line)
            c = rec.get("content", {})
            for k in NAME_KEYS:
                if c.get(k) in mp:
                    c[k] = mp[c[k]]
            if isinstance(c.get("companies_mentioned"), list):
                c["companies_mentioned"] = [mp.get(n, n) for n in c["companies_mentioned"]]
            lines.append(json.dumps(rec, ensure_ascii=False))
        atomic_write(p, "\n".join(lines) + ("\n" if lines else ""))
    return mp
