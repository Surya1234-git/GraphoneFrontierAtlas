const $=s=>document.querySelector(s),E=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const MAP=u=>u.startsWith('/api/data/')?'data/'+u.slice(10)+'.json':u==='/api/summary'?'data/summary.json':u==='/api/momentum'?'data/momentum.json':null;
const J=async u=>{try{const r=await fetch(u);if(!r.ok)throw 0;return await r.json()}catch(e){const m=MAP(u);if(!m)throw e;return (await fetch(m)).json()}},g=(o,p)=>p.split('.').reduce((a,k)=>a?.[k],o);
const T={startups:'Startups',products:'Products',papers:'Research Papers',jobs:'Jobs (24h)',news:'News (24h)'};
const COLS={startups:[['Name','content.entityName'],['Raw name','content.rawName'],['Batch','content.batch'],['Employees','content.data.employeeCount'],['Resolved by','content.resolution'],['Source','source.url']],
products:[['Startup','content.startupName'],['Product','content.productName'],['Stars','content.githubStars'],['Pricing','content.pricingModel'],['Evidence','content.pricingEvidence'],['By','content.classifiedBy'],['Source','source.url']],
papers:[['Title','content.title'],['Published','content.published_date'],['GitHub','content.github_url'],['Stars','content.github_stars'],['Found via','content.github_discovery']],
jobs:[['Company','content.company'],['Title','content.title'],['Role family','content.role_family'],['Remote','content.is_remote'],['Date','content.date'],['Date method','content.date_method']],
news:[['Title','content.title'],['Source','source.name'],['Published','content.published_at'],['Date method','content.date_method'],['Companies','content.companies_mentioned']]};
let S,D={},cur='startups';
function count(el,to){const t0=performance.now();(function f(t){const p=Math.min(1,(t-t0)/900);el.textContent=Math.round(to*(1-Math.pow(1-p,3))).toLocaleString();if(p<1)requestAnimationFrame(f)})(t0)}
document.querySelectorAll('nav a').forEach(a=>a.onclick=e=>{e.preventDefault();document.querySelectorAll('nav a,.v').forEach(x=>x.classList.remove('on'));a.classList.add('on');$('#'+a.dataset.v).classList.add('on');({fresh:radar,graph:graph}[a.dataset.v]||(()=>0))()});
async function init(){
 S=await J('/api/summary');for(const n of Object.keys(T))D[n]=await J('/api/data/'+n);
 const tot=Object.values(S.counts).reduce((a,b)=>a+b,0);
 $('#snap').textContent=S.snapshot?'Snapshot of run at '+new Date(S.snapshot*1000).toLocaleString()+' · reading '+S.out+'/':'No run_report.json yet · reading '+S.out+'/';
 if(!tot)$('#banner').innerHTML='<div class="card empty">No pipeline output found.<br>Run <code>PYTHONPATH=src python -m graphone run all</code> then refresh. This dashboard never shows placeholder data.</div>';
 const TG={startups:1000,products:1000,papers:1000},IC={jobs:ico('briefcase'),news:ico('file')};
 $('#kpis').innerHTML=Object.entries(T).map(([k,v])=>{const pc=TG[k]?Math.min(1,S.counts[k]/TG[k]):null;return `<div class="card kpi"><div class="rg">${pc!==null?`<svg width="48" height="48" viewBox="0 0 48 48"><circle cx="24" cy="24" r="20" fill="none" style="stroke:var(--line)" stroke-width="5"/><circle cx="24" cy="24" r="20" fill="none" style="stroke:${pc>=1?'var(--ok)':'var(--a)'}" stroke-width="5" stroke-linecap="round" stroke-dasharray="${pc*125.7} 125.7"/></svg>`:`<b>${IC[k]}</b>`}</div><div><div class="l">${v}</div><div class="n" data-n="${S.counts[k]}">0</div><small>${TG[k]?'of '+TG[k].toLocaleString()+' target':'last 24 h only'}</small></div></div>`}).join('');
 const cn=S.counts,allr=Object.keys(T).flatMap(k=>D[k]||[]),miss=allr.filter(r=>!/^https?:\/\//.test(r.source?.url||'')).length;
 $('#hsum').textContent=allr.length?`${cn.startups.toLocaleString()} startups · ${cn.products.toLocaleString()} products · ${cn.papers.toLocaleString()} papers · ${cn.jobs} fresh jobs · ${cn.news} fresh news`+(miss?` — ${miss} rows lack a source URL`:' — every row links to its source URL.'):'No pipeline output yet. Run the pipeline, then reload: this page only ever shows real data.';
 $('#hbars').innerHTML=Object.keys(TG).map(k=>`<div class="hb"><div class="stat" style="border:0;padding:0"><span>${T[k]}</span><b>${cn[k].toLocaleString()} / 1,000</b></div><div class="bar"><i style="width:${Math.min(100,cn[k]/10)}%"></i></div></div>`).join('');trust();
 document.querySelectorAll('[data-n]').forEach(e=>count(e,+e.dataset.n));
 const V=S.report?.validation||{},stale=(V.jobs_stale_violations||0)+(V.news_stale_violations||0),pr=(V.problems||[]).length;
 const bd=(ok,t)=>`<span class="badge"><i class="dot ${ok?'':'bad'}"></i>${t}</span>`;
 $('#badges').innerHTML=S.report?bd(stale===0,stale===0?'0 stale rows (24h window enforced)':stale+' stale rows')+bd(pr===0,pr?pr+' gate problems':(['startups','products','papers'].every(k=>S.counts[k]>=1000)?'All quality gates passed':'No gate failures · targets not yet met'))
  +bd(true,(V.papers_with_stars??0)+' papers with live GitHub stars')+bd(true,'LLM ungrounded drops: '+(S.report.stats?.llm?.ungrounded_drops??0)):bd(false,'Run report not available');
 const f=S.report?.stats?.fetch||{},l=S.report?.stats?.llm||{};
 $('#flow').innerHTML=[['Discover','APIs · feeds · bulk'],['Fetch',(f.requests??'–')+' req'],['Extract',(l.calls??0)+' LLM calls'],['Resolve',Object.values(S.mapping).reduce((a,b)=>a+b,0)+' names'],['Store','JSONL · XLSX']]
  .map((n,i)=>(i?'<div class="arrow"></div>':'')+`<div class="node"><em>${ico(['compass','globe','zap','merge','db'][i])}</em><b>${n[0]}</b><span>${n[1]}</span></div>`).join('');
 const st=(o,ks)=>ks.map(k=>`<div class="stat"><span>${k}</span><b>${o[k]??'–'}</b></div>`).join('');
 $('#fs').innerHTML=st(f,['requests','retries','r429','blocked','escalations']);$('#ls').innerHTML=st(l,['calls','r429','r413','fallbacks','ungrounded_drops']);
 const mt=Object.values(S.mapping).reduce((a,b)=>a+b,0)||1;
 $('#ms').innerHTML=Object.entries(S.mapping).map(([k,v])=>`<div class="stat" style="border:0;padding-bottom:0"><span>${k}</span><b>${v}</b></div><div class="bar"><i style="width:${v/mt*100}%"></i></div>`).join('')||'<div class="empty">No mapping log yet</div>';
 $('#tabs').innerHTML=Object.entries(T).map(([k,v])=>`<div class="tab ${k===cur?'on':''}" role="tab" aria-selected="${k===cur}" tabindex="0" onkeydown="event.key==='Enter'&&this.click()" data-k="${k}">${v} · ${S.counts[k]}</div>`).join('');
 document.querySelectorAll('.tab').forEach(t=>t.onclick=()=>{cur=t.dataset.k;SORT=null;PG=100;document.querySelectorAll('#tabs .tab').forEach(x=>{x.classList.toggle('on',x===t);x.setAttribute('aria-selected',x===t)});table()});
 $('#q').oninput=table;table();
}
let PG=100,SORT=null,DIR=1;const cmp=(a,b)=>{if(!SORT)return 0;const x=g(a,SORT)??'',y=g(b,SORT)??'';return (x>y?1:x<y?-1:0)*DIR};
function table(){
 const q=$('#q').value.toLowerCase(),cols=COLS[cur],all=(D[cur]||[]).filter(r=>!q||JSON.stringify(r).toLowerCase().includes(q)).sort(cmp),rows=all.slice(0,PG);
 if(!rows.length){$('#tbl').innerHTML='<tr><td class="empty">No rows</td></tr>';$('#more').innerHTML='';return}
 $('#tbl').innerHTML='<tr>'+cols.map(c=>`<th tabindex=0 data-s="${c[1]}" aria-sort="${SORT===c[1]?(DIR>0?'ascending':'descending'):'none'}" style="cursor:pointer">${c[0]}${SORT===c[1]?(DIR>0?' ▲':' ▼'):''}</th>`).join('')+'</tr>'+rows.map((r,i)=>`<tr class="r" data-i="${i}">`+cols.map(c=>{let v=g(r,c[1]);if(Array.isArray(v))v=v.join(', ');return `<td title="${E(v)}">${c[0].includes('method')||c[0]==='By'||c[0]==='Resolved by'?`<span class="tag">${E(v)}</span>`:E(v)}</td>`}).join('')+'</tr>').join('');
 document.querySelectorAll('tr.r').forEach(tr=>{tr.tabIndex=0;tr.onclick=()=>open(rows[tr.dataset.i]);tr.onkeydown=e=>e.key==='Enter'&&tr.click()});
 document.querySelectorAll('#tbl th').forEach(th=>{const f=()=>{DIR=SORT===th.dataset.s?-DIR:1;SORT=th.dataset.s;PG=100;table()};th.onclick=f;th.onkeydown=e=>e.key==='Enter'&&f()});
 $('#more').innerHTML=all.length>rows.length?`<button class="ghost" onclick="PG+=200;table()">Show ${Math.min(200,all.length-rows.length)} more · ${all.length-rows.length} left</button>`:`<span style="color:var(--mut);font-size:12px">${all.length} rows · click a header to sort</span>`;window.__csv={cols,all};$('#more').insertAdjacentHTML('beforeend',' <button class="ghost" onclick="dl()">Download CSV</button>');
 if(['Name','Startup','Company'].includes(cols[0][0]))document.querySelectorAll('#tbl tr.r td:first-child').forEach(td=>{const t=td.textContent.trim();td.insertAdjacentHTML('afterbegin',`<span class="av" style="background:hsl(${[...t].reduce((a,c)=>a+c.charCodeAt(0),0)*37%360} 65% 42%)">${E(t[0]||'?')}</span>`)});
}
window.__ret=null;const closeDrawer=()=>{$('#drawer').classList.remove('open');window.__ret?.focus?.()};
function open(r){window.__ret=document.activeElement;
 const c=r.content||{},u=c.url||c.paper_url||r.source?.url,ev=c.pricingEvidence,txt=c.text||c.description||'';
 let body='';
 if(ev)body=`<div class="ev"><h3 style="color:var(--ok)">Verbatim evidence · classified by ${E(c.classifiedBy)}</h3><mark>${E(ev)}</mark></div>`;
 else if(c.github_stars!=null)body=`<div class="ev"><h3 style="color:var(--ok)">Live GitHub metric</h3><b class="big">★ ${c.github_stars.toLocaleString()}</b><div style="color:var(--mut);font-size:12px">checked ${E(c.github_stars_checked_at)} · linked via ${E(c.github_discovery)}</div></div>`;
 else if(c.date_method)body=`<div class="ev"><h3 style="color:var(--ok)">Date provenance</h3><span class="tag">${E(c.date_method)}</span> ${E(c.date||c.published_at)}</div>`;
 $('#drawer').innerHTML=`<div class="row" style="justify-content:space-between;margin-top:0"><h1 style="font-size:18px">${E(c.title||c.entityName||c.startupName)}</h1><span class="tab" role="button" tabindex="0" aria-label="Close" onclick="closeDrawer()" onkeydown="event.key==='Enter'&&this.click()">✕</span></div>
 ${/^https?:\/\//i.test(u||'')?`<a href="${E(u)}" target="_blank" rel="noopener noreferrer" style="color:var(--a);word-break:break-all">${E(u)}</a><div class="row" style="margin:10px 0"><a class="btnlink" href="${E(u)}" target="_blank" rel="noopener noreferrer">Open source URL</a><button class="ghost" data-u="${E(u)}" onclick="navigator.clipboard?.writeText(this.dataset.u);this.textContent='Copied ✓'">Copy source URL</button></div>`:''}${body}${txt&&r.recordType==='NEWS'?`<h3 style="margin-top:14px">Full text</h3><pre>${E(txt.slice(0,4000))}</pre>`:''}<h3 style="margin-top:14px">Raw record</h3><pre>${E(JSON.stringify(r,null,2))}</pre>`;
 $('#drawer').classList.add('open');setTimeout(()=>$('#drawer [aria-label=Close]')?.focus(),60);
}
function radar(){
 const cv=$('#cv'),W=cv.clientWidth*2,H=720,PX=Math.min(3,window.devicePixelRatio||1),x=(cv.width=W*PX/2,cv.height=H*PX/2,cv.getContext('2d'));x.setTransform(PX/2,0,0,PX/2,0,0);
 const items=[...(D.jobs||[]).map(r=>[r.source.name,r.content.date,r.content.date_method]),...(D.news||[]).map(r=>[r.source.name,r.content.published_at,r.content.date_method])];
 x.clearRect(0,0,W,H);if(!items.length){x.fillStyle=V('--mut');x.font='28px sans-serif';x.fillText('No jobs/news rows yet. Run the pipeline first.',40,80);return}
 const end=Math.max(...items.map(i=>+new Date(i[1]))),srcs=[...new Set(items.map(i=>i[0]))],meths=[...new Set(items.map(i=>i[2]))],pal=['#22d3ee','#a78bfa','#34d399','#fbbf24','#f472b6','#60a5fa','#fb923c'];
 const L=230,R=W-30,T0=30,B=H-50,rowH=(B-T0)/srcs.length;
 x.font='22px sans-serif';x.strokeStyle=V('--line');x.fillStyle=V('--mut');
 for(let h=0;h<=24;h+=4){const px=R-(h/24)*(R-L);x.beginPath();x.moveTo(px,T0);x.lineTo(px,B);x.stroke();x.fillText(h?'-'+h+'h':'now',px-18,H-18)}
 srcs.forEach((s,i)=>{x.fillText(s.slice(0,22),10,T0+rowH*(i+.5)+6)});
 items.forEach(([s,d,m],i)=>{const age=(end-new Date(d))/36e5;if(age<0||age>24.5)return;const px=R-(age/24)*(R-L),py=T0+rowH*(srcs.indexOf(s)+.5)+(((Math.sin(i*12.9898)*43758.5453)%1)/2)*rowH*.55;x.fillStyle=pal[meths.indexOf(m)%7];x.globalAlpha=.8;x.beginPath();x.arc(px,py,7,0,7);x.fill();x.globalAlpha=1});
 $('#lg').innerHTML=meths.map((m,i)=>`<span><i style="background:${pal[i%7]}"></i>${E(m)}</span>`).join('')+`<span>· ${items.length} items</span>`;
}
let GR;
function graph(){
 if(GR)return;const cv=$('#gc'),W=cv.clientWidth*2,H=1120,PX=Math.min(3,window.devicePixelRatio||1),x=(cv.width=W*PX/2,cv.height=H*PX/2,cv.getContext('2d'));x.setTransform(PX/2,0,0,PX/2,0,0);
 const N=new Map,Ls=[],col={batch:'#94a3b8',startup:'#22d3ee',product:'#a78bfa',paper:'#fbbf24',repo:'#34d399',job:'#f472b6',news:'#60a5fa'};
 const rn=k=>((Math.sin(k*91.7)*10000)%1+1)%1,add=(id,t,l,d)=>{if(!N.has(id)&&N.size<340)N.set(id,{id,t,l,d,x:W/2+(rn(N.size*2)-.5)*600,y:H/2+(rn(N.size*2+1)-.5)*400,vx:0,vy:0});return N.get(id)};
 const lk=(a,b)=>{if(a&&b)Ls.push([a,b])};
 (D.startups||[]).slice(0,110).forEach(r=>{const n=add('c:'+r.content.entityName,'startup',r.content.entityName,r);if(r.content.batch)lk(n,add('b:'+r.content.batch,'batch',r.content.batch+' (YC batch)',null))});
 const co=n=>N.get('c:'+n)||add('c:'+n,'startup',n,null);
 (D.products||[]).slice(0,60).forEach(r=>lk(add('p:'+r.content.startupName,'product',r.content.productName,r),co(r.content.startupName)));
 (D.papers||[]).filter(r=>r.content.github_url).slice(0,60).forEach(r=>lk(add('a:'+r.content.arxiv_id,'paper',r.content.title,r),add('r:'+r.content.github_url,'repo',r.content.github_url.replace('https://github.com/',''),r)));
 (D.jobs||[]).slice(0,50).forEach(r=>lk(add('j:'+r.content.url,'job',r.content.title,r),co(r.content.company)));
 (D.news||[]).slice(0,40).forEach(r=>{const n=add('n:'+r.content.url,'news',r.content.title,r);(r.content.companies_mentioned||[]).forEach(c=>lk(n,co(c)))});
 const nodes=[...N.values()];if(!nodes.length){x.fillStyle=V('--mut');x.font='28px sans-serif';x.fillText('No data yet. Run the pipeline first.',40,80);return}
 const ed=Ls.map(([a,b])=>[a,b]);GR=1;let hov=null;
 $('#gl').innerHTML=Object.entries(col).map(([k,c])=>`<span><i style="background:${c}"></i>${k}</span>`).join('')+`<span>· ${nodes.length} nodes · ${ed.length} edges</span>`;
 let alpha=1,run=0;
 const phys=()=>{for(const a of nodes){a.vx+=(W/2-a.x)*.0007*alpha;a.vy+=(H/2-a.y)*.0007*alpha;for(const b of nodes){if(a===b)continue;const dx=a.x-b.x,dy=a.y-b.y,d=dx*dx+dy*dy+50;if(d<90000){const f=2600*alpha/d/Math.sqrt(d);a.vx+=dx*f;a.vy+=dy*f}}}
   for(const [a,b] of ed){const dx=b.x-a.x,dy=b.y-a.y;a.vx+=dx*.004*alpha;a.vy+=dy*.004*alpha;b.vx-=dx*.004*alpha;b.vy-=dy*.004*alpha}
   for(const n of nodes){n.vx*=.82;n.vy*=.82;n.x=Math.max(20,Math.min(W-20,n.x+n.vx));n.y=Math.max(20,Math.min(H-20,n.y+n.vy))}alpha*=.993};for(let k=0;k<300;k++)phys();
 const frame=()=>{
  if(alpha>.005)phys();
  x.clearRect(0,0,W,H);x.strokeStyle=V('--line');x.lineWidth=1.5;x.beginPath();for(const [a,b] of ed){x.moveTo(a.x,a.y);x.lineTo(b.x,b.y)}x.stroke();
  for(const n of nodes){x.fillStyle=col[n.t];x.shadowColor=col[n.t];x.shadowBlur=n===hov?24:8;x.beginPath();x.arc(n.x,n.y,n.t==='batch'?11:n.t==='startup'?7:6,0,7);x.fill()}x.shadowBlur=0;
  if(hov){x.font='24px sans-serif';const t=hov.l.slice(0,70),w=x.measureText(t).width+20;x.fillStyle=V('--pop');x.fillRect(hov.x+14,hov.y-30,w,36);x.fillStyle=V('--tx');x.fillText(t,hov.x+24,hov.y-5)}
  if(alpha>.005)requestAnimationFrame(frame);else run=0};
 const kick=()=>{if(!run){run=1;requestAnimationFrame(frame)}};
 cv.onmousemove=e=>{const b=cv.getBoundingClientRect(),mx=(e.clientX-b.left)*2,my=(e.clientY-b.top)*2,n=nodes.find(n=>Math.hypot(n.x-mx,n.y-my)<16)||null;if(n!==hov){hov=n;cv.style.cursor=n?'pointer':'default';kick()}};
 cv.onclick=()=>hov?.d&&open(hov.d);kick();
}
let tm;const lab=()=>{clearTimeout(tm);tm=setTimeout(async()=>{const q=$('#eq').value.trim();if(!q){$('#es').innerHTML='';return}
 let r;try{r=await J('/api/resolve?q='+encodeURIComponent(q)+'&domain='+encodeURIComponent($('#ed').value.trim()))}catch(e){$('#es').innerHTML='<div class="empty">Entity Lab needs the live server: <code>make dashboard</code></div>';return}const m=r.result.method;
 let html=r.stages.map(s=>`<div class="step ${s.hit&&s.stage===m?'hit':''}"><span>${s.hit?'✓':'·'}</span><b>${s.stage}</b><code>${E(s.key||'—')}</code></div>`).join('');
 html+=`<div class="step ${m==='fuzzy'?'hit':''}"><span>${m==='fuzzy'?'✓':'·'}</span><b>fuzzy</b><code>${m==='fuzzy'?'score '+r.result.score:'—'}</code></div><div class="step ${m==='new'?'hit':''}"><span>${m==='new'?'✓':'·'}</span><b>new canonical</b><code>${m==='new'?'registered':'—'}</code></div>`;
 $('#es').innerHTML=html;$('#er').className='';$('#er').innerHTML=`<div style="color:var(--mut)">${E(r.result.raw)} →</div><div class="big">${E(r.result.canonical)}</div><div style="margin-top:10px"><span class="tag">${m}</span> <span style="color:var(--mut)">score ${r.result.score}${r.result.is_new?' · not in seed list':''}</span></div>`},180)};
async function chaos(){const b=$('#cb');b.disabled=true;b.textContent='Injecting failures…';let r;try{r=await J('/api/chaos')}catch(e){b.disabled=false;b.textContent='Inject failures';$('#cr').innerHTML='<div class="empty">Chaos Mode runs the real engine, so it needs the live server: <code>make dashboard</code></div>';return}b.disabled=false;b.textContent='Run Chaos Mode again';
$('#cr').innerHTML=r.events.map((e,i)=>`<div class="step"><span>${i+1}</span><b>Tier ${e.tier}</b><span class="chip c${e.status}">${e.status}</span><code>${E(e.note)}</code></div>`).join('')+`<div class="ev"><h3 style="color:var(--ok)">${r.result?'Recovered':'Failed'} · served by ${E(r.provider)}</h3>Jittered backoffs (s): <b>${r.backoffs.join(', ')||'–'}</b> · 429s ${r.stats.r429} · 413s ${r.stats.r413} · fallbacks ${r.stats.fallbacks}<br>Extracted <mark>${E(JSON.stringify(r.result))}</mark> grounded by <mark>${E(JSON.stringify(r.evidence))}</mark></div>`}
async function momentum(){const m=await J('/api/momentum');$('#mm').innerHTML=m.length?m.map(r=>{const mx=Math.max(...r.h),mn=Math.min(...r.h),pts=r.h.map((v,i)=>`${i/Math.max(r.h.length-1,1)*80},${18-(mx===mn?9:(v-mn)/(mx-mn)*16)}`).join(' ');return `<div class="stat"><span>${E(r.repo.replace('https://github.com/',''))}</span><span><svg width="80" height="20"><polyline fill="none" stroke="#22d3ee" stroke-width="2" points="${pts}"/></svg> <b>★ ${r.stars.toLocaleString()}</b> <span class="tag">${r.delta>=0?'+':''}${r.delta}</span></span></div>`}).join(''):'<div class="empty">No star snapshots yet. Each papers run adds one.</div>'}
const go=v=>document.querySelector(`nav a[data-v=${v}]`).click(),sl=ms=>new Promise(r=>setTimeout(r,ms));let TOUR=0;
const CMD=[['Mission Control','page',()=>go('mission')],['Data & Evidence','page',()=>go('data')],['Freshness Radar','page',()=>go('fresh')],['Knowledge Graph','page',()=>go('graph')],['Entity Lab','page',()=>go('lab')],['Run Chaos Mode','action',()=>{go('mission');chaos()}],['Start auto demo','action',()=>tour()],['Search all records','action',()=>{go('data');$('#q').focus()}]];
function pal(on){$('#pal').classList.toggle('on',!!on);if(on){$('#pi').value='';pl();$('#pi').focus()}}
function pl(){const q=$('#pi').value.toLowerCase(),r=CMD.filter(c=>c[0].toLowerCase().includes(q));$('#pl').innerHTML=r.map((c,i)=>`<div class="it ${i?'':'f'}" data-i="${CMD.indexOf(c)}">${c[0]}<span>${c[1]}</span></div>`).join('');$('#pl').querySelectorAll('.it').forEach(el=>el.onclick=()=>{pal(0);CMD[el.dataset.i][2]()})}
$('#pi').oninput=pl;$('#pi').onkeydown=e=>{if(e.key==='Enter'){$('#pl .it')?.click()}};$('#pal').onclick=e=>{if(e.target.id==='pal')pal(0)};
document.addEventListener('keydown',e=>{if((e.metaKey||e.ctrlKey)&&e.key==='k'){e.preventDefault();pal(1)}if(e.key==='Escape'){pal(0);TOUR=0;closeDrawer()}
 if(e.key==='Tab'&&$('#drawer').classList.contains('open')){const f=[...$('#drawer').querySelectorAll('a[href],button,[tabindex="0"]')];if(f.length){const a=f[0],z=f[f.length-1];if(e.shiftKey&&document.activeElement===a){e.preventDefault();z.focus()}else if(!e.shiftKey&&document.activeElement===z){e.preventDefault();a.focus()}}}});
function cap(t,p){const b=$('#cap');b.innerHTML=`<span>${t}</span><i style="width:${p}%"></i>`;b.classList.add('on')}
async function tour(){if(TOUR)return;TOUR=1;$('#drawer').classList.remove('open');
 const st=[['mission','Every number is read from the pipeline output. No placeholder data, ever.',3800],['mission','Chaos Mode: the real engine survives injected 429 and 413 failures…',5200,chaos],['data','Click any row: source URL, verbatim evidence, raw record.',4600,()=>document.querySelector('tr.r')?.click()],['fresh','Freshness Radar: nothing older than 24 hours gets through.',4200],['graph','Knowledge graph: startups, products, papers, jobs and news linked by canonical entity.',5200],['lab','Entity resolution: “Open AI” resolves to OpenAI, deterministically.',4800,()=>{$('#eq').value='Open AI';$('#eq').dispatchEvent(new Event('input'))}]];
 for(const [i,[v,t,d,a]] of st.entries()){if(!TOUR)break;$('#drawer').classList.remove('open');go(v);cap(t,(i+1)/st.length*100);if(a)a();await sl(d)}
 $('#cap').classList.remove('on');TOUR=0;go('mission')}
[['#q','Filter rows'],['#eq','Messy entity name'],['#ed','Optional domain'],['#pi','Command palette']].forEach(([s,l])=>$(s).setAttribute('aria-label',l));
window.addEventListener('resize',()=>{if($('#fresh').classList.contains('on'))radar()});
const V=n=>getComputedStyle(document.documentElement).getPropertyValue(n).trim();
const IP={home:'<path d="M4 11l8-7 8 7v9H4z"/>',table:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M9 4v16"/>',clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',share:'<circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="6" r="2.5"/><circle cx="18" cy="18" r="2.5"/><path d="M8.2 11l7.6-3.8M8.2 13l7.6 3.8"/>',search:'<circle cx="11" cy="11" r="6"/><path d="m20 20-4-4"/>',play:'<path d="M7 4l13 8-13 8z"/>',compass:'<circle cx="12" cy="12" r="9"/><path d="m15 9-2 5-5 1 2-5z"/>',globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>',zap:'<path d="M13 3 5 14h6l-1 7 8-11h-6z"/>',merge:'<circle cx="6" cy="6" r="2.5"/><circle cx="6" cy="18" r="2.5"/><circle cx="18" cy="12" r="2.5"/><path d="M6 8.5v7M8.5 6C14 6 16 8 16 10"/>',db:'<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>',briefcase:'<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M9 7V4h6v3"/>',file:'<path d="M6 3h9l4 4v14H6z"/><path d="M9 12h7M9 16h7"/>',sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M5 19l1.5-1.5M17.5 6.5L19 5"/>',moon:'<path d="M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5z"/>'};
const ico=n=>`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${IP[n]}</svg>`;
$('#bd').innerHTML=ico('play')+' Auto demo';const dark=document.documentElement.dataset.theme==='dark';$('#th').innerHTML=ico(dark?'sun':'moon');
$('#th').onclick=()=>{try{localStorage.setItem('th',dark?'light':'dark')}catch(e){}location.reload()};
fetch('config.json').then(r=>r.json()).then(c=>{const ok=u=>/^https?:\/\//.test(u||'');$('#hlinks').innerHTML=(ok(c.sheetUrl)?`<a class="btnlink" href="${E(c.sheetUrl)}" target="_blank" rel="noopener noreferrer">Open the Google Sheet</a>`:'')+(ok(c.githubUrl)?`<a class="btnlink ghost" href="${E(c.githubUrl)}" target="_blank" rel="noopener noreferrer">View on GitHub</a>`:'')}).catch(()=>{});
function dl(){const {cols,all}=window.__csv,q=v=>'"'+String(Array.isArray(v)?v.join('; '):v??'').replace(/"/g,'""')+'"',csv=[cols.map(c=>q(c[0])).join(',')].concat(all.map(r=>cols.map(c=>q(g(r,c[1]))).join(','))).join('\n'),a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv'}));a.download=cur+'.csv';a.click()}
function trust(){const rows=Object.keys(T).flatMap(k=>(D[k]||[]).map(r=>[k,r])),R=S.report||{},f=R.stats?.fetch||{},l=R.stats?.llm||{},Q=R.validation||{},stale=(Q.jobs_stale_violations||0)+(Q.news_stale_violations||0);
 const miss=rows.filter(([,r])=>!/^https?:\/\//.test(r.source?.url||'')).length,seen=new Set();let dup=0;rows.forEach(([k,r])=>{const u=k+'|'+r.source?.url;seen.has(u)?dup++:seen.add(u)});
 const dm={};['jobs','news'].forEach(k=>(D[k]||[]).forEach(r=>{const m=r.content.date_method||'unknown';dm[m]=(dm[m]||0)+1}));const dt=Object.values(dm).reduce((a,b)=>a+b,0)||1;
 const st=(a,b,bad)=>`<div class="stat"><span>${a}</span><b style="color:${bad?'var(--bad)':'var(--ok)'}">${b}</b></div>`,pv=(a,b)=>`<div class="stat"><span>${a}</span><b>${b}</b></div>`;
 $('#trust').innerHTML=`<h3>Data trust</h3><div class="grid c3"><div><h3>Provenance</h3>${rows.length?st('Rows with a source URL',(rows.length-miss).toLocaleString()+' / '+rows.length.toLocaleString(),miss)+st('Duplicate source URLs',dup,dup)+st('Stale rows (24 h window)',stale,stale):'<div class="empty">No rows yet</div>'}</div><div><h3>Grounding and proof of work</h3>${pv('LLM calls',l.calls??'–')+pv('Dropped as ungrounded',l.ungrounded_drops??'–')+pv('429s survived',(f.r429||0)+(l.r429||0))+pv('413s shrunk',l.r413??0)+pv('Provider fallbacks',l.fallbacks??0)}</div><div><h3>How dates were determined</h3>${Object.entries(dm).map(([k,v])=>`<div class="stat" style="border:0;padding-bottom:0"><span>${E(k)}</span><b>${v}</b></div><div class="bar"><i style="width:${v/dt*100}%"></i></div>`).join('')||'<div class="empty">No jobs/news yet</div>'}</div></div>`}
$('#eq').oninput=lab;$('#ed').oninput=lab;init().then(momentum);
