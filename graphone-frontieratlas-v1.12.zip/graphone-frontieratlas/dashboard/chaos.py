"""Chaos Mode: runs the REAL LLMOrchestrator against an in-process mock LLM server that injects failures.
Tier A is permanently rate-limited (429 + Retry-After); tier B rejects big payloads (413) until the
adaptive chunker shrinks the document enough. Proves backoff, circuit breaker, fallback, 413 shrink and grounding."""
import asyncio, json, sys
from pathlib import Path
from aiohttp import web

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from graphone.llm import LLMOrchestrator, OpenAICompat  # noqa: E402

DOC = "\n".join(f"Paragraph {i}: markets moved {i * 7 % 97} percent as investors reacted to news cycle {i}." for i in range(700)) \
    + "\nThe round was led by ACME Robotics Ventures today.\n" + "\n".join(f"Analyst note {i}: valuation {i * 3 % 89} remains debated." for i in range(200))


async def run_chaos() -> dict:
    log: list[dict] = []

    async def tier_a(req):
        await req.read()
        log.append({"tier": "A", "status": 429, "note": "rate limited · Retry-After: 0"})
        return web.Response(status=429, headers={"Retry-After": "0"}, text="slow down")

    async def tier_b(req):
        txt = (await req.json())["messages"][1]["content"]
        if len(txt) > 8000:
            log.append({"tier": "B", "status": 413, "note": f"payload {len(txt):,} chars too large -> shrink"})
            return web.Response(status=413, text="payload too large")
        hit = "ACME Robotics Ventures" in txt
        out = {"company": "ACME Robotics Ventures" if hit else None, "evidence": {"company": "ACME Robotics Ventures"} if hit else {}}
        log.append({"tier": "B", "status": 200, "note": f"served {len(txt):,} chars"})
        return web.json_response({"choices": [{"message": {"content": json.dumps(out)}}]})

    app = web.Application()
    app.add_routes([web.post("/a", tier_a), web.post("/b", tier_b)])
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", 0)
    await site.start()
    port = site._server.sockets[0].getsockname()[1]

    class A(OpenAICompat):
        base = f"http://127.0.0.1:{port}/a"

    class B(OpenAICompat):
        base = f"http://127.0.0.1:{port}/b"

    sleeps: list[float] = []

    async def fake_sleep(d):  # record the jittered backoff without actually waiting
        sleeps.append(round(d, 2))
        await asyncio.sleep(0)
    try:
        chain = [A("mock-A", "k", "m", max_chars=30000, rpm=6000, concurrency=4), B("mock-B", "k", "m", max_chars=30000, rpm=6000, concurrency=4)]
        async with LLMOrchestrator(chain, sleep=fake_sleep, max_429=3) as llm:
            ex = await llm.extract(task="Who led the round?", fields={"company": "lead investor"}, text=DOC,
                                   url="https://example.com/chaos", required=("company",), keywords=("led by", "round"))
            stats = dict(llm.stats)
    finally:
        await runner.cleanup()
    return {"events": log, "backoffs": sleeps, "stats": stats, "provider": ex.provider if ex else None,
            "result": ex.data if ex else None, "evidence": ex.evidence if ex else None}
