"""FrontierAtlas Mission Control - serves the dashboard and a read-only JSON API over output/.
Usage:  PYTHONPATH=src python dashboard/server.py [--out output] [--port 8000]
No new dependencies (aiohttp is already required). Shows ONLY what the pipeline wrote: empty output = empty UI."""
import argparse, csv, json, shutil, sys
from collections import Counter
from pathlib import Path
from aiohttp import web

sys.path.insert(0, str(Path(__file__).parent))
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from graphone.resolver import EntityResolver, norm, compact, stripped, registrable  # noqa: E402

from chaos import run_chaos  # noqa: E402

NAMES = ["startups", "products", "papers", "jobs", "news"]
SEED = ROOT / "data" / "seed_entities.json"


def read_jsonl(p: Path) -> list:
    out = []
    if p.exists():
        for line in p.read_text(encoding="utf-8").splitlines():
            try:
                out.append(json.loads(line))
            except ValueError:
                pass
    return out


def read_mapping(out: Path) -> list:
    p = out / "entity_mapping_log.csv"
    if not p.exists():
        return []
    with open(p, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


async def summary(req):
    out: Path = req.app["out"]
    rp = out / "run_report.json"
    rep = json.loads(rp.read_text()) if rp.exists() else None
    counts = {n: len(read_jsonl(out / f"{n}.jsonl")) for n in NAMES}
    m = Counter(r["method"] for r in read_mapping(out))
    return web.json_response({"out": str(out), "counts": counts, "report": rep, "mapping": dict(m),
                              "snapshot": rp.stat().st_mtime if rp.exists() else None})


async def data(req):
    n = req.match_info["name"]
    if n not in NAMES:
        raise web.HTTPNotFound()
    return web.json_response(read_jsonl(req.app["out"] / f"{n}.jsonl"))


async def mapping(req):
    return web.json_response(read_mapping(req.app["out"]))


async def resolve(req):
    raw, dom = req.query.get("q", ""), req.query.get("domain") or None
    r = EntityResolver(SEED)          # fresh copy: playground never pollutes the real log
    n, k, s = norm(raw), compact(raw), stripped(raw)
    stages = [{"stage": "domain", "key": registrable(dom) if dom else "", "hit": bool(dom and r.domain.get(registrable(dom)))},
              {"stage": "alias", "key": n, "hit": n in r.alias},
              {"stage": "compact", "key": k, "hit": k in r.canon},
              {"stage": "stripped", "key": s, "hit": bool(s and s in r.strip)}]
    return web.json_response({"result": r.resolve(raw, dom, log=False).row(), "stages": stages})


async def chaos(req):
    return web.json_response(await run_chaos())


def momentum_rows(out: Path) -> list:
    by: dict = {}
    for r in sorted(read_jsonl(out / "star_history.jsonl"), key=lambda r: r.get("at") or ""):
        by.setdefault(r["repo"], []).append(r["stars"])
    rows = [{"repo": k, "stars": v[-1], "delta": v[-1] - v[0], "h": v[-12:]} for k, v in by.items()]
    return sorted(rows, key=lambda r: -r["stars"])[:12]


async def momentum(req):
    return web.json_response(momentum_rows(req.app["out"]))


async def metrics(req):
    rp = req.app["out"] / "run_report.json"
    rep = json.loads(rp.read_text()) if rp.exists() else {}
    lines = [f'graphone_records{{type="{k}"}} {v}' for k, v in (rep.get("counts") or {}).items()]
    for grp, d in (rep.get("stats") or {}).items():
        lines += [f'graphone_{grp}_{k} {v}' for k, v in d.items()]
    return web.Response(text="\n".join(lines) + "\n", content_type="text/plain")


def static_export(out: Path, dest: Path) -> None:
    """Write index.html + data/*.json so the dashboard works on GitHub Pages with no server."""
    (dest / "data").mkdir(parents=True, exist_ok=True)
    rp = out / "run_report.json"
    counts = {}
    for n in NAMES:
        rows = read_jsonl(out / f"{n}.jsonl")
        counts[n] = len(rows)
        (dest / "data" / f"{n}.json").write_text(json.dumps(rows), encoding="utf-8")
    (dest / "data" / "summary.json").write_text(json.dumps({
        "out": "static snapshot", "counts": counts, "report": json.loads(rp.read_text()) if rp.exists() else None,
        "mapping": dict(Counter(r["method"] for r in read_mapping(out))), "snapshot": rp.stat().st_mtime if rp.exists() else None}))
    (dest / "data" / "momentum.json").write_text(json.dumps(momentum_rows(out)))
    for f in ("index.html", "app.css", "app.js", "config.json"):
        (dest / f).write_bytes((Path(__file__).parent / f).read_bytes())
    shutil.copytree(Path(__file__).parent / "fonts", dest / "fonts", dirs_exist_ok=True)
    (dest / ".nojekyll").write_text("")


def make_app(out: Path) -> web.Application:
    app = web.Application()
    app["out"] = out
    app.router.add_static("/fonts", Path(__file__).parent / "fonts")
    app.add_routes([web.get("/", lambda r: web.FileResponse(Path(__file__).parent / "index.html")),
                    web.get("/config.json", lambda r: web.FileResponse(Path(__file__).parent / "config.json")), web.get("/app.css", lambda r: web.FileResponse(Path(__file__).parent / "app.css")), web.get("/app.js", lambda r: web.FileResponse(Path(__file__).parent / "app.js")),
                    web.get("/api/summary", summary), web.get("/api/data/{name}", data),
                    web.get("/api/mapping", mapping), web.get("/api/chaos", chaos), web.get("/api/momentum", momentum), web.get("/metrics", metrics), web.get("/api/resolve", resolve)])
    return app


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="output")
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--export", help="write a static site (GitHub Pages) to this folder and exit")
    a = ap.parse_args()
    if a.export:
        static_export(Path(a.out), Path(a.export))
        raise SystemExit(f"static site written to {a.export}/ - publish that folder (e.g. GitHub Pages /docs)")
    print(f"Mission Control -> http://localhost:{a.port}  (reading {a.out}/)")
    web.run_app(make_app(Path(a.out)), port=a.port, print=None)
