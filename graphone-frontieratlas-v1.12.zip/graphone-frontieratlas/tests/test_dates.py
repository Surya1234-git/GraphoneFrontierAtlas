from datetime import datetime, timedelta, UTC
from graphone.dates import parse_datetime, extract_published, is_fresh

NOW = datetime(2026, 11, 21, 12, 0, tzinfo=UTC)


def test_relative_forms():
    assert parse_datetime("2 hours ago", NOW) == NOW - timedelta(hours=2)
    assert parse_datetime("an hour ago", NOW) == NOW - timedelta(hours=1)
    assert parse_datetime("3d ago", NOW) == NOW - timedelta(days=3)
    assert parse_datetime("5m ago", NOW) == NOW - timedelta(minutes=5)
    assert parse_datetime("yesterday", NOW) == NOW - timedelta(days=1)
    assert parse_datetime("just now", NOW) == NOW


def test_not_confused_by_read_time():
    assert parse_datetime("2 min read", NOW) is None
    assert parse_datetime("garbage", NOW) is None


def test_timezones_and_epochs():
    assert parse_datetime("2026-11-21T10:00:00+05:30", NOW) == datetime(2026, 11, 21, 4, 30, tzinfo=UTC)
    assert parse_datetime("Published: Nov 20, 2026 3:00 PM EST", NOW) == datetime(2026, 11, 20, 20, 0, tzinfo=UTC)
    ms = int(datetime(2026, 11, 21, 9, tzinfo=UTC).timestamp() * 1000)
    assert parse_datetime(ms, NOW) == datetime(2026, 11, 21, 9, tzinfo=UTC)


def test_future_dates_rejected():
    assert parse_datetime("2030-01-01", NOW) is None


def test_html_priority_jsonld_over_meta():
    html = '''<html><head><meta property="article:published_time" content="2026-11-19T00:00:00Z">
    <script type="application/ld+json">{"@type":"NewsArticle","datePublished":"2026-11-21T08:00:00Z"}</script></head></html>'''
    r = extract_published(html, "", NOW)
    assert r.method == "jsonld" and r.dt.hour == 8


def test_html_fallbacks():
    assert extract_published('<meta name="date" content="2026-11-21">', "", NOW).method == "meta:date"
    assert extract_published("<p>Posted 3 hours ago by staff</p>", "", NOW).method == "relative-text"
    r = extract_published("<p>nothing</p>", "https://x.com/2026/11/20/story", NOW)
    assert r.method == "url-path" and r.dt.day == 20
    assert extract_published("<p>nothing</p>", "https://x.com/s", NOW).dt is None


def test_freshness_window():
    assert is_fresh(NOW - timedelta(hours=23, minutes=59), NOW)
    assert not is_fresh(NOW - timedelta(hours=24, minutes=1), NOW)
    assert not is_fresh(NOW + timedelta(hours=2), NOW)
    assert not is_fresh(None, NOW)
