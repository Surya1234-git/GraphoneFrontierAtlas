import csv
import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import build_heldout_candidates as hc  # noqa: E402
import eval_resolver  # noqa: E402
import finalize_submission as fin  # noqa: E402
import make_llm_trace as mlt  # noqa: E402
import screenshots  # noqa: E402
import submit_check as sc  # noqa: E402


def jl(p: Path, rows):
    p.write_text("\n".join(json.dumps(r) for r in rows) + "\n", encoding="utf-8")


def synthetic_output(out: Path, n: int = 1000):
    out.mkdir(exist_ok=True)
    jl(out / "startups.jsonl", [{"source": {"url": f"https://s/{i}"}, "content": {"entityName": f"S{i}"}} for i in range(n)])
    jl(out / "products.jsonl", [{"source": {"url": f"https://p/{i}"}, "content": {"startupName": f"S{i}"}} for i in range(n)])
    jl(out / "papers.jsonl", [{"source": {"url": f"https://a/{i}"}, "content": {"github_url": "https://github.com/a/b", "github_stars": i}} for i in range(n)])
    for name in ("jobs", "news"):
        jl(out / f"{name}.jsonl", [])
    (out / "run_report.json").write_text(json.dumps({"stats": {"fetch": {"requests": 5}, "llm": {"calls": 0}}}), encoding="utf-8")
    (out / "entity_mapping_log.csv").write_text("raw,canonical,method,score,is_new\n", encoding="utf-8")


def test_finalize_refuses_without_a_run_report(tmp_path):
    assert "run_report.json is missing" in fin.check(tmp_path)[0]
    assert fin.main(["--out", str(tmp_path), "--check-only"]) == 1


def test_finalize_lists_every_unmet_requirement(tmp_path):
    synthetic_output(tmp_path, n=3)
    f = "\n".join(fin.check(tmp_path))
    assert "startups: 3 rows" in f and "products: 3 rows" in f and "papers: 3 rows" in f


def test_finalize_passes_on_a_complete_output_and_flags_missing_urls(tmp_path):
    synthetic_output(tmp_path)
    assert fin.check(tmp_path) == []
    rows = [json.loads(x) for x in (tmp_path / "startups.jsonl").read_text(encoding="utf-8").splitlines()]
    rows[0]["source"]["url"] = ""
    jl(tmp_path / "startups.jsonl", rows)
    assert any("without a valid http(s) source URL" in x for x in fin.check(tmp_path))


def test_results_block_is_generated_from_files_and_replaced_in_place(tmp_path):
    synthetic_output(tmp_path)
    readme = tmp_path / "README.md"
    readme.write_text("# T\n\ntext\n", encoding="utf-8")
    fin.write_block(readme, fin.results_block(tmp_path))
    fin.write_block(readme, fin.results_block(tmp_path))          # second call replaces, never duplicates
    t = readme.read_text(encoding="utf-8")
    assert t.count(fin.START) == 1 and "| Startups | 1,000 |" in t and "text" in t


def test_llm_trace_refuses_missing_empty_and_mock(tmp_path):
    with pytest.raises(SystemExit):
        mlt.load(tmp_path / "nope.jsonl")
    p = tmp_path / "e.jsonl"
    p.write_text(json.dumps({"provider": "mock-A", "status": 200}) + "\n", encoding="utf-8")
    with pytest.raises(SystemExit):
        mlt.load(p)


def test_llm_trace_renders_real_sequences(tmp_path):
    base = {"ts": "2026-01-01T00:00:00+00:00", "attempt": 1, "backoff_s": None, "shrunk_to_chars": None, "fallback_to": None}
    ev = [{**base, "provider": "gemini", "status": 429, "backoff_s": 1.2}, {**base, "provider": "gemini", "status": 413, "shrunk_to_chars": 9000},
          {**base, "provider": "gemini", "status": None, "fallback_to": "groq"}, {**base, "provider": "groq", "status": 200}]
    md = mlt.build(ev)
    assert "| gemini | 0 | 1 | 1 | 1 |" in md and "### Sequence 1" in md and "9000" in md


def test_screenshots_refuse_missing_or_empty_docs(tmp_path):
    assert "missing" in screenshots.precheck(tmp_path)
    (tmp_path / "data").mkdir()
    (tmp_path / "index.html").write_text("x", encoding="utf-8")
    (tmp_path / "data" / "summary.json").write_text(json.dumps({"counts": {"startups": 0}}), encoding="utf-8")
    assert "no records" in screenshots.precheck(tmp_path)
    (tmp_path / "data" / "summary.json").write_text(json.dumps({"counts": {"startups": 4}}), encoding="utf-8")
    assert screenshots.precheck(tmp_path) is None


def test_heldout_candidates_come_from_the_real_log_only(tmp_path):
    with pytest.raises(SystemExit):
        hc.sample(tmp_path / "missing.csv")
    p = tmp_path / "log.csv"
    p.write_text("raw,canonical,method,score,is_new\n" + "".join(f"Name {i},Name {i},new,0,True\n" for i in range(10)), encoding="utf-8")
    assert len(hc.sample(p, 4)) == 4 and hc.sample(p, 4) == hc.sample(p, 4)


def test_eval_refuses_unlabeled_rows(tmp_path):
    p = tmp_path / "c.csv"
    with open(p, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["raw", "domain", "expected"])
        w.writerow(["Open AI", "", "OpenAI"])
        w.writerow(["Mystery Co", "", ""])
    with pytest.raises(ValueError, match="unlabeled"):
        eval_resolver.evaluate(str(p))


def test_submit_check_finds_secrets_placeholders_and_unset_links(tmp_path):
    (tmp_path / "dashboard").mkdir()
    (tmp_path / "dashboard" / "config.json").write_text('{"sheetUrl": "", "githubUrl": ""}', encoding="utf-8")
    (tmp_path / "README.md").write_text("# T\nTODO: add the link\n", encoding="utf-8")
    (tmp_path / "leak.py").write_text("k = '" + "AIza" + "x" * 35 + "'\n", encoding="utf-8")
    msgs = "\n".join(sc.problems(tmp_path))
    assert "possible secret in leak.py" in msgs and "README placeholder" in msgs and "sheetUrl" in msgs and "githubUrl" in msgs


def test_repo_itself_has_no_secrets():
    assert sc.scan_secrets(ROOT) == []
