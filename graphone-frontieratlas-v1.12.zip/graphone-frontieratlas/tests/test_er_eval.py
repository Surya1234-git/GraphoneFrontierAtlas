import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from eval_resolver import evaluate  # noqa: E402


def test_labelled_entity_resolution_accuracy():
    m = evaluate()
    assert m["n"] >= 100
    assert m["precision"] >= 0.99 and m["recall"] >= 0.97, m["fails"]
    assert m["negatives_rejected"] == m["negatives"], m["fails"]  # look-alike companies must never merge


def test_heldout_real_github_orgs():
    m = evaluate("er_heldout.csv")
    assert m["n"] >= 200 and m["precision"] >= 0.99 and m["recall"] >= 0.95
    assert m["negatives_rejected"] == m["negatives"], m["fails"]
