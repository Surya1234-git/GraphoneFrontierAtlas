import json
from graphone.grounding import verify
from graphone.llm import (LLMOrchestrator, Provider, RateLimited, PayloadTooLarge, Fatal, Transient,
                          classify_error, parse_json)

SRC = "Acme Corp builds robots. The team has 1,250 employees. Pricing: Free plan available; Pro is $20/month."


def test_grounding_keeps_supported_drops_hallucinated():
    data = {"employees": 1250, "ceo": "Jane Doe", "pricingModel": "FREEMIUM", "city": "Paris"}
    ev = {"employees": "The team has 1,250 employees", "ceo": "CEO Jane Doe", "pricingModel": "Free plan available; Pro is $20/month"}
    rep = verify(data, ev, SRC, required=("employees",), enums={"pricingModel": {"FREE", "FREEMIUM"}})
    assert rep.kept == {"employees": 1250, "pricingModel": "FREEMIUM"}
    assert "ceo" in rep.dropped and "city" in rep.dropped and rep.ok


def test_grounding_rejects_wrong_number_and_missing_required():
    rep = verify({"employees": 9999}, {"employees": "The team has 1,250 employees"}, SRC, required=("employees",))
    assert not rep.ok


def test_classify_errors():
    assert isinstance(classify_error(429, "slow", "7"), RateLimited) and classify_error(429, "", "7").retry_after == 7
    assert isinstance(classify_error(413, "Request too large"), PayloadTooLarge)
    assert isinstance(classify_error(400, "input token count exceeds the maximum"), PayloadTooLarge)
    assert isinstance(classify_error(503, "x"), Transient)
    assert isinstance(classify_error(401, "x"), Fatal)


def test_parse_json_fences():
    assert parse_json('```json\n{"a": 1}\n```') == {"a": 1}
    assert parse_json('Sure! {"a": {"b": 2}} done') == {"a": {"b": 2}}


class Fake(Provider):
    """Scripted provider: script items are exceptions to raise or dicts to return."""
    def __init__(self, name, script, max_chars=100_000):
        super().__init__(name, "k", "m", max_chars=max_chars, rpm=100000)
        self.script, self.seen_lens = list(script), []

    async def complete(self, session, system, user):
        self.seen_lens.append(len(user))
        step = self.script.pop(0) if self.script else self.script_last
        if isinstance(step, Exception):
            raise step
        return json.dumps(step)


GOOD = {"employees": 1250, "evidence": {"employees": "The team has 1,250 employees"}}


async def no_sleep(_): pass


def orch(*providers, **kw):
    o = LLMOrchestrator(list(providers), sleep=no_sleep, **kw)
    return o


async def run(o, text=SRC):
    return await o.extract(task="t", fields={"employees": "int"}, text=text, url="https://x.com", required=("employees",))


async def test_happy_path_first_tier():
    a = Fake("gemini", [GOOD])
    ex = await run(orch(a))
    assert ex.provider == "gemini" and ex.data == {"employees": 1250}


async def test_429_backoff_then_success_same_tier():
    a = Fake("gemini", [RateLimited("x"), RateLimited("x", 2.0), GOOD])
    o = orch(a)
    ex = await run(o)
    assert ex.provider == "gemini" and o.stats["r429"] == 2


async def test_429_exhausted_falls_to_next_tier():
    a = Fake("gemini", [RateLimited("x")] * 10)
    b = Fake("groq", [GOOD])
    o = orch(a, b, max_429=2)
    ex = await run(o)
    assert ex.provider == "groq" and o.stats["fallbacks"] == 1


async def test_413_shrinks_payload_then_succeeds():
    big = "\n".join(f"Paragraph {i} about nothing in particular, with filler words." for i in range(4000)) + "\n" + SRC
    a = Fake("groq", [PayloadTooLarge("x"), PayloadTooLarge("x"), GOOD], max_chars=40_000)
    o = orch(a)
    ex = await run(o, big)
    assert ex.provider == "groq" and ex.truncated
    assert a.seen_lens[0] > a.seen_lens[1] > a.seen_lens[2]          # monotonically shrinking
    assert a.max_chars < 40_000                                       # learned budget remembered


async def test_fatal_disables_and_chain_continues():
    a = Fake("gemini", [Fatal("auth")])
    b = Fake("deepseek", [GOOD])
    o = orch(a, b)
    assert (await run(o)).provider == "deepseek" and a.disabled


async def test_hallucination_is_rejected_across_all_tiers():
    bad = {"employees": 5000, "evidence": {"employees": "The team has 5,000 employees"}}  # quote not in source
    o = orch(Fake("gemini", [bad]), Fake("groq", [bad]))
    assert await run(o) is None


async def test_ungrounded_tier_falls_back_to_grounded_tier():
    bad = {"employees": 5000, "evidence": {"employees": "invented quote"}}
    ex = await run(orch(Fake("gemini", [bad]), Fake("groq", [GOOD])))
    assert ex.provider == "groq"


async def test_invalid_json_repaired_once():
    class Junk(Fake):
        n = 0
        async def complete(self, s, sy, u):
            Junk.n += 1
            return "not json at all" if Junk.n == 1 else json.dumps(GOOD)
    ex = await run(orch(Junk("gemini", [])))
    assert ex.data["employees"] == 1250
