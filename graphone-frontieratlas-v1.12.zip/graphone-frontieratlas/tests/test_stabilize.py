import csv
import json
import random
from pathlib import Path

from graphone.resolver import EntityResolver
from graphone.stabilize import apply_stable_names, stable_names

SEED = Path(__file__).resolve().parents[1] / "data" / "seed_entities.json"
NAMES = ["ACME Inc", "Acme, Inc.", "Acme", "ACME Corp", "Zenith Labs", "Zenith Labs Inc", "OpenAI", "Open AI", "Quantum Forge", "quantum forge Ltd"]


def final_names(order):
    r = EntityResolver(SEED)
    out = [r.resolve(n, log=True) for n in order]
    mp = stable_names(((x.raw, x.canonical) for x in out), r.seed_names)
    return {x.raw: mp.get(x.canonical, x.canonical) for x in out}


def test_final_canonical_names_do_not_depend_on_processing_order():
    ref = final_names(NAMES)
    rnd = random.Random(7)
    for _ in range(60):
        order = NAMES[:]
        rnd.shuffle(order)
        assert final_names(order) == ref
    assert ref["OpenAI"] == ref["Open AI"] == "OpenAI"      # seed names are never renamed
    assert len({ref["ACME Inc"], ref["Acme, Inc."], ref["Acme"], ref["ACME Corp"]}) == 1


def test_non_seed_domains_never_merge_organisations():
    r = EntityResolver(SEED)
    a, b = r.resolve("NVIDIA-NeMo", "https://docs.nvidia.com/nemo", log=False), r.resolve("triton-inference-server", "https://docs.nvidia.com/triton", log=False)
    assert a.canonical != b.canonical


def test_apply_rewrites_log_and_jsonl(tmp_path):
    rows = [("ACME Inc", "ACME"), ("Acme, Inc.", "ACME"), ("Acme", "ACME")]
    with open(tmp_path / "entity_mapping_log.csv", "w", newline="") as f:
        w = csv.DictWriter(f, ["raw", "canonical", "method", "score", "is_new"])
        w.writeheader()
        w.writerows({"raw": a, "canonical": b, "method": "new", "score": 100, "is_new": False} for a, b in rows)
    (tmp_path / "startups.jsonl").write_text(json.dumps({"content": {"entityName": "ACME"}}) + "\n")
    mp = apply_stable_names(tmp_path, set())
    assert mp == {"ACME": "Acme"} and json.loads((tmp_path / "startups.jsonl").read_text())["content"]["entityName"] == "Acme"
