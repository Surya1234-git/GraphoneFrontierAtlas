import json
from dataclasses import dataclass
from pathlib import Path

from graphone.llm import LLMOrchestrator, Provider
from graphone.resolver import EntityResolver, fold

SEED = Path(__file__).resolve().parents[1] / "data" / "seed_entities.json"


def test_confusable_typos_resolve():
    r = EntityResolver(SEED)
    assert r.resolve("OpenAl").canonical == "OpenAI" and r.resolve("OpenAl").method == "confusable"
    assert r.resolve("Anthr0pic").canonical == "Anthropic"


def test_fold_never_merges_distinct_seed_entities():
    seen = {}
    for e in json.loads(SEED.read_text()):
        from graphone.resolver import compact
        k = fold(compact(e["canonical"]))
        assert seen.setdefault(k, e["canonical"]) == e["canonical"], (k, e["canonical"], seen[k])


@dataclass
class Fake(Provider):
    async def complete(self, session, system, user):
        doc = user.split("DOCUMENT:", 1)[1]
        out = {"company": None, "evidence": {}}
        if "ACME Robotics" in doc:
            out = {"company": "ACME Robotics", "evidence": {"company": "ACME Robotics"}}
        return json.dumps(out)


async def test_map_reduce_finds_fact_in_last_chunk():
    text = "\n".join(f"Filler paragraph number {i} about nothing in particular." for i in range(120)) + "\nThe deal was led by ACME Robotics today."
    async with LLMOrchestrator([Fake("fake", "k", "m", max_chars=1000, rpm=6000, concurrency=8)]) as llm:
        ex = await llm.extract_long(task="t", fields={"company": "name"}, text=text, url="https://x.co", required=("company",))
    assert ex and ex.data["company"] == "ACME Robotics" and ex.truncated
    assert llm.stats["calls"] >= 5


def test_is_ai_is_strict():
    from graphone.sources.yc import is_ai
    assert not is_ai({"name": "PayrollCo", "one_liner": "Global payroll", "long_description": "We use AI to help teams get paid."})
    assert is_ai({"name": "X", "one_liner": "Rebuilding healthcare with AI", "tags": []})
    assert is_ai({"name": "Y", "one_liner": "Tools", "tags": [], "industries": ["Machine Learning"]})


def test_shared_hosting_homepages_never_merge_orgs():
    r = EntityResolver(SEED)
    a = r.resolve("alpha-labs", "https://github.com/alpha-labs/repo", log=False)
    b = r.resolve("beta-works", "https://github.com/beta-works", log=False)
    c = r.resolve("gamma-ai", "https://arxiv.org/abs/2401.00001", log=False)
    assert len({a.canonical, b.canonical, c.canonical}) == 3 and not b.canonical == "alpha-labs"


def test_subdomains_reduce_to_registrable_domain():
    from graphone.resolver import registrable
    assert registrable("https://developers.llamaindex.ai/x") == "llamaindex.ai" and registrable("a.b.bbc.co.uk") == "bbc.co.uk"
    assert EntityResolver(SEED).resolve("run-llama", "https://developers.llamaindex.ai", log=False).canonical == "LlamaIndex"
