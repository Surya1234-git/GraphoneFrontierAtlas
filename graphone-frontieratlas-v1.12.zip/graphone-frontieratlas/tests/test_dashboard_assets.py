from pathlib import Path

D = Path(__file__).resolve().parents[1] / "dashboard"


def test_css_braces_balanced():
    depth = 0
    for ch in (D / "app.css").read_text(encoding="utf-8"):
        depth += (ch == "{") - (ch == "}")
        assert depth >= 0, "stray closing brace in app.css"
    assert depth == 0


def test_index_has_no_decorative_glyphs_or_dead_effects():
    html = (D / "index.html").read_text(encoding="utf-8")
    assert not any(g in html for g in "◉▤◔✦") and "aurora" not in html
    assert "aurora" not in (D / "app.css").read_text(encoding="utf-8")


def test_accent_meets_contrast():
    def lum(h):
        c = [int(h[i:i + 2], 16) / 255 for i in (1, 3, 5)]
        c = [x / 12.92 if x <= .03928 else ((x + .055) / 1.055) ** 2.4 for x in c]
        return .2126 * c[0] + .7152 * c[1] + .0722 * c[2]
    css = (D / "app.css").read_text(encoding="utf-8")
    accent = css.split("[data-theme=light]{")[1].split("--a:")[1][:7]
    assert 1.05 / (lum(accent) + .05) >= 4.5, accent          # white text on the accent colour
    assert (lum("#FBF8F4") + .05) / (lum(accent) + .05) >= 4.5  # accent text on the page background


def test_nav_icons_are_in_the_html_source_and_font_is_self_hosted():
    import re
    html = (D / "index.html").read_text(encoding="utf-8")
    links = re.findall(r"<a href=\"#\w+\" data-v=[^>]*>.*?</a>", html)
    assert len(links) == 5 and all("<svg" in link for link in links)
    assert (D / "fonts" / "inter-latin-wght-normal.woff2").stat().st_size > 10_000
    assert "fonts/inter-latin-wght-normal.woff2" in (D / "app.css").read_text(encoding="utf-8")
    assert "fonts.googleapis" not in html


def test_app_js_parses():
    import shutil
    import subprocess

    import pytest
    if not shutil.which("node"):
        pytest.skip("node not installed")
    r = subprocess.run(["node", "--check", str(D / "app.js")], capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
