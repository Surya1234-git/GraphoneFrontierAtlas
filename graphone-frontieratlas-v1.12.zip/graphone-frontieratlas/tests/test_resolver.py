import json
from pathlib import Path
from graphone.resolver import EntityResolver

SEED = Path(__file__).parents[1] / "data" / "seed_entities.json"


def r():
    return EntityResolver(SEED)


def test_seed_has_50():
    assert len(json.loads(SEED.read_text())) >= 50


def test_task_example_openai():
    e = r()
    for raw in ["OpenAI", "OpenAI, Inc.", "Open AI", "openai", "OPENAI INC", "Open-AI"]:
        assert e.resolve(raw).canonical == "OpenAI", raw


def test_methods_and_domain():
    e = r()
    assert e.resolve("Anysphere, Inc.").canonical == "Cursor"
    assert e.resolve("Cohere AI").canonical == "Cohere"
    assert e.resolve("Totally Unknown Name", domain="https://www.anthropic.com/x").canonical == "Anthropic"
    assert e.resolve("W&B").canonical == "Weights & Biases"
    assert e.resolve("Mistral").method in ("alias", "stripped")


def test_typos_fuzzy_but_no_false_merge():
    e = r()
    assert e.resolve("Anthropik").canonical == "Anthropic"
    assert e.resolve("Perplexity Inc").canonical == "Perplexity AI"
    # lookalike but distinct companies must NOT merge
    assert e.resolve("Cohere Health").is_new
    assert e.resolve("Scalar AI").canonical != "Scale AI"


def test_dynamic_canonicalization_of_unknown():
    e = r()
    a = e.resolve("Zephyr Robotics, Inc.")
    assert a.is_new and a.canonical == "Zephyr Robotics"
    b = e.resolve("Zephyr Robotics")
    assert b.canonical == "Zephyr Robotics" and not b.is_new


def test_deterministic_and_logged(tmp_path):
    inputs = ["Open AI", "Zed Labs", "Zed Labs Inc", "Groq, Inc."]
    out1 = [x.canonical for x in map(r().resolve, inputs)]
    out2 = [x.canonical for x in map(r().resolve, inputs)]
    assert out1 == out2
    e = r()
    for i in inputs:
        e.resolve(i)
    e.write_log(tmp_path / "l.csv")
    assert len((tmp_path / "l.csv").read_text().splitlines()) == 5
