import asyncio
from pathlib import Path

import pytest

from graphone.resolver import EntityResolver
from graphone.sources.products import repo_to_product

SEED = Path(__file__).resolve().parents[1] / "data" / "seed_entities.json"


class C:  # minimal ctx
    resolver = EntityResolver(SEED)


def repo(**kw):
    base = {"id": 1, "name": "transformers", "html_url": "https://github.com/huggingface/transformers", "fork": False, "archived": False,
            "owner": {"login": "huggingface", "type": "Organization"}, "license": {"spdx_id": "Apache-2.0"},
            "homepage": "https://huggingface.co/transformers", "stargazers_count": 150000, "description": "Models"}
    return {**base, **kw}


def test_repo_to_product_is_fact_only():
    rec = repo_to_product(C, repo())
    c = rec["content"]
    assert rec["source"]["url"].startswith("https://github.com/") and c["startupName"] == "Hugging Face"
    assert c["pricingModel"] == "FREE" and "Apache-2.0" in c["pricingEvidence"] and c["githubStars"] == 150000


@pytest.mark.parametrize("kw", [{"fork": True}, {"archived": True}, {"license": None}, {"license": {"spdx_id": "NOASSERTION"}},
                                {"owner": {"login": "someone", "type": "User"}}])
def test_repo_to_product_rejects_unqualified(kw):
    assert repo_to_product(C, repo(**kw)) is None


async def test_redis_exactly_once_across_two_workers():
    fakeredis = pytest.importorskip("fakeredis.aioredis")
    from graphone.state import RedisState
    st = RedisState.__new__(RedisState)
    st.r = fakeredis.FakeRedis(decode_responses=True)
    wins = await asyncio.gather(*(st.claim("news", "k1") for _ in range(20)))  # 20 concurrent "workers"
    assert sum(wins) == 1
    await st.commit("news", "k1")
    assert not await st.claim("news", "k1")           # committed -> never again, on any node
    assert await st.claim("news", "k2") and not await st.claim("news", "k2")
    await st.release("news", "k2")
    assert await st.claim("news", "k2")               # crashed worker's item is retried
