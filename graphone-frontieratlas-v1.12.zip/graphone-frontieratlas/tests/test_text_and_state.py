from graphone.textclean import smart_truncate, canonical_url
from graphone.state import SqliteState, FreshnessGate, url_key
from datetime import datetime, timedelta, UTC

NOW = datetime(2026, 11, 21, 12, tzinfo=UTC)


def test_truncate_never_exceeds_and_keeps_dense():
    lede = "Acme raised $50 million Series B led by Foo Capital to expand its AI platform."
    filler = ["Subscribe to our newsletter for more." for _ in range(50)] + ["lorem ipsum dolor sit amet " * 8 for _ in range(300)]
    dense = "Revenue grew 340% to $12.5 million in 2025 across 1,200 customers."
    ending = "Acme plans to hire 200 engineers by Q3."
    text = "\n".join([lede] + filler[:150] + [dense] + filler[150:] + [ending])
    out = smart_truncate(text, 2000, keywords=("revenue",))
    assert len(out) <= 2000
    assert lede in out and ending in out and dense in out
    assert out.count("Subscribe") <= 1


def test_truncate_small_text_untouched_and_giant_paragraph():
    assert smart_truncate("hello world", 100) == "hello world"
    big = " ".join(f"Sentence number {i} mentions 42 items." for i in range(5000))
    assert len(smart_truncate(big, 3000)) <= 3000


def test_canonical_url():
    assert canonical_url("http://www.Example.com/a/b/?utm_source=x&id=2#frag") == "https://example.com/a/b?id=2"


async def test_claim_commit_release_and_lease():
    s = SqliteState(":memory:")
    assert await s.claim("n", "k")
    assert not await s.claim("n", "k")           # lease held by another worker
    await s.release("n", "k")
    assert await s.claim("n", "k")               # crashed worker -> retried
    await s.commit("n", "k")
    assert not await s.claim("n", "k")           # processed once, never again


async def test_expired_lease_is_reclaimable():
    s = SqliteState(":memory:")
    assert await s.claim("n", "k", lease_s=-1)
    assert await s.claim("n", "k")


async def test_gate_dated_and_stale():
    g = FreshnessGate(SqliteState(":memory:"))
    k = url_key("https://a.com/x")
    assert (await g.decide("s", k, NOW - timedelta(hours=3), NOW))[0]
    assert not (await g.decide("s", k, NOW - timedelta(hours=3), NOW))[0]   # duplicate across nodes
    assert (await g.decide("s", "k2", NOW - timedelta(hours=30), NOW)) == (False, "stale")


async def test_gate_first_seen_heuristic_needs_baseline():
    st = SqliteState(":memory:")
    g = FreshnessGate(st)
    # run 1: undated back-catalogue must NOT look 'new'
    assert (await g.decide("src", "old1", None, NOW))[0] is False
    await st.set_baselined("src")
    # run 2: old1 still not new; a genuinely unseen item is accepted
    assert (await g.decide("src", "old1", None, NOW))[0] is False
    ok, why = await g.decide("src", "brand-new", None, NOW)
    assert ok and why == "first-seen-heuristic"
