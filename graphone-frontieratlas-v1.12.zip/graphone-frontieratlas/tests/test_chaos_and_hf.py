import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "dashboard"))
from chaos import run_chaos  # noqa: E402
from graphone.sources.papers import parse_hf_daily  # noqa: E402


async def test_chaos_mode_recovers_with_grounded_result():
    r = await run_chaos()
    assert r["result"] == {"company": "ACME Robotics Ventures"} and r["provider"] == "mock-B"
    assert r["stats"]["r429"] >= 1 and r["stats"]["r413"] >= 1 and r["stats"]["fallbacks"] == 1
    assert r["backoffs"] and r["events"][-1]["status"] == 200


def test_parse_hf_daily_keeps_repo_and_skips_incomplete():
    items = [{"paper": {"id": "2401.00001", "title": "A  Paper", "authors": [{"name": "X"}, {"name": "H", "hidden": True}],
                        "publishedAt": "2024-01-01T00:00:00.000Z", "githubRepo": "https://github.com/a/b"}},
             {"paper": {"id": "2401.00002", "title": "No authors", "authors": []}}, {"nothing": 1}]
    out = parse_hf_daily(items)
    assert len(out) == 1 and out[0]["authors"] == ["X"] and out[0]["repo"] == "https://github.com/a/b" and out[0]["title"] == "A Paper"
