import csv
import json
import os
import subprocess
import sys
from pathlib import Path

from graphone.llm import LLMOrchestrator
from graphone.resolver import EntityResolver
from graphone.stabilize import apply_stable_names

ROOT = Path(__file__).resolve().parents[1]
SEED = ROOT / "data" / "seed_entities.json"


def test_write_path_survives_non_utf8_locale(tmp_path):
    code = ("from graphone.resolver import EntityResolver\n"
            f"r = EntityResolver(r'{SEED}')\nr.resolve('Soci\\u00e9t\\u00e9 G\\u00e9n\\u00e9rale AI')\nr.write_log(r'{tmp_path / 'log.csv'}')\n")
    env = {**os.environ, "LC_ALL": "C", "PYTHONUTF8": "0", "PYTHONCOERCECLOCALE": "0", "PYTHONPATH": str(ROOT / "src")}
    res = subprocess.run([sys.executable, "-c", code], env=env, capture_output=True, text=True)
    assert res.returncode == 0, res.stderr
    assert "Soci\u00e9t\u00e9 G\u00e9n\u00e9rale AI" in (tmp_path / "log.csv").read_text(encoding="utf-8")


def _rows(p):
    with open(p, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def test_mapping_log_merges_across_sequential_runs(tmp_path):
    p = tmp_path / "entity_mapping_log.csv"
    for name in ("Open AI", "Stripe"):          # e.g. `run startups` then `run products`
        r = EntityResolver(SEED)
        r.resolve(name)
        r.write_log(p)
    assert {x["raw"] for x in _rows(p)} == {"Open AI", "Stripe"}
    r = EntityResolver(SEED)
    r.resolve("Open AI")
    r.write_log(p)                               # same pair again: deduped, nothing lost
    assert len(_rows(p)) == 2 and not list(tmp_path.glob("*.tmp"))


def test_stabilize_unifies_names_from_different_invocations_and_is_atomic(tmp_path):
    p = tmp_path / "entity_mapping_log.csv"
    for batch in (["ACME Inc"], ["Acme, Inc.", "Acme"]):
        r = EntityResolver(SEED)
        for n in batch:
            r.resolve(n)
        r.write_log(p)
    (tmp_path / "startups.jsonl").write_text(json.dumps({"content": {"entityName": "ACME"}}) + "\n", encoding="utf-8")
    apply_stable_names(tmp_path, EntityResolver(SEED).seed_names)
    assert len({x["canonical"] for x in _rows(p)}) == 1 and not list(tmp_path.glob("*.tmp"))
    assert json.loads((tmp_path / "startups.jsonl").read_text(encoding="utf-8"))["content"]["entityName"] == next(iter({x["canonical"] for x in _rows(p)}))


async def test_orchestrator_writes_structured_events(tmp_path):
    from tests.test_improvements import Fake  # provider that answers from the document
    ev = tmp_path / "llm_events.jsonl"
    async with LLMOrchestrator([Fake("fake", "k", "m", max_chars=1000, rpm=6000, concurrency=2)], event_log=ev) as llm:
        await llm.extract(task="t", fields={"company": "x"}, text="ACME Robotics wins.", url="https://x.co", required=("company",))
    e = [json.loads(line) for line in ev.read_text(encoding="utf-8").splitlines()]
    assert e and e[0]["provider"] == "fake" and e[0]["status"] == 200 and set(e[0]) >= {"ts", "attempt", "backoff_s", "shrunk_to_chars", "fallback_to"}
