"""Integration tests against a local aiohttp server: 429/Retry-After, Cloudflare-style challenge,
robots.txt, pricing classification and the full news/product record paths. No internet needed."""
import json
import pytest
import feedparser
from datetime import datetime, timedelta, UTC
from aiohttp import web

from graphone.config import Settings
from graphone.context import Ctx, JsonlSink
from graphone.fetcher import Fetcher, BlockedError, FetchError, looks_blocked
from graphone.llm import LLMOrchestrator
from graphone.resolver import EntityResolver
from graphone.state import SqliteState, FreshnessGate
from graphone.sources import products, news, papers, jobs

NOW = datetime.now(UTC)
ART = "<p>" + ("Acme Robotics announced a new model today with significant improvements across benchmarks. " * 6) + "</p>"


def iso(dt): return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def make_app(hits):
    async def flaky(req):
        hits["flaky"] = hits.get("flaky", 0) + 1
        if hits["flaky"] < 3:
            return web.Response(status=429, headers={"Retry-After": "0"}, text="slow down")
        return web.json_response({"ok": True})

    async def cf(req):
        return web.Response(status=403, headers={"server": "cloudflare", "cf-mitigated": "challenge"},
                            text="<title>Just a moment...</title>")

    async def robots(req):
        return web.Response(text="User-agent: *\nDisallow: /private")

    async def pricing_freemium(req):
        return web.Response(text="<html><body><h1>Pricing</h1>" + "<p>Plans for everyone</p>" * 40 +
                            "<p>Free plan: $0 forever</p><p>Pro: $20/month per seat</p></body></html>", content_type="text/html")

    async def article(req):
        when = iso(NOW - timedelta(hours=2 if req.match_info["n"] == "fresh" else 60))
        return web.Response(content_type="text/html", text=f'<html><head><script type="application/ld+json">'
                            f'{{"@type":"NewsArticle","datePublished":"{when}"}}</script></head><body><article>{ART}</article></body></html>')

    app = web.Application()
    app.add_routes([web.get("/flaky", flaky), web.get("/cf", cf), web.get("/robots.txt", robots),
                    web.get("/private", pricing_freemium), web.get("/pricing", pricing_freemium),
                    web.get("/a/{n}", article)])
    return app


@pytest.fixture
async def server(aiohttp_server_factory=None):
    hits = {}
    runner = web.AppRunner(make_app(hits))
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", 0)
    await site.start()
    port = site._server.sockets[0].getsockname()[1]
    yield f"http://127.0.0.1:{port}", hits
    await runner.cleanup()


async def _noop(_): pass


async def test_429_retry_after_backoff(server):
    base, hits = server
    async with Fetcher(sleep=_noop, base_delay=0.01, per_domain=2) as f:
        r = await f.get(base + "/flaky", as_json=True)
    assert r.status == 200 and hits["flaky"] == 3 and f.stats["r429"] == 2


async def test_cloudflare_challenge_detected_and_escalation_attempted(server):
    base, _ = server
    async with Fetcher(sleep=_noop, max_tier=2) as f:
        with pytest.raises(BlockedError):      # tier1/2 libs absent here -> clean failure, not a hang or a crash
            await f.get(base + "/cf")
    assert f.stats["blocked"] >= 1 and f.stats["escalations"] >= 1


async def test_robots_respected(server):
    base, _ = server
    async with Fetcher(respect_robots=True) as f:
        with pytest.raises(FetchError):
            await f.get(base + "/private")
        assert (await f.get(base + "/pricing")).status == 200


def test_block_marker_detection():
    assert looks_blocked(403, {"server": "cloudflare"}, "<html>x</html>")
    assert looks_blocked(200, {}, "<title>Just a moment...</title>")
    assert not looks_blocked(200, {}, "<html>" + "real content " * 3000 + "</html>")
    assert not looks_blocked(404, {}, "not found")


def test_backoff_full_jitter_bounds():
    f = Fetcher(base_delay=1, max_delay=10)
    for a in range(8):
        for _ in range(50):
            assert 0 <= f.backoff(a) <= 10
    assert f.backoff(0, retry_after=7) >= 7


def mkctx(tmp_path):
    s = Settings(out_dir=tmp_path, respect_robots=False, concurrency=4)
    st = SqliteState(":memory:")
    f = Fetcher(sleep=_noop, respect_robots=False)
    return Ctx(s, f, LLMOrchestrator([]), EntityResolver("data/seed_entities.json"), st, FreshnessGate(st), JsonlSink(tmp_path))


def test_pricing_classifier():
    c = products.classify_pricing
    assert c("Free plan available. Pro $20/month")[0].value == "FREEMIUM"
    assert c("Starter $49/month Business $99/month")[0].value == "PAID"
    assert c("Contact sales for custom pricing")[0].value == "ENTERPRISE"
    assert c("completely free and open-source, no credit card")[0].value == "FREE"
    assert c("We build great things") is None
    assert "Free plan" in c("Free plan: $0 forever. Pro $20/month")[1]


async def test_product_record_end_to_end(server, tmp_path):
    base, _ = server
    ctx = mkctx(tmp_path)
    async with ctx.fetcher:
        await products.process(ctx, {"content": {"entityName": "Acme", "website": base}})
    rec = json.loads((tmp_path / "products.jsonl").read_text())
    assert rec["recordType"] == "PRODUCT" and rec["content"]["pricingModel"] == "FREEMIUM"
    assert rec["source"]["url"].endswith("/pricing") and "Free plan" in rec["content"]["pricingEvidence"]


async def test_news_freshness_end_to_end(server, tmp_path):
    base, _ = server
    ctx = mkctx(tmp_path)
    now = datetime.now(UTC)
    mk = lambda n, title: feedparser.parse(f"<rss><channel><item><title>{title}</title><link>{base}/a/{n}</link></item></channel></rss>").entries[0]
    async with ctx.fetcher:
        await news.process_entry(ctx, "T", mk("fresh", "Fresh story"), now)
        await news.process_entry(ctx, "T", mk("fresh", "Fresh story"), now)    # duplicate (another node / next run)
        await news.process_entry(ctx, "T", mk("stale", "Old story"), now)       # page says 60h old
    rows = [json.loads(l) for l in (tmp_path / "news.jsonl").read_text().splitlines()]
    assert len(rows) == 1 and rows[0]["content"]["title"] == "Fresh story"
    assert rows[0]["content"]["date_method"] == "jsonld" and len(rows[0]["content"]["text"]) > 200


ARXIV = """<feed xmlns="http://www.w3.org/2005/Atom" xmlns:arxiv="http://arxiv.org/schemas/atom"><entry>
<id>http://arxiv.org/abs/2411.01234v2</id><published>2026-11-20T17:59:59Z</published>
<title>A  Great
 Paper</title><summary>Code at https://github.com/foo/bar.git.</summary><author><name>Ada L</name></author><author><name>Bo C</name></author>
<arxiv:comment>Project page</arxiv:comment></entry></feed>"""


def test_arxiv_parsing_and_repo_extraction():
    p = papers.parse_arxiv_feed(ARXIV)[0]
    assert p["id"] == "2411.01234" and p["title"] == "A Great Paper" and p["authors"] == ["Ada L", "Bo C"]
    assert papers.parse_repo(p["summary"]) == ("foo", "bar")
    assert papers.parse_repo("see https://github.com/features/copilot") is None
    assert papers.parse_repo("https://github.com/org/repo/tree/main).") == ("org", "repo")


def test_job_helpers():
    assert jobs.role_family("Senior Research Scientist, LLMs") == "Research"
    assert jobs.role_family("Backend Engineer") == "Engineering"
    assert jobs.role_family("Account Executive") == "Sales & GTM"
    assert jobs.role_family("Chief of Vibes") == "Other"
    assert jobs.is_remote("Remote - US") and not jobs.is_remote("Hybrid, SF") and jobs.is_remote("Worldwide", board_remote=True)
