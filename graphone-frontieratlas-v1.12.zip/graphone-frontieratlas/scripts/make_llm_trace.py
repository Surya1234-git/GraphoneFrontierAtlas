"""Turn output/llm_events.jsonl (written by the orchestrator during a REAL run) into docs/llm_trace.md.
Refuses if the file is missing/empty or only mock providers appear. Usage: python scripts/make_llm_trace.py"""
import json
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MOCK = ("mock", "fake", "test")


def load(path: Path) -> list[dict]:
    if not path.exists():
        raise SystemExit(f"{path} not found: run the pipeline with real LLM keys first")
    ev = [json.loads(x) for x in path.read_text(encoding="utf-8").splitlines() if x.strip()]
    real = [e for e in ev if e.get("provider") and not str(e["provider"]).lower().startswith(MOCK)]
    if not real:
        raise SystemExit(f"{path} has no events from a real provider: refusing to write a trace")
    return real


def build(ev: list[dict]) -> str:
    prov = sorted({e["provider"] for e in ev})
    c: dict[str, Counter] = {p: Counter() for p in prov}
    for e in ev:
        c[e["provider"]]["fallback" if e.get("fallback_to") else e.get("status") or "?"] += 1
    md = ["# LLM trace (generated from output/llm_events.jsonl)", "", "| provider | 200 | 429 | 413 | fallbacks away |", "|---|---|---|---|---|"]
    md += [f"| {p} | {c[p][200]} | {c[p][429]} | {c[p][413]} | {c[p]['fallback']} |" for p in prov]
    marks = [i for i, e in enumerate(ev) if e.get("status") in (429, 413) or e.get("fallback_to")]
    windows, last = [], -10
    for i in marks:
        if i > last + 3:
            windows.append((max(i - 1, 0), min(i + 3, len(ev))))
            last = i
    md += ["", f"{len(ev)} events, {len(marks)} non-trivial. First {min(5, len(windows))} real sequences:", ""]
    for n, (lo, hi) in enumerate(windows[:5], 1):
        md += [f"### Sequence {n}", "", "| ts | provider | status | attempt | backoff_s | shrunk_to_chars | fallback_to |", "|---|---|---|---|---|---|---|"]
        md += [f"| {e['ts']} | {e['provider']} | {e['status']} | {e['attempt']} | {e['backoff_s']} | {e['shrunk_to_chars']} | {e['fallback_to']} |" for e in ev[lo:hi]]
        md.append("")
    if not windows:
        md.append("No 429/413/fallback occurred in this run, so there are no failure sequences to show.")
    return "\n".join(md) + "\n"


if __name__ == "__main__":
    out = ROOT / "docs" / "llm_trace.md"
    out.parent.mkdir(exist_ok=True)
    out.write_text(build(load(ROOT / "output" / "llm_events.jsonl")), encoding="utf-8")
    print(f"wrote {out}")
    sys.exit(0)
