"""Builds architecture.pdf (<= 3 pages). Run: python scripts/build_architecture_pdf.py"""
from reportlab.graphics.shapes import Drawing, Rect, String, Line, Polygon
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, TableStyle

INK, ACC, SOFT = colors.HexColor("#1b1f2a"), colors.HexColor("#4f46e5"), colors.HexColor("#eef0ff")
ss = getSampleStyleSheet()
B = ParagraphStyle("b", parent=ss["Normal"], fontName="Helvetica", fontSize=8.4, leading=10.6, textColor=INK, spaceAfter=2.5)
BL = ParagraphStyle("bl", parent=B, leftIndent=9, bulletIndent=0, spaceAfter=1.2)
H1 = ParagraphStyle("h1", parent=B, fontName="Helvetica-Bold", fontSize=15, leading=18, textColor=ACC, spaceAfter=1)
H2 = ParagraphStyle("h2", parent=B, fontName="Helvetica-Bold", fontSize=10.2, leading=12, textColor=ACC, spaceBefore=5, spaceAfter=2.5)
SUB = ParagraphStyle("s", parent=B, fontSize=8.2, textColor=colors.HexColor("#555b6e"), spaceAfter=4)
CELL = ParagraphStyle("c", parent=B, fontSize=7.6, leading=9.2, spaceAfter=0)
CELLB = ParagraphStyle("cb", parent=CELL, fontName="Helvetica-Bold")


def p(t): return Paragraph(t, B)
def bl(t): return Paragraph(t, BL, bulletText="\u2022")


def diagram():
    d = Drawing(540, 118)
    boxes = [("1  Discover", "sitemaps, APIs, feeds,\nbulk dumps (arXiv OAI,\nYC directory)", 0),
             ("2  Frontier", "Redis Streams / SQS\nper-domain token\nbuckets + dedupe", 1),
             ("3  Fetch", "async workers (K8s+KEDA)\naiohttp > curl_cffi >\nPlaywright ladder", 2),
             ("4  Extract", "rules first, then LLM:\nGemini>Groq>DeepSeek\n+ evidence grounding", 3),
             ("5  Resolve", "domain>alias>compact\n>fuzzy, seed list +\ndynamic canonicals", 4),
             ("6  Store", "Postgres + pgvector\nS3 raw landing zone\nRedis exactly-once state", 5)]
    w, g, x0, y = 82, 9, 2, 48
    for t, s, i in boxes:
        x = x0 + i * (w + g)
        d.add(Rect(x, y, w, 56, rx=5, ry=5, fillColor=SOFT, strokeColor=ACC, strokeWidth=0.9))
        d.add(String(x + 5, y + 42, t, fontName="Helvetica-Bold", fontSize=8.2, fillColor=ACC))
        for j, line in enumerate(s.split("\n")):
            d.add(String(x + 5, y + 28 - j * 9, line, fontName="Helvetica", fontSize=5.9, fillColor=INK))
        if i < 5:
            d.add(Line(x + w, y + 28, x + w + g, y + 28, strokeColor=ACC, strokeWidth=1.1))
            d.add(Polygon([x + w + g, y + 28, x + w + g - 3, y + 31, x + w + g - 3, y + 25], fillColor=ACC, strokeColor=ACC))
    d.add(Rect(2, 4, 538, 32, rx=5, ry=5, fillColor=colors.white, strokeColor=colors.HexColor("#c7cbe8"), strokeWidth=0.8))
    d.add(String(8, 24, "Cross-cutting:", fontName="Helvetica-Bold", fontSize=6.6, fillColor=INK))
    d.add(String(8, 13, "claim > process > commit leases (no double processing)  |  evidence-grounded extraction (no quote, no field)  |  "
                         "date provenance on every row  |  structured logs + metrics", fontName="Helvetica", fontSize=6.1, fillColor=INK))
    return d


def tbl(rows, widths):
    t = Table([[Paragraph(c, CELLB if i == 0 else CELL) for c in r] for i, r in enumerate(rows)], colWidths=widths)
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), SOFT), ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#c7cbe8")),
                           ("VALIGN", (0, 0), (-1, -1), "TOP"), ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2)]))
    return t


S = [Paragraph("GraphOne / FrontierAtlas - Ingestion Pipeline Architecture", H1),
     Paragraph("Design for 500,000+ startups, products and papers with zero manual intervention. v1.0", SUB), diagram(),

     Paragraph("1. Scale strategy: 500k records, no manual steps", H2),
     p("<b>Principle: scale by infrastructure, not code.</b> Every source is a declarative adapter (discover -> fetch -> parse). Adding "
       "workers or sources changes config only. Work is a queue of idempotent URL/ID tasks, so a run is restartable at any point."),
     bl("<b>Prefer bulk and structured channels over HTML crawling.</b> arXiv OAI-PMH harvests papers by resumption token (about 1,000 records per request, "
        "so 500k papers is on the order of 500 polite requests); YC directory is one JSON file; GitHub GraphQL aliases batch ~100 repos per query "
        "(500k star lookups = ~5k queries); sitemap indexes (with <i>lastmod</i>) enumerate directory sites without link-chasing."),
     bl("<b>Frontier + workers.</b> Discovery pushes tasks to Redis Streams/SQS; stateless async workers on Kubernetes autoscale on queue depth (KEDA). "
        "Per-domain token buckets + concurrency caps keep us polite while total throughput scales across hundreds of domains. "
        "The arXiv 3 s rule is met by the bulk path, not by crawling."),
     p("<b>Measured throughput</b> (<i>scripts/benchmark.py</i>, real Fetcher against a local loopback server with 40 ms latency, so it measures the client, not the internet): "
       "<b>135 req/s per process</b> at concurrency 100 (CPU-bound; the mock server shares the core). Per-host politeness caps one domain at 6.7 req/s (0.15 s interval), "
       "so a worker needs 20+ distinct hosts to reach its ceiling. Entity resolver: 125k names/s per core. "
       "<b>Extrapolation for 500k single-page fetches</b> assumes stateless workers scale linearly (only 1 process was measured):"),
     tbl([["Workers", "Aggregate req/s", "Time for 500k fetches", "Compute"], ["1", "135 (measured)", "about 62 min", "1 process"],
          ["8", "about 1,080 (assumed linear)", "about 7.7 min", "8 small pods"], ["32", "about 4,300 (assumed linear)", "about 2 min", "32 small pods (KEDA)"]],
         [60, 150, 130, 120]),
     bl("<b>Self-healing.</b> Task leases expire on worker crash and are retried; poison tasks go to a dead-letter queue with the failing HTTP/LLM reason; "
        "raw responses land gzip'd in S3 so parsers/prompts can be re-run (replay) without re-fetching."),
     bl("<b>LLM only where rules abstain.</b> Rules handle most structured fields (APIs, JSON-LD, meta tags, pricing keywords); the LLM chain handles the "
        "long tail. This sharply cuts cost and the 429/413 surface area. Results are cached by content hash."),
     bl("<b>Quality gates on every run:</b> row counts vs targets, 24 h-window violations (must be 0), duplicate keys (must be 0), "
        "% papers linked to GitHub, LLM drop-rate. Gates fail the job (non-zero exit) so regressions page someone."),

     Paragraph("2. Handling 413s and 429s across thousands of concurrent extractions", H2),
     tbl([["Failure", "Strategy (implemented in <font face='Courier'>llm.py</font>)", "At fleet scale"],
          ["<b>429</b> rate limit", "Exponential backoff with <b>full jitter</b> (sleep ~ U(0, min(cap, base*2^n))), <i>Retry-After</i> used as a floor. "
           "Proactive per-provider pacing (rpm) avoids most 429s. After N failures a <b>circuit breaker</b> opens; the next tier takes the request.",
           "Shared Redis token bucket per provider/key (Lua, atomic) so all pods obey one global quota; priority lanes (fresh news &gt; backfill); "
           "multiple API keys per tier."],
          ["<b>413</b> / context overflow", "Payload is first fitted to the provider's <b>known budget</b> by a semantic-density truncator: keep lede (35%) + conclusion, "
           "rank the middle by numbers/entities/keywords, drop boilerplate and duplicates, emit with gap markers. If a 413 (or 400 'token count') "
           "still occurs, budget shrinks x0.55 and retries (max 4); the learned budget is remembered per provider.",
           "Token estimation before dispatch; very long docs use map-reduce (extract per chunk, merge by evidence). Small docs are batch-packed "
           "into one call to save RPM."],
          ["<b>5xx / timeout</b>", "Retried with the same jittered backoff, then fall through the chain.", "Hedged request to the next tier after p95 latency."],
          ["<b>401 / 403</b>", "Provider disabled for the run (no retry storm).", "Alert + key rotation."],
          ["<b>Bad JSON</b>", "One repair retry ('JSON only'), then next tier.", "Schema-constrained decoding where the API supports it."]],
         [2.5 * cm, 9.1 * cm, 6.1 * cm]),

     Paragraph("3. Freshness tracking: never process the same article or job twice, across nodes", H2),
     bl("<b>Atomic claim -> process -> commit lease</b> in a shared store (Redis; SQLite for one node). <font face='Courier'>SET lease NX EX</font> makes exactly one node "
        "win; <font face='Courier'>done:</font> is written before the lease can expire; a crash simply lets the lease lapse and the item is retried."),
     bl("<b>Two identity keys per item:</b> sha1(canonical URL: lower-cased host, no www, tracking params stripped, fragment dropped) and sha1(source + normalised title), "
        "which catches syndicated or re-URL'd copies. At 10M+ keys a RedisBloom filter fronts the exact set."),
     bl("<b>Date pipeline:</b> feed date -> page JSON-LD -> meta tags -> &lt;time&gt; -> relative text ('2 hours ago', 'yesterday', '3d ago') -> URL path -> Last-Modified. "
        "Everything is normalised to UTC; future/implausible dates are rejected, not guessed. Each row stores <i>date_method</i> for audit. "
        "The 24 h rule is enforced on the normalised value."),
     bl("<b>No-date heuristic:</b> per-source <b>baseline run</b>. The first run only fingerprints what exists (emits nothing), so the back-catalogue never "
        "masquerades as new. Later runs emit an undated item only if its fingerprint is unseen, flagged <i>first-seen-heuristic</i>. "
        "Greenhouse <i>updated_at</i> is deliberately not treated as a publish date."),

     Paragraph("4. Anti-bot and JavaScript-heavy sources", H2),
     p("<b>Order of preference:</b> official API/feed &gt; sitemap &gt; plain HTTP &gt; escalation. Escalation ladder (per-domain memory, so a protected host costs one expensive hit):"),
     bl("<b>Tier 0</b> aiohttp: stable per-host User-Agent and headers, HTTP/2-era defaults, per-domain pacing, robots.txt honoured, conditional requests."),
     bl("<b>Tier 1</b> <font face='Courier'>curl_cffi</font> impersonating Chrome's TLS/JA3 + HTTP/2 fingerprint, which defeats most passive Cloudflare/Datadome fingerprint checks cheaply."),
     bl("<b>Tier 2</b> Playwright (async) with a realistic context; waits for the JS challenge to clear, then <b>harvests cookies</b> (e.g. cf_clearance, bound to UA+IP) so subsequent "
        "requests drop back to Tier 0/1. Residential/ISP proxy pools with sticky sessions are used only at this tier. Block detection covers status, cf-mitigated, "
        "datadome/px markers and soft-block interstitials."),
     bl("<b>Hard targets</b> (aggressive Datadome, login walls): we do not solve CAPTCHAs or evade authentication. We use licensed/partner data feeds, "
        "ask for API access, or capture through user-consented browser sessions; sources that stay blocked are dead-lettered and surfaced on a dashboard."),

     Paragraph("5. Storage strategy and justification", H2),
     tbl([["Layer", "Choice", "Why"],
          ["System of record", "<b>PostgreSQL</b> (JSONB + relational)", "Entities are semi-structured but heavily relational. Unique constraints give idempotent upserts "
           "(canonical_url, arxiv_id); transactions keep entity + alias + edge writes consistent; 500k-50M rows is routine. JSONB keeps schema-v1.x evolution cheap."],
          ["Graph", "<b>Edge tables in Postgres</b> (startup-product, paper-repo, person-startup, job-company, news-mentions)",
           "Most queries are 1-3 hops (recursive CTEs). Avoids a second consistency domain. Promote to Neo4j/Apache AGE via CDC only if deep traversal / "
           "graph algorithms dominate."],
          ["Vector", "<b>pgvector</b> (HNSW)", "Embeds names/descriptions for resolution candidates, semantic dedup and search, joined with relational filters in one query. "
           "Move to Qdrant past ~10M vectors."],
          ["Raw + state", "<b>S3</b> (gzip) and <b>Redis</b>", "Immutable replayable raw landing zone; Redis for leases, token buckets, baselines and queues."]],
         [2.5 * cm, 5.2 * cm, 10.0 * cm]),

     Paragraph("6. Entity resolution and anti-hallucination", H2),
     bl("<b>Deterministic cascade</b> (<font face='Courier'>resolver.py</font>): domain match &gt; exact alias &gt; compact key (\"Open AI\" -> openai) &gt; generic-token-stripped key "
        "(\"Cohere AI\", \"Anysphere, Inc.\") &gt; guarded fuzzy (rapidfuzz, margin test, same initial; ambiguous = no merge) &gt; register NEW canonical so later variants "
        "collapse into it. Every decision (raw, canonical, method, score) is written to the Entity Mapping Log. Embedding-based candidate generation is the scale-out step; "
        "merges stay rule-gated."),
     bl("<b>No fabricated data, by construction.</b> (1) Records are built from parsed source fields wherever possible. (2) The LLM must return a verbatim <i>evidence</i> quote per field; "
        "the quote must exist in the fetched text and the value must be consistent with it, else the field is dropped, and a missing required field drops the record "
        "(tested). (3) <font face='Courier'>source.url</font> is a validated http(s) URL on every record. (4) Pricing records store the evidence snippet. (5) GitHub stars are always "
        "read live from the GitHub API and stamped with <i>github_stars_checked_at</i>; if no repo is found the field is null, never inferred."),
     bl("<b>Verification:</b> 40+ offline tests cover date parsing, truncation, 429/413/fallback chains, grounding, lease semantics, resolver precision "
        "(look-alikes must not merge), and local-server integration for Retry-After and Cloudflare-style blocks.")]


def foot(c, d):
    c.saveState(); c.setFont("Helvetica", 7); c.setFillColor(colors.HexColor("#777"))
    c.drawString(1.4 * cm, 0.8 * cm, "GraphOne / FrontierAtlas - AI Engineer demo task - architecture"); c.drawRightString(A4[0] - 1.4 * cm, 0.8 * cm, f"page {d.page}")
    c.restoreState()


doc = SimpleDocTemplate("architecture.pdf", pagesize=A4, leftMargin=1.4 * cm, rightMargin=1.4 * cm, topMargin=1.2 * cm, bottomMargin=1.4 * cm,
                        title="GraphOne Architecture", author="AI Engineer candidate")
doc.build(S, onFirstPage=foot, onLaterPages=foot)
from pypdf import PdfReader
n = len(PdfReader("architecture.pdf").pages)
print("pages:", n)
assert n <= 3, "architecture doc must be <= 3 pages"
