"""Validate output/ against the brief, then build every submission artefact FROM REAL FILES (never fabricated).
  python scripts/finalize_submission.py --check-only
  python scripts/finalize_submission.py --sheet-url URL --github-url URL [--push-sheet]
Refuses (exit 1, readable list) if run_report.json is missing or any requirement of the brief is unmet."""
import argparse
import json
import re
import sys
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "dashboard")]
from graphone.export import TABS, export, read_jsonl, validate  # noqa: E402

START, END = "<!-- RESULTS:START -->", "<!-- RESULTS:END -->"
HTTP = re.compile(r"^https?://\S+$")


def src_url(r: dict) -> str:
    return str((r.get("source") or {}).get("url") or (r.get("content") or {}).get("paper_url") or "")


def check(out: Path) -> list[str]:
    if not (out / "run_report.json").exists():
        return [f"{out}/run_report.json is missing: run the pipeline first (no data is ever invented)"]
    rows = {n: read_jsonl(out / f"{n}.jsonl") for _, n in TABS}
    f: list[str] = []
    for n in ("startups", "products", "papers"):
        if len(rows[n]) < 1000:
            f.append(f"{n}: {len(rows[n])} rows, the brief needs >= 1000")
    no_stars = [r for r in rows["papers"] if r["content"].get("github_url") and r["content"].get("github_stars") is None]
    if no_stars:
        f.append(f"papers: {len(no_stars)} rows have a github_url but no github_stars")
    if rows["papers"] and not any(r["content"].get("github_stars") is not None for r in rows["papers"]):
        f.append("papers: no row carries github_stars (set GITHUB_TOKEN and re-run the papers phase)")
    v = validate(out)
    stale = v.get("jobs_stale_violations", 0) + v.get("news_stale_violations", 0)
    if stale:
        f.append(f"{stale} jobs/news rows are older than 24 h")
    for n, rs in rows.items():
        bad = sum(1 for r in rs if not HTTP.match(src_url(r)))
        if bad:
            f.append(f"{n}: {bad} rows without a valid http(s) source URL")
        urls = [src_url(r) for r in rs]
        if len(urls) != len(set(urls)):
            f.append(f"{n}: {len(urls) - len(set(urls))} duplicate source URLs")
    if not (out / "entity_mapping_log.csv").exists():
        f.append("entity_mapping_log.csv is missing")
    return f


def results_block(out: Path) -> str:
    rep = json.loads((out / "run_report.json").read_text(encoding="utf-8"))
    counts = {t: len(read_jsonl(out / f"{n}.jsonl")) for t, n in TABS}
    st = rep.get("stats", {})
    lines = [START, "| Tab | Rows |", "|---|---|"] + [f"| {t} | {c:,} |" for t, c in counts.items()]
    lines += ["", f"Fetch stats: `{json.dumps(st.get('fetch', {}))}`  ", f"LLM stats: `{json.dumps(st.get('llm', {}))}`  ",
              f"_Generated {datetime.now(UTC).isoformat(timespec='seconds')} by `scripts/finalize_submission.py` from `output/run_report.json`._", END]
    return "\n".join(lines)


def write_block(readme: Path, block: str, start: str = START, end: str = END) -> None:
    text = readme.read_text(encoding="utf-8")
    if start in text and end in text:
        text = re.sub(re.escape(start) + r".*?" + re.escape(end), lambda _m: block, text, flags=re.S)
    else:  # first run: insert right after the title line
        i = text.find("\n") + 1
        text = text[:i] + "\n" + block + "\n" + text[i:]
    readme.write_text(text, encoding="utf-8")


def push_sheet(out: Path, url: str) -> None:
    import csv

    import gspread  # optional: pip install gspread; service-account JSON via GOOGLE_APPLICATION_CREDENTIALS
    sh = gspread.service_account().open_by_url(url)
    for tab, name in [*TABS, ("Entity Mapping Log", "entity_mapping_log")]:
        with open(out / f"{name}.csv", newline="", encoding="utf-8") as fh:
            data = list(csv.reader(fh))
        try:
            ws = sh.worksheet(tab)
            ws.clear()
        except gspread.WorksheetNotFound:
            ws = sh.add_worksheet(tab, rows=max(len(data), 2), cols=max(len(data[0]), 1))
        ws.update(data)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=str(ROOT / "output"))
    ap.add_argument("--docs", default=str(ROOT / "docs"))
    ap.add_argument("--sheet-url")
    ap.add_argument("--github-url")
    ap.add_argument("--check-only", action="store_true")
    ap.add_argument("--push-sheet", action="store_true", help="upload the 6 tabs with gspread (off by default)")
    a = ap.parse_args(argv)
    out, docs = Path(a.out), Path(a.docs)
    failures = check(out)
    if failures:
        print("NOT READY TO SUBMIT:\n" + "\n".join(f"  - {x}" for x in failures))
        return 1
    if a.check_only:
        print("OK: output/ satisfies the brief")
        return 0
    counts = export(out)
    from server import static_export
    static_export(out, docs)
    cfg = {"sheetUrl": a.sheet_url or "", "githubUrl": a.github_url or ""}
    if any(v and not HTTP.match(v) for v in cfg.values()):
        print("--sheet-url/--github-url must be http(s) URLs")
        return 1
    if a.sheet_url or a.github_url:
        for p in (ROOT / "dashboard" / "config.json", docs / "config.json"):
            p.write_text(json.dumps(cfg) + "\n", encoding="utf-8")
    write_block(ROOT / "README.md", results_block(out))
    if a.push_sheet:
        push_sheet(out, a.sheet_url or "")
    print(f"exported {counts}\nstatic site -> {docs}/\nREADME results block updated")
    return 0


if __name__ == "__main__":
    sys.exit(main())
