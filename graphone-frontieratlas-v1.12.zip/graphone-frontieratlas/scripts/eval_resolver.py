"""Entity-resolution accuracy on a hand-labelled set (data/er_labelled.csv).
expected == canonical name -> must resolve to it; expected == NEW -> must NOT map onto a seed entity.
Usage: PYTHONPATH=src python scripts/eval_resolver.py"""
import csv
import json
import sys
from pathlib import Path

from graphone.resolver import EntityResolver

ROOT = Path(__file__).resolve().parents[1]


def evaluate(name: str = "er_labelled.csv") -> dict:
    path = Path(name) if Path(name).is_absolute() or Path(name).exists() else ROOT / "data" / name
    with open(path, encoding="utf-8", newline="") as fh:
        rows = list(csv.DictReader(fh))
    unlabeled = [r["raw"] for r in rows if not (r.get("expected") or "").strip()]
    if unlabeled:
        raise ValueError(f"{len(unlabeled)} unlabeled rows (e.g. {unlabeled[:3]}): fill the `expected` column by hand first")
    res = EntityResolver(ROOT / "data" / "seed_entities.json")
    seeds = {e["canonical"] for e in json.load(open(ROOT / "data" / "seed_entities.json", encoding="utf-8"))}
    tp = fp = fn = tn = 0
    fails, merges = [], []
    for r in rows:
        out = res.resolve(r["raw"], r.get("domain") or None, log=False)
        mapped = out.canonical if out.canonical in seeds else None  # metric = mapping onto the SEED list
        if r["expected"] == "NEW" and not mapped and not out.is_new and out.canonical != r["raw"]:
            merges.append((r["raw"], out.canonical, out.method))  # informational: merged into another non-seed entity
        if r["expected"] == "NEW":
            tn += mapped is None
            if mapped:
                fp += 1
                fails.append((r["raw"], "NEW", mapped, out.method))
        elif mapped == r["expected"]:
            tp += 1
        else:
            fn += 1
            if mapped:
                fp += 1
            fails.append((r["raw"], r["expected"], mapped or "(new)", out.method))
    pos = tp + fn
    return {"n": len(rows), "positives": pos, "negatives": len(rows) - pos, "precision": tp / (tp + fp) if tp + fp else 1.0,
            "recall": tp / pos, "negatives_rejected": tn, "fails": fails, "merges": merges}


if __name__ == "__main__":
    try:
        m = evaluate(sys.argv[1] if len(sys.argv) > 1 else "er_labelled.csv")
    except ValueError as e:
        sys.exit(f"refusing to score: {e}")
    print(f"{m['n']} labelled names ({m['positives']} variants, {m['negatives']} negatives)")
    print(f"precision {m['precision']:.1%} | recall {m['recall']:.1%} | negatives correctly kept new {m['negatives_rejected']}/{m['negatives']}")
    print(f"non-seed merges (informational, same-company merges are legitimate): {m['merges']}")
    for raw, exp, got, method in m["fails"]:
        print(f"  MISS  {raw!r}: expected {exp}, got {got} via {method}")
    sys.exit(0)
