"""Sample company strings from the REAL run (output/entity_mapping_log.csv) into data/er_heldout_candidates.csv with an
EMPTY `expected` column for you to label by hand (canonical seed name, or NEW). Refuses if there is no real log."""
import csv
import random
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def sample(log: Path, n: int = 60, seed: int = 7) -> list[str]:
    if not log.exists():
        raise SystemExit(f"{log} not found: run the pipeline first")
    with open(log, newline="", encoding="utf-8") as f:
        raws = sorted({r["raw"] for r in csv.DictReader(f) if r["raw"].strip()})
    if not raws:
        raise SystemExit(f"{log} is empty")
    return random.Random(seed).sample(raws, min(n, len(raws)))


if __name__ == "__main__":
    rows = sample(ROOT / "output" / "entity_mapping_log.csv", int(sys.argv[1]) if len(sys.argv) > 1 else 60)
    dest = ROOT / "data" / "er_heldout_candidates.csv"
    with open(dest, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["raw", "domain", "expected"])
        w.writerows([r, "", ""] for r in rows)
    print(f"{len(rows)} candidates -> {dest}. Fill `expected` by hand BEFORE looking at the resolver output, then:\n"
          "  PYTHONPATH=src python scripts/eval_resolver.py er_heldout_candidates.csv")
