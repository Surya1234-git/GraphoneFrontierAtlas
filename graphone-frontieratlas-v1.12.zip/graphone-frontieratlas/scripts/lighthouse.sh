#!/usr/bin/env bash
# Lighthouse against the static export in docs/ (desktop + mobile). Scores are printed from the REAL run only.
# Targets: accessibility >= 95, best-practices >= 95. Needs Node (npx) and Chrome.
set -euo pipefail
[ -f docs/index.html ] || { echo "docs/ missing: run scripts/finalize_submission.py first"; exit 1; }
python3 -m http.server 8899 -d docs >/dev/null 2>&1 & PID=$!; trap 'kill $PID' EXIT; sleep 1
for preset in desktop mobile; do
  flags=(); [ "$preset" = desktop ] && flags=(--preset=desktop)
  npx --yes lighthouse http://127.0.0.1:8899 "${flags[@]}" --only-categories=accessibility,best-practices --output=json \
      --output-path="docs/lighthouse-$preset.json" --chrome-flags="--headless" --quiet
  python3 - "$preset" <<'PY'
import json, sys
c = json.load(open(f"docs/lighthouse-{sys.argv[1]}.json"))["categories"]
print(sys.argv[1], {k: round(v["score"] * 100) for k, v in c.items()})
PY
done
