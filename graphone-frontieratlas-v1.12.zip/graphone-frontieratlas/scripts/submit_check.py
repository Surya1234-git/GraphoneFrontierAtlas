"""Submission gate: no secrets in the tree, no TODO/placeholder in README, Sheet + GitHub URLs set in config.json."""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SECRETS = re.compile(r"AIza[0-9A-Za-z_\-]{35}|gsk_[A-Za-z0-9]{20,}|sk-[A-Za-z0-9_\-]{20,}|ghp_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|(?:GEMINI|GROQ|DEEPSEEK|GITHUB)_[A-Z_]*KEY[ \t]*=[ \t]*\S{12,}")
PLACEHOLDER = re.compile(r"\b(TODO|FIXME|TBD)\b|lorem ipsum|YOUR_[A-Z_]+|<your[ -]|\[(?:placeholder|insert)[^\]]*\]", re.I)
SKIP = {".git", ".venv", "node_modules", "__pycache__", ".pytest_cache", ".ruff_cache", "output", "docs"}


def scan_secrets(root: Path) -> list[str]:
    hits = []
    for p in root.rglob("*"):
        if p.is_file() and not (SKIP & set(p.relative_to(root).parts)) and p.suffix not in {".pdf", ".png", ".woff2", ".xlsx", ".zip"} and p.name != ".env":
            try:
                if SECRETS.search(p.read_text(encoding="utf-8")):
                    hits.append(f"possible secret in {p.relative_to(root)}")
            except (UnicodeDecodeError, OSError):
                continue
    return hits


def problems(root: Path = ROOT) -> list[str]:
    out = scan_secrets(root)
    readme = (root / "README.md").read_text(encoding="utf-8")
    out += [f"README placeholder: {m.group(0)!r}" for m in PLACEHOLDER.finditer(readme)]
    cfg = json.loads((root / "dashboard" / "config.json").read_text(encoding="utf-8"))
    out += [f"dashboard/config.json: {k} is not set to an http(s) URL" for k in ("sheetUrl", "githubUrl") if not re.match(r"^https?://", cfg.get(k) or "")]
    return out


if __name__ == "__main__":
    ps = problems()
    print("\n".join(f"  - {x}" for x in ps) if ps else "OK: no secrets, no placeholders, links set")
    sys.exit(1 if ps else 0)
