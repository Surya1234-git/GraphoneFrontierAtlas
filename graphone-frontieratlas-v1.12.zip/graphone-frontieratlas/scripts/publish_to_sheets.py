"""Upload output/graphone_output.xlsx (6 tabs) to a NEW public-read Google Sheet.

Setup: create a Google Cloud service account, enable the Sheets + Drive APIs, download its JSON key and
    export GOOGLE_APPLICATION_CREDENTIALS=/path/key.json
    pip install gspread openpyxl
    python scripts/publish_to_sheets.py output/graphone_output.xlsx "GraphOne Pipeline Output"
(Alternative with zero setup: Google Sheets -> File -> Import -> Upload graphone_output.xlsx -> 'Insert new sheet(s)',
 then Share -> Anyone with the link -> Viewer.)
"""
import os
import sys

import gspread
from openpyxl import load_workbook

path = sys.argv[1] if len(sys.argv) > 1 else "output/graphone_output.xlsx"
title = sys.argv[2] if len(sys.argv) > 2 else "GraphOne Pipeline Output"
gc = gspread.service_account(filename=os.environ["GOOGLE_APPLICATION_CREDENTIALS"])
sh = gc.create(title)
wb = load_workbook(path, read_only=True)
for i, ws in enumerate(wb.worksheets):
    rows = [["" if c is None else c for c in r] for r in ws.iter_rows(values_only=True)]
    g = sh.sheet1 if i == 0 else sh.add_worksheet(ws.title, rows=max(len(rows), 2), cols=max(len(rows[0]), 2))
    if i == 0:
        g.update_title(ws.title)
        g.resize(rows=max(len(rows), 2), cols=max(len(rows[0]), 2))
    for s in range(0, len(rows), 5000):                    # batch to respect API limits
        g.update(rows[s:s + 5000], f"A{s + 1}")
    g.freeze(rows=1)
sh.share(None, perm_type="anyone", role="reader")
print("Public sheet:", sh.url)
