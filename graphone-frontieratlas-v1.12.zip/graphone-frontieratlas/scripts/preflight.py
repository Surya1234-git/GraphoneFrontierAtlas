"""Preflight: hit every live source once and report whether its response SHAPE still matches the adapters.
Run before the full pipeline:  python scripts/preflight.py   (exit 1 if anything is off)"""
import asyncio, json, sys
import aiohttp

J = lambda f: ("json", f)
T = lambda f: ("text", f)
CHECKS = [
    ("YC directory (startups)", "https://yc-oss.github.io/api/companies/all.json", J(lambda d: isinstance(d, list) and "name" in d[0] and "url" in d[0])),
    ("arXiv API (papers)", "https://export.arxiv.org/api/query?search_query=cat:cs.LG&max_results=1", T(lambda t: "<entry>" in t)),
    ("HF daily papers", "https://huggingface.co/api/daily_papers", J(lambda d: isinstance(d, list) and "paper" in d[0])),
    ("GitHub search (products)", "https://api.github.com/search/repositories?q=topic:llm&per_page=1", J(lambda d: "license" in d["items"][0] and "owner" in d["items"][0])),
    ("GitHub repo (stars)", "https://api.github.com/repos/huggingface/transformers", J(lambda d: isinstance(d.get("stargazers_count"), int))),
    ("RemoteOK", "https://remoteok.com/api", J(lambda d: any(isinstance(x, dict) and "epoch" in x for x in d))),
    ("Remotive", "https://remotive.com/api/remote-jobs?limit=1", J(lambda d: "publication_date" in d["jobs"][0])),
    ("We Work Remotely", "https://weworkremotely.com/categories/remote-programming-jobs.rss", T(lambda t: "<item>" in t)),
    ("Greenhouse (anthropic)", "https://boards-api.greenhouse.io/v1/boards/anthropic/jobs", J(lambda d: "jobs" in d)),
    ("Lever (mistral)", "https://api.lever.co/v0/postings/mistral?mode=json", J(lambda d: isinstance(d, list))),
    ("TechCrunch AI feed", "https://techcrunch.com/category/artificial-intelligence/feed/", T(lambda t: "<item>" in t)),
    ("VentureBeat AI feed", "https://venturebeat.com/category/ai/feed/", T(lambda t: "<item>" in t)),
    ("The Verge AI feed", "https://www.theverge.com/rss/ai-artificial-intelligence/index.xml", T(lambda t: "<entry" in t or "<item>" in t)),
    ("MIT TR AI feed", "https://www.technologyreview.com/topic/artificial-intelligence/feed", T(lambda t: "<item>" in t)),
    ("Hugging Face blog feed", "https://huggingface.co/blog/feed.xml", T(lambda t: "<item>" in t or "<entry" in t)),
]


async def one(s, name, url, spec):
    kind, ok = spec
    try:
        async with s.get(url, headers={"User-Agent": "graphone-preflight"}, timeout=aiohttp.ClientTimeout(total=25)) as r:
            body = await r.text()
            if r.status != 200:
                return name, False, f"HTTP {r.status}"
            return name, bool(ok(json.loads(body) if kind == "json" else body)), "shape OK"
    except Exception as e:  # noqa: BLE001
        return name, False, f"{type(e).__name__}: {str(e)[:60]}"


async def main() -> int:
    async with aiohttp.ClientSession() as s:
        res = await asyncio.gather(*(one(s, n, u, sp) for n, u, sp in CHECKS))
    for n, ok, why in res:
        print(f"{'PASS' if ok else 'FAIL'}  {n:28} {why if ok else why + '  <- fix this adapter first'}")
    bad = sum(not ok for _, ok, _ in res)
    print(f"\n{len(res) - bad}/{len(res)} sources healthy")
    return 1 if bad else 0

sys.exit(asyncio.run(main()))
