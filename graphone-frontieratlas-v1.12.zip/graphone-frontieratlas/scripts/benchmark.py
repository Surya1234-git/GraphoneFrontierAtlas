"""Throughput benchmark. Fetch layer runs against a LOCAL loopback server with a fixed 40 ms response latency, so it
measures this client's own overhead and concurrency ceiling, NOT internet speed. Usage: PYTHONPATH=src python scripts/benchmark.py"""
import asyncio
import time
from pathlib import Path

from aiohttp import web

from graphone.fetcher import Fetcher
from graphone.resolver import EntityResolver
from graphone.textclean import smart_truncate

ROOT = Path(__file__).resolve().parents[1]
BODY = "<html><body>" + "<p>AI startup raised funding and shipped a new product.</p>" * 40 + "</body></html>"


async def fetch_bench(n: int, conc: int, hosts: int = 1, paced: bool = True, latency: float = 0.04) -> float:
    """hosts > 1 uses 127.0.0.1..N as distinct 'domains' (per-host pacing is keyed by host name)."""
    async def page(req):
        await asyncio.sleep(latency)
        return web.Response(text=BODY, content_type="text/html")
    app = web.Application()
    app.add_routes([web.get("/p/{i}", page)])
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", 0)
    await site.start()
    port = site._server.sockets[0].getsockname()[1]
    names = [f"127.0.0.{h + 1}" for h in range(hosts)]
    try:
        async with Fetcher(concurrency=conc, per_domain=conc, respect_robots=False, max_tier=0, contact="bench@example.com",
                           intervals=None if paced else {h: 0 for h in names}) as f:
            t = time.perf_counter()
            res = await asyncio.gather(*(f.get(f"http://{names[i % hosts]}:{port}/p/{i}") for i in range(n)))
            dt = time.perf_counter() - t
        assert all(r.status == 200 for r in res)
        return n / dt
    finally:
        await runner.cleanup()


def cpu_bench() -> tuple[float, float]:
    res = EntityResolver(ROOT / "data" / "seed_entities.json")
    names = ["Open AI", "Anthropc", "Stripe", "Hugging-Face", "Scale Computing"] * 4000
    t = time.perf_counter()
    for nm in names:
        res.resolve(nm, log=False)
    r = len(names) / (time.perf_counter() - t)
    doc = "\n".join(f"Paragraph {i} mentions {i * 7 % 97} percent growth." for i in range(4000))
    t = time.perf_counter()
    for _ in range(20):
        smart_truncate(doc, 20_000)
    return r, 20 / (time.perf_counter() - t)


if __name__ == "__main__":
    print("fetch layer, local loopback server, 40 ms latency (measures this client, not the internet):")
    print(f"  1 host,  polite pacing (0.15 s/host): {asyncio.run(fetch_bench(60, 40)):8.1f} req/s")
    print(f" 20 hosts, polite pacing, conc 100    : {asyncio.run(fetch_bench(800, 100, hosts=20)):8.1f} req/s")
    print(f"  unpaced client ceiling, conc 100    : {asyncio.run(fetch_bench(2000, 100, hosts=20, paced=False)):8.1f} req/s")
    rr, tr = cpu_bench()
    print(f"entity resolver : {rr:10,.0f} names/s (single core)")
    print(f"smart_truncate  : {tr:10,.1f} docs/s (4,000 paragraphs each)")
