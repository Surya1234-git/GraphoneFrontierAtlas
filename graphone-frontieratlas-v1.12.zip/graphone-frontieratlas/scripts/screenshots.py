"""Capture docs/ (the static export of a REAL run) at 1440x900 and 375x812, light + dark, into docs/screenshots/.
Refuses if docs/ has no data. Needs: pip install playwright && playwright install chromium. Usage: python scripts/screenshots.py"""
import asyncio
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PAGES = ["mission", "data", "fresh", "graph", "lab"]
VIEWS = {"desktop": (1440, 900), "mobile": (375, 812)}


def precheck(docs: Path) -> str | None:
    if not (docs / "index.html").exists() or not (docs / "data" / "summary.json").exists():
        return f"{docs}/ is missing: run scripts/finalize_submission.py first"
    if sum(json.loads((docs / "data" / "summary.json").read_text(encoding="utf-8"))["counts"].values()) == 0:
        return "docs/ contains no records: refusing to screenshot an empty dashboard"
    return None


async def shoot(docs: Path) -> list[Path]:
    from aiohttp import web
    from playwright.async_api import async_playwright
    app = web.Application()
    app.router.add_static("/", docs)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", 0)
    await site.start()
    port = site._server.sockets[0].getsockname()[1]
    (docs / "screenshots").mkdir(exist_ok=True)
    made = []
    async with async_playwright() as p:
        b = await p.chromium.launch()
        for theme in ("light", "dark"):
            for view, (w, h) in VIEWS.items():
                ctx = await b.new_context(viewport={"width": w, "height": h}, device_scale_factor=2)
                await ctx.add_init_script(f"localStorage.setItem('th','{theme}')")
                pg = await ctx.new_page()
                await pg.goto(f"http://127.0.0.1:{port}/index.html")
                await pg.wait_for_timeout(1500)
                for name in PAGES:
                    await pg.evaluate(f"document.querySelector('nav a[data-v={name}]').click()")
                    await pg.wait_for_timeout(3500 if name == "graph" else 500)
                    f = docs / "screenshots" / f"{name}-{theme}-{view}.png"
                    await pg.screenshot(path=str(f))
                    made.append(f)
                await ctx.close()
        await b.close()
    await runner.cleanup()
    return made


def block(docs: Path, files: list[Path]) -> str:
    imgs = [f"![{f.stem}](docs/screenshots/{f.name})" for f in files if "-light-desktop" in f.name or "-light-mobile" in f.name]
    return "<!-- SCREENSHOTS:START -->\n" + "\n".join(imgs) + "\n<!-- SCREENSHOTS:END -->"


if __name__ == "__main__":
    docs = ROOT / "docs"
    if err := precheck(docs):
        sys.exit(err)
    try:
        import playwright  # noqa: F401
    except ImportError:
        sys.exit("Playwright is not installed: pip install playwright && playwright install chromium")
    from finalize_submission import write_block
    files = asyncio.run(shoot(docs))
    write_block(ROOT / "README.md", block(docs, files), "<!-- SCREENSHOTS:START -->", "<!-- SCREENSHOTS:END -->")
    print(f"{len(files)} screenshots -> docs/screenshots/, README block updated")
