# Submission checklist (steps only you can do)
Each item has a "done when" test. Order matters.

1. **Real data.** `python scripts/preflight.py` -> fix every FAIL. Set `GITHUB_TOKEN`. `run all`, then export immediately (24 h window). Import `output/graphone_output.xlsx` into Google Sheets, share "Anyone with the link: Viewer", open in an incognito window.
   *Done when* `run_report.json` shows all three targets met, 0 stale rows, 0 gate problems; ~20 rows spot-checked by hand.
2. **Real LLM evidence.** Put Gemini, Groq and DeepSeek keys in `.env`; run again. Save a log excerpt showing a real 429 backoff / 413 shrink / fallback to `docs/llm_trace.md`.
   *Done when* `run_report.json` has `llm.calls > 0` across 2+ providers.
3. **Real anti-bot trace.** Fetch one Cloudflare/JS-heavy page; paste the URL, which tier succeeded and what failed into the README.
4. **Host the dashboard.** `make export-static` -> publish `docs/` with GitHub Pages; add 3-4 screenshots to the README.
5. **CI badge, repo link, 2-minute screen recording**; check both submission links open without login.

Known gaps: `mypy` reports ~41 annotation errors (not enforced in CI); coverage is 64%.
